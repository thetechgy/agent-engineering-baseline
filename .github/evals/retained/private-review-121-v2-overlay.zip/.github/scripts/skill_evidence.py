#!/usr/bin/env python3
"""Offline evidence inventory and closed, data-only reporting contracts."""

import argparse
import copy
from contextlib import contextmanager
from datetime import datetime, timezone
import errno
import hashlib
from importlib.metadata import PackageNotFoundError, version as installed_version
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace

# Standalone commands must not mutate the checkout while importing local helpers.
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import skill_reports as reports
import evaluator_profiles as profiles
import static_evaluator
import unscored_security

# Frozen static admission identity, not a freshness inventory. Retain this profile
# when admitting future scanner groups. Earlier historical records omit the field.
SCANNER_RUNTIME_UNPATCHED = {
    "versions": {
        "semgrep": "1.184.0",
        "skillspector": "2.13.4",
        "gitleaks": "8.30.1",
        "bandit": "1.9.4",
        "pip-audit": "2.10.1"
    },
    "skillspector_revision": "54824463814a0be01360792523ec7245a69190fc",
    "skillspector_lock": "sha256:8c922f8c222c28c7e02b1dc856a2b9464fb2d768ddae944ee9f8131452bfeee9",
    "semgrep_lock": "sha256:523bff62b068c83716cfd73e461d23beb8876a9a951227a7aaaf0b7b7a37b764"
}

SCANNER_RUNTIME_PREVIOUS = {**SCANNER_RUNTIME_UNPATCHED,
                   "adapter_patch": "sha256:09ab5d1440f355224935b9498ea3c2a68395d656997932ab525771287cb802bc"}
SCANNER_RUNTIME_2134 = {**SCANNER_RUNTIME_PREVIOUS,
                   "versions": {**SCANNER_RUNTIME_PREVIOUS["versions"], "semgrep": "1.185.0"},
                   "skillspector_lock": "sha256:3352c462434ed1d906069b710bfba8b352c255139a0c5718f4edb6ad4051be2b",
                   "semgrep_lock": "sha256:d0c13313fb643f578a8116375078d344bfcf74748380ca88acd6e0d7d467c520"}
SCANNER_RUNTIME_2136_INITIAL = {
    **SCANNER_RUNTIME_2134,
    "versions": {**SCANNER_RUNTIME_2134["versions"], "skillspector": "2.13.6", "semgrep": "1.186.0"},
    "skillspector_revision": "e2674da339b0bddc6e565d059c0577c6d9cd25da",
    "skillspector_lock": "sha256:5ab9adb9707d66ee786cf934509d6c8d7258fb7ce12ebbc6a5b74fee35733fd1",
    "semgrep_lock": "sha256:f0e17604bc64d9189ea4165c1e7fb5612834488d4be786312601d0f04763053e",
}
SCANNER_RUNTIME = {
    **SCANNER_RUNTIME_2136_INITIAL,
    "semgrep_lock": static_evaluator.SEMGREP_LOCK,
}


def scanner_adapters(patched):
    """Bind the same scanner bytes to the two other qualified evaluator adapters."""
    unpatched = {key: value for key, value in patched.items() if key != "adapter_patch"}
    return unpatched, {**unpatched, "evaluator_revision": profiles.NEXT['revision']}


SCANNER_2134_UNPATCHED, SCANNER_2134_NEXT = scanner_adapters(SCANNER_RUNTIME_2134)
SCANNER_2136_INITIAL_UNPATCHED, SCANNER_2136_INITIAL_NEXT = scanner_adapters(
    SCANNER_RUNTIME_2136_INITIAL)
SCANNER_2136_UNPATCHED, SCANNER_2136_NEXT = scanner_adapters(SCANNER_RUNTIME)
SCANNER_RUNTIME_2136 = SCANNER_RUNTIME
SCANNER_RUNTIME = static_evaluator.current_scanner_runtime(SCANNER_RUNTIME_2136)
SCANNER_RUNTIME_CURRENT_UNPATCHED, SCANNER_RUNTIME_NEXT = scanner_adapters(SCANNER_RUNTIME)
SCANNER_RUNTIME_STATIC_CANDIDATE = {
    **SCANNER_RUNTIME_CURRENT_UNPATCHED, 'evaluator_revision': static_evaluator.REVISION,
    'adapter_patch': 'sha256:' + static_evaluator.SCANNER_PATCH,
}
SCANNER_RUNTIME_RETAINED_STATIC = {
    **SCANNER_RUNTIME_CURRENT_UNPATCHED, 'evaluator_revision': static_evaluator.RETAINED['evaluator_revision']
}
SCANNER_2136_INITIAL_STATIC = {
    **SCANNER_2136_INITIAL_UNPATCHED, 'evaluator_revision': static_evaluator.RETAINED['evaluator_revision']
}
SCANNER_2136_STATIC = {
    **SCANNER_RUNTIME_STATIC_CANDIDATE, **SCANNER_2136_UNPATCHED,
}
SCANNER_2136_RETAINED_STATIC = {
    **SCANNER_RUNTIME_RETAINED_STATIC, **SCANNER_2136_UNPATCHED,
}
STATIC_SCANNER_RUNTIMES = (SCANNER_2136_INITIAL_STATIC, SCANNER_2136_STATIC,
                           SCANNER_2136_RETAINED_STATIC, SCANNER_RUNTIME_RETAINED_STATIC,
                           SCANNER_RUNTIME_STATIC_CANDIDATE)
RELEASED_SCANNER_RUNTIMES = (SCANNER_2134_NEXT, SCANNER_2136_INITIAL_NEXT, SCANNER_2136_NEXT, SCANNER_RUNTIME_NEXT,
                             *STATIC_SCANNER_RUNTIMES)
CAVEAT_SCANNER_RUNTIMES = (SCANNER_RUNTIME_PREVIOUS, SCANNER_RUNTIME_2134,
                           SCANNER_RUNTIME_2136_INITIAL, SCANNER_RUNTIME_2136, SCANNER_RUNTIME,
                           *RELEASED_SCANNER_RUNTIMES)
SCANNER_RUNTIMES = (SCANNER_RUNTIME_UNPATCHED, SCANNER_2134_UNPATCHED,
                    SCANNER_2136_INITIAL_UNPATCHED, SCANNER_2136_UNPATCHED, SCANNER_RUNTIME_CURRENT_UNPATCHED,
                    *CAVEAT_SCANNER_RUNTIMES)

ROOT = Path(__file__).resolve().parents[2]
JSON_LIMIT = 8 * 1024 * 1024
NORMALIZATION_LIMIT = 64 * 1024 * 1024
PUBLIC_LIMIT = 1024 * 1024
MAX_CASES = 1000
MAX_TRIALS = 10000
MAX_REFERENCES = 2 * MAX_TRIALS + 100
MAX_SOURCE_MEMBERS = 1000
MAX_INPUT_ENTRIES = 100000
SECURE_DIRECTORY_OUTPUT = (all(fn in os.supports_dir_fd for fn in (os.open, os.mkdir))
                           and all(hasattr(os, name) for name in ('O_DIRECTORY', 'O_NOFOLLOW', 'geteuid')))
# Reviewed Podman extract-manifest.json bytes; additional identities require review.
REVIEWED_EXTRACT_MANIFESTS = frozenset({
    'sha256:4f8ab06638a37c970dfd5a97f057da8505a0b57767a332b41d4e0c2c8e8066ea',
})
# Original-artifact deadlines from the pinned manifest. Serialized availability
# is not evidence of durable retention and cannot override these deadlines.
REVIEWED_REFERENCE_EXPIRY = {
    ('github-artifact-10590172928',
     'sha256:2d384b3c01ac778764fee33943c66a14e011ebcf60fbf266cf1e40880d2e5dca'):
        '2026-10-19T19:11:15Z',
}
require = reports.require


class EvidenceBoundaryError(ValueError):
    """An explicit validation failure at a captured-data or output boundary."""

    def __init__(self, message, boundary):
        super().__init__(message)
        self.boundary = boundary


def boundary_check(boundary):
    def check(condition, message):
        if not condition:
            raise EvidenceBoundaryError(message, boundary)
    return check


def boundary_call(boundary, operation, *args, allow_collision=False, allow_missing=False, **kwargs):
    """Translate known protection/race errors only at a specific OS call."""
    try:
        return operation(*args, **kwargs)
    except OSError as error:
        if allow_collision and isinstance(error, FileExistsError):
            raise  # Only temporary-name collisions retain the existing bounded retry.
        if allow_missing and isinstance(error, FileNotFoundError):
            raise  # The path walker alone decides whether a missing final component is permitted.
        if error.errno in (errno.ENOENT, errno.ENOTDIR, errno.ELOOP, errno.EEXIST, errno.EACCES, errno.EPERM):
            raise EvidenceBoundaryError('Filesystem boundary rejected', boundary) from None
        raise


# Metadata identities from the exact reviewed manifest above, independently
# checked against its pinned bytes by the fixture contract. No execution attestation.
REVIEWED_REFERENCE_IDENTITIES = frozenset({
    'sha256:0079d44b850c03753cc4c5c3664b7c857cdcd20766752b65f3ec1c0666434a4b',
    'sha256:010869aa935d7200789a3b1d14f167b05e87228f36343f20f0d7c457c017b796',
    'sha256:022830f064eed2e50d95cb3d839b38406eb0d29a8a3ee1d17a8ee1dc6e0ad059',
    'sha256:0975698385508c3b95fb545f2d1c6449d51543f9711990eb93d3c70e21a1fa41',
    'sha256:1336bcc8a75421cd8c6ce0712729b2ef60f7656377f113e43a3abfe0091732d1',
    'sha256:1344afa303b2a76b8c92bc334ad3e41c41d58bc474f20f4464406add34cd554b',
    'sha256:1a89e5e4f9b67f55e7bb01280df5c58953298843cf182042e4c1859fce9d0652',
    'sha256:1e0b174d762744fc71e9bb752f1cd8985662afd9c3b092d23f8ea48c676f72dd',
    'sha256:1e72f6533e2d97493c58ba1ed271ede6a2d555d227ab7efc45930faf99d95ba3',
    'sha256:20067f2d75b80658df4d7e7b03c94536b5b868768d488361600553fa87259cf5',
    'sha256:3ea90fcdfbc8162f18ff3deb2862e8129b94a027e5291a0f199cb72781843b8a',
    'sha256:41d2cb2d35e3ec2bd3cefb002a50b2d45fd7338b005a980f37106c0a73f5a0ab',
    'sha256:51e78f9160eb6be7727a6032842703ac1fe5baefd02c78cc77a451a677b432c3',
    'sha256:563e49238fc2c57aa20c2738311c47502d0452704f19f939a9ab9e7346f499c8',
    'sha256:635dcc3a74f006619f76c282d7ea868d6bb15366510da64afd0c96575aa7533b',
    'sha256:676f8c7df2ea2eb4663503ee4993fa0e96750a3df1bf2ef1949df1955fdd75d6',
    'sha256:68fddbd6b3747bf44e10ee231e44c4ac5db7206897473d703a0404c212114883',
    'sha256:6e10eb576317283b058b82d347ea866f5305913a8b89019009852aee186f47fe',
    'sha256:6eec6caf6e2a09aa37dbfa362c9be5fa42bf89b70328ab574d7ae3bd7a52ac2f',
    'sha256:7a19b4c77dab289a4565f73214f26139b1ac46a94967c75daa3d607b45f2b138',
    'sha256:8140ef2dda2da4eeeba0b9390153b0e1e3e7c594a5f1930a19b8c50fe751bb24',
    'sha256:8424e5e2f55758739e1f36719e2495769ed3642a54246805a11af9178cc64c52',
    'sha256:846648a61b269a70ce32f813796f241f0b30c93a8e9882f2b930c2fc8f286577',
    'sha256:86c9f0bc89b89cb8060809f4ba027b41b80e0da92cfe45a98c12f4f69a39e007',
    'sha256:86e0793fea0da9585bccf3c6e3458511a1519c2645f7a9a4f8e0defbdfe17278',
    'sha256:8ea0884d5dc678aa25e45d365ce42355bb1210f3d254b3fea7843bdee8441a5b',
    'sha256:91e1385f672667ff14279ad33474774a8002c8c49b6312ef5fc9ba0fd04936c4',
    'sha256:921caa7779427a8ea2cfb808248355dce9b2064fdf20184a6e94e8817188aa06',
    'sha256:9c99cf006081fcb8d250d18d2c25821ce4f50a01168eca350e814192360ee24f',
    'sha256:9fdbbae4ae978255fd14c2ed9dfb00be3d9812f2c91de5ca498ea9dee3b9e8b9',
    'sha256:a25acc54782d667d087c18dce5df6a8269079e37966174e6c078cf0c70192128',
    'sha256:a552c56679cc259ad7c007abc116d0b59753338d8cc987896454a9d4804ca73f',
    'sha256:a62848fbdd773aa679387a3fc4144f63f61eafd1e4fb3ffd21e512d200975d53',
    'sha256:aa44764dac09b62e048765b524ee8585a85cb0786446bbc10a6fc2474bc9898b',
    'sha256:b81a5d8059b1c7b7c71dccb97a3fea1bfe1b3e6a0db92804c70aedea3c7e7cda',
    'sha256:bac053f37adb00d0179977e45da22c22f80b392373157739e4ee1348973d0972',
    'sha256:bf26e822151bbc5f0feff3ddfe8e553e26d5b4dd0c660c0fe56c00e0a1ed68b3',
    'sha256:c74b685be3405401bc3ab91db9d03eca132addeb59e4b60dba3408a995dd1161',
    'sha256:d21532e67e3f4689889fc392fc68dca8aaa51e9ab42d435b207b20f5e30c8014',
    'sha256:d5856100f6065447d044b219c768049c2bfae71d5ac37f81d30b01cc1160143c',
    'sha256:e2807f8b190a97e929700a047e586631ac8a7ce35b4c02d5facdaf9c0e102795',
    'sha256:e9b57020d90a44fe55f30e05745bd3f4c999e1e60852cac2dffac63f9dd647b5',
    'sha256:ea2d043ad29d3f5ceab40120d0f302ee34341e2f8a7c10a6f3fa419151e56fe1',
    'sha256:ecdf06c011a9106cc74fdf5eb63010538806aa024575710a19ad159b572f2b44',
    'sha256:f0eff6637f6e896afa1d59c8d53ac57e744dba89992e651e7bf735a519103a27',
    'sha256:f317cd3076c986d81a9ae6d28cb3a09b03b8d95419728bcbda9923f739e56e96',
    'sha256:f7b8fb2ef9ccc51564ccdd639094df45a7368ced6bd433c5bd2eb52536401b59',
    'sha256:fd8fe9abe5696b157aae40a758ae66e8f38d539687bc1dec5da587ec6911f688',
})
# Public observation payloads derived from the pinned reviewed extract above.
REVIEWED_OBSERVATION_PAYLOADS = frozenset({
    'sha256:02bf5965fc7878010a2b55be6601cf56cd51a539666023b7292eb09f7d25d6e6',
    'sha256:12671ef8618d82bb05f39d2ad71c0a7c41e42efa5b523805ed90242dc518d050',
    'sha256:16f016601d3a4851399616b4b71e2065c7cf13b435b3ce233171a662f67b400d',
    'sha256:1d8545b95ec03a8e37e87831b285c3a6952b1a4130fd0b9a70c104e3772a7881',
    'sha256:328b62bf137c5a36a61f22065bc612d6b4bc660929f32f4dcf9e8eea7190c381',
    'sha256:439c9872f362e2ef2785ff0d2eb299601b6d0b39a5f87275c16b4d9162194fa9',
    'sha256:6b9f38446da22ecba2d5997565a15ed01e4484e7f234ef12e8b04e2ec4f4454e',
    'sha256:7c7024b7eb902ad097e7dadbf2f7ffb4a22ddb6bef747109180b4db18262ade9',
    'sha256:822155b1b1581748f7c5360265bbaeb6940d47d5678044f692d9bc1a471396e8',
    'sha256:827cf7600e3314a80bf1ce9b781b8f4b5733f640f5f22c5ac922ceca89d87228',
    'sha256:898d8e1fa9ecc58b10d1a60e9493270c8a5cbe2e08e634a5ac4842eb22c9f300',
    'sha256:8ccc3fb74f4cf4214df58ba3ae8b5ce3829b53500645d3238f74eadeeb6a526f',
    'sha256:8cdfe410cfba748438064130b4d4ebad9cd1c11d48c0976ebc14c0e6418d9152',
    'sha256:93bb29af57d0a5510a413dfcff0c9b15472c6513b3876535bb9d86b4d2471fc1',
    'sha256:c4b01a4f7e0703c1a34a4edc02f1ac3ccb9bac4927a72c209e40c7f07a24c059',
    'sha256:cbde5e2ec3cfc413810f1a0b8846652acf7a0a77ed6fa8130291d1081f1b1519',
    'sha256:d446609db87a11e86dfa18a9f7c3fc0eb6e89f8785f563abab348b77073bfd8f',
    'sha256:e8dade88e6e3abb701dd896394f44f0805e048aacc1354f721393008e320dc47',
    'sha256:fe93aaa7437debe16ad1d3c09acb37d672b35ce72d18cfffc9b12ffe0430a27e',
    'sha256:ffea68958116554cfacd0c9eb5f5b292d2f552ae6b3bcfa5232268f0d0f59fdd',
})
OBSERVATION_FIELDS = ('id', 'arm', 'case_id', 'attempt', 'score', 'scores', 'rubric_pass',
                      'deterministic_gate', 'deterministic_scores', 'references')
REVIEWED_METRIC_VALUES = {'Skill Lift': 0.1207, 'Effectiveness': 0.7730,
                         'Correctness': 0.9600, 'Discoverability': 0.6937}
REVIEWED_SOURCE_IDENTITIES = frozenset({
    'sha256:88d1d5eda32819451938ae64f404d2c694aa628039d9045302e627c48107a3b8',
    'sha256:f54436458de3447e2ef95a75db3ea1a4cb59c527515127e633043350629895c7',
})  # Exact historical content, or the same declared identity with unavailable content.
REVIEWED_EXECUTION_CONTRACTS = frozenset({
    'sha256:bffae00bec7b34fcdae64794f39d477b48b0b86adc673d221cf113178ba54c35',
    'sha256:5b1f9b4daa3af1222579cea0bc1055dc1e31d4f8ef2cb96d6ea2993e5a65bf1f',
})  # The pinned run/dataset/policy/arms, with exact or unavailable authored bytes.
PROVENANCE = ('runtime_recorded', 'configured', 'reconstructed_from_declared_revision',
              'reviewed_extract', 'synthetic', 'unknown')
REASONS = ('results_not_supplied', 'coverage_missing', 'execution_incomplete', 'case_details_missing',
           'metadata_missing', 'source_unavailable', 'source_mismatch', 'reference_unavailable',
           'reference_expired', 'scan_incomplete')


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode()


def digest_bytes(value):
    return 'sha256:' + hashlib.sha256(value).hexdigest()


def utc_now():
    return datetime.now(timezone.utc)


def identity(value):
    return digest_bytes(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                   ensure_ascii=True, allow_nan=False).encode())


def depth(value, limit, level=0, seen=None, *, validate=require):
    validate(level <= limit, 'JSON depth exceeded')
    if isinstance(value, (dict, list)):
        seen = {} if seen is None else seen
        # YAML aliases preserve shared containers. Revisit only at a deeper
        # level, bounding work by the depth limit rather than alias paths.
        marker = id(value)
        if seen.get(marker, -1) >= level:
            return
        seen[marker] = level
        for child in value.values() if isinstance(value, dict) else value:
            depth(child, limit, level + 1, seen, validate=validate)
    elif type(value) is float:
        validate(math.isfinite(value), 'Nonfinite JSON number')


def safe_path(path, *, directory=False, missing=False, directory_identities=None, boundary="integrity"):
    require = boundary_check(boundary)
    path = Path(path).absolute()
    require('..' not in path.parts, 'Parent traversal')
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        try:
            info = boundary_call(boundary, current.lstat, allow_missing=True)
        except FileNotFoundError:
            require(missing and current == path, 'Missing input component')
            return path
        require(not stat.S_ISLNK(info.st_mode) and not bool(getattr(info, 'st_file_attributes', 0)
                & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)), 'Linked/reparse input')
        if current != path or directory:
            require(stat.S_ISDIR(info.st_mode), 'Non-directory component')
            if directory_identities is not None:
                observed = (info.st_dev, info.st_ino)
                require(current not in directory_identities or directory_identities[current] == observed,
                        'Input directory changed')
                directory_identities[current] = observed
        else:
            require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, 'Special or hard-linked input')
    return path


def directory_state(info):
    return info.st_mtime_ns, info.st_ctime_ns


def file_state(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


def require_unchanged_member(condition, check, *, phase, role, path, expected, info):
    """Annotate the original rejection using only closed diagnostic vocabularies.

    Identity differences compare the retained five-field snapshot. Type/link
    diagnostics describe the regular, single-link input requirement; those
    properties are not part of the retained snapshot. Never reread the input.
    """
    try:
        check(condition, 'Input member changed')
    except ValueError as error:
        if not condition:
            try:
                fields = ('device', 'inode', 'size', 'mtime', 'ctime')
                observed = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
                changed = [name for name, before, after in zip(fields, expected, observed) if before != after]
                types = {stat.S_IFREG: 'regular', stat.S_IFDIR: 'directory', stat.S_IFLNK: 'symlink',
                         stat.S_IFIFO: 'fifo', stat.S_IFSOCK: 'socket', stat.S_IFCHR: 'device', stat.S_IFBLK: 'device'}
                observed_type = types.get(stat.S_IFMT(info.st_mode), 'other')
                links = 'single' if info.st_nlink == 1 else 'zero' if info.st_nlink == 0 else 'multiple'
                failed = ([] if stat.S_ISREG(info.st_mode) else ['file_type']) + ([] if info.st_nlink == 1 else ['link_count'])
                member_role = role(path) if callable(role) else role
                note = {'phase': phase if type(phase) is str and phase in {'member_revalidation', 'repository_revalidation', 'tree_capture',
                                                    'read_open', 'read_complete', 'inventory_presence'} else 'unknown',
                        'role': member_role if type(member_role) is str and member_role in {'input_file', 'git_metadata', 'git_reference', 'git_object_store'} else 'unknown',
                        'changed_fields': changed, 'failed_requirements': failed,
                        'observed_type': observed_type, 'observed_links': links}
                diagnostic = 'Input member diagnostic: ' + json.dumps(note, sort_keys=True, separators=(',', ':'))
            except Exception:
                # Diagnostic failure must not replace the original integrity rejection.
                diagnostic = 'Input member diagnostic: unavailable'
            error.add_note(diagnostic)
        raise


def verify_file_states(states, directories, directory_states, paths=None, *,
                       phase="member_revalidation", role="input_file"):
    require = boundary_check("integrity")
    fd = None
    parent = None
    try:
        for path in states if paths is None else paths:
            if path.parent != parent:
                if fd is not None:
                    os.close(fd); fd = None
                fd = open_directory(path.parent, directories, directory_states=directory_states)
                parent = path.parent
            info = boundary_call("integrity", os.stat, path.name, dir_fd=fd, follow_symlinks=False)
            require_unchanged_member(
                stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and file_state(info) == states[path], require,
                phase=phase, role=role, path=path, expected=states[path], info=info)
    finally:
        if fd is not None: os.close(fd)


def verify_directory_states(states, identities, paths=None):
    paths = states if paths is None else paths
    for path in paths:
        fd = open_directory(path, identities, directory_states=states)
        os.close(fd)


def safe_tree(path, *, max_entries=MAX_INPUT_ENTRIES, max_files=None, directory_identities=None, directory_states=None, file_states=None, native_layout_skill=None, member_role="input_file"):
    if directory_identities is None:
        directory_identities = {}
    if directory_states is None:
        directory_states = {}
    if file_states is None:
        file_states = {}
    path = safe_path(path, directory=True, directory_identities=directory_identities)
    pending = [path]
    files = []
    scanned = []
    seen = 0
    while pending:
        current = pending.pop()
        fd = open_directory(current, directory_identities, directory_states=directory_states)
        try:
            observed = directory_state(os.fstat(fd))
            require(current not in directory_states or directory_states[current] == observed,
                    'Input directory entries changed')
            directory_states[current] = observed
            scanned.append(current)
            with os.scandir(fd) as entries:
                for entry in entries:
                    seen += 1
                    require(seen <= max_entries, 'Input tree entry limit')
                    info = entry.stat(follow_symlinks=False)
                    directory = stat.S_ISDIR(info.st_mode)
                    parts = (current / entry.name).relative_to(path).parts
                    linked = stat.S_ISLNK(info.st_mode) or bool(getattr(info, 'st_file_attributes', 0)
                        & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400))
                    if native_layout_skill is not None and parts == ('results', native_layout_skill, 'latest'):
                        require(linked, 'Expected native latest alias')
                        continue  # Never resolve or inspect the generated alias.
                    if (native_layout_skill is not None and len(parts) == 4
                            and parts[:2] == ('results', native_layout_skill)
                            and parts[2] != 'latest' and parts[3] in ('_harbor-jobs', '_harbor-tasks')):
                        require(directory and not linked, 'Invalid native runtime directory')
                        continue  # Ordinary per-run runtime contents are not evidence inputs.
                    member = safe_path(current / entry.name, directory=directory, directory_identities=directory_identities)
                    if directory:
                        pending.append(member)
                    else:
                        require(max_files is None or len(files) < max_files, 'Input tree entry limit')
                        observed_file = file_state(info)
                        require_unchanged_member(member not in file_states or file_states[member] == observed_file, require,
                            phase='tree_capture', role=member_role, path=member,
                            expected=file_states.get(member, observed_file), info=info)
                        file_states[member] = observed_file
                        files.append(member)
            require(directory_state(os.fstat(fd)) == directory_states[current], 'Input directory entries changed')
        finally:
            os.close(fd)
    verify_directory_states(directory_states, directory_identities, scanned)
    verify_file_states(file_states, directory_identities, directory_states, files, role=member_role)
    return files


class ReadBudget:
    def __init__(self):
        self.remaining = NORMALIZATION_LIMIT
        self.repository_inputs = []
        self.repository_locations = {}
        self.repository_depth = 0

    def consume(self, size):
        require(0 <= size <= self.remaining, 'Normalization byte limit')
        self.remaining -= size

    def verify_repository(self):
        for directories, states, members in self.repository_inputs:
            verify_directory_states(states, directories)
            verify_file_states(members, directories, states, phase='repository_revalidation', role=self.member_role)

    def member_role(self, path):
        for gitdir, common in self.repository_locations.values():
            if path.is_relative_to(common / 'objects'):
                return 'git_object_store'
            if any(path.is_relative_to(root / name) for root in (gitdir, common) for name in ('refs', 'reftable')):
                return 'git_reference'
        return 'git_metadata'

    @contextmanager
    def repository_operation(self):
        outer = self.repository_depth == 0
        if outer: self.verify_repository()
        self.repository_depth += 1
        try:
            yield
        finally:
            self.repository_depth -= 1
        # A failed read cannot publish; retain its original bounded rejection.
        if outer: self.verify_repository()


def read_bytes(path, limit=JSON_LIMIT, *, budget=None, directory_identities=None, directory_states=None, file_states=None, member_role="input_file"):
    require = boundary_check("integrity")
    if directory_identities is None:
        directory_identities = {}
    path = safe_path(path, directory_identities=directory_identities)
    require(SECURE_DIRECTORY_OUTPUT, 'Secure directory input unsupported')
    # O_NONBLOCK avoids hanging if a file is replaced by a FIFO between checks.
    parent_fd = open_directory(path.parent, directory_identities, directory_states=directory_states)
    try:
        fd = boundary_call("integrity", os.open, path.name,
                           os.O_RDONLY | os.O_NOFOLLOW | getattr(os, 'O_NONBLOCK', 0), dir_fd=parent_fd)
    finally:
        os.close(parent_fd)
    with os.fdopen(fd, 'rb') as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= limit,
                'Special, hard-linked or oversized input')
        if file_states is not None:
            observed = file_state(info)
            require_unchanged_member(path not in file_states or file_states[path] == observed, require,
                phase='read_open', role=member_role, path=path, expected=file_states.get(path, observed), info=info)
            file_states[path] = observed
        if budget is not None:
            budget.consume(info.st_size)
        value = stream.read(min(limit, info.st_size + budget.remaining) + 1 if budget is not None else limit + 1)
        if file_states is not None:
            final_info = os.fstat(stream.fileno())
            require_unchanged_member(file_state(final_info) == observed, require,
                phase='read_complete', role=member_role, path=path, expected=observed, info=final_info)
    require(len(value) <= limit, 'Oversized input')
    if budget is not None:
        budget.consume(max(0, len(value) - info.st_size))
    return value


def parse_json(raw, *, limit=None):
    require = boundary_check("json")
    limit = JSON_LIMIT if limit is None else limit
    require(type(limit) is int and limit > 0, 'Invalid JSON limit')
    require(type(raw) is bytes and len(raw) <= limit, 'Invalid bounded JSON')
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    try:
        value = json.loads(raw, object_pairs_hook=pairs,
                           parse_constant=lambda _: require(False, 'Nonfinite JSON number'))
        depth(value, 32, validate=require)
        return value
    except (RecursionError, UnicodeError, json.JSONDecodeError):
        raise EvidenceBoundaryError('Invalid bounded JSON', 'json') from None


def read_json(path):
    return parse_json(read_bytes(path))


def read_json_and_digest(path, *, budget=None, directory_identities=None, directory_states=None, file_states=None):
    raw = read_bytes(path, budget=budget, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)
    return parse_json(raw), digest_bytes(raw)


def read_yaml(path, *, reader=None):
    import yaml
    if reader is None:
        reader = read_bytes
    class UniqueLoader(yaml.SafeLoader):
        pass
    def mapping(loader, node):
        result = {}
        for key_node, value_node in node.value:
            key = loader.construct_object(key_node)
            require(type(key) is str and key not in result, 'Ambiguous YAML key')
            result[key] = loader.construct_object(value_node)
        return result
    UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, mapping)
    try:
        value = yaml.load(reader(path), Loader=UniqueLoader)
        depth(value, 32)
        return value
    except (yaml.YAMLError, RecursionError) as exc:
        raise ValueError('Invalid bounded YAML metadata') from exc


def closed(value, fields):
    require(type(value) is dict and set(value) == set(fields), 'Unexpected or missing fields')


def token(value):
    require(type(value) is str and bool(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._+~:-]{0,127}', value)),
            'Invalid identifier')


def skill_id(value):
    require(type(value) is str and len(value) <= 64
            and bool(re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', value)), 'Invalid skill ID')


def relative(value):
    require(type(value) is str and len(value) <= 512 and '\\' not in value, 'Invalid relative member')
    parts = value.split('/')
    require(not PurePosixPath(value).is_absolute() and all(p not in ('', '.', '..') for p in parts),
            'Escaping relative member')
    for part in parts:
        require(bool(re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', part)), 'Unsafe member component')
        require(not part.endswith('.') and part.split('.', 1)[0].upper() not in
                {'CON', 'PRN', 'AUX', 'NUL', *('COM' + str(i) for i in range(1, 10)),
                 *('LPT' + str(i) for i in range(1, 10))}, 'Cross-platform unsafe member')


def sha(value):
    require(type(value) is str and bool(re.fullmatch(r'sha256:[0-9a-f]{64}', value)), 'Invalid SHA256')


def revision(value):
    require(type(value) is str and bool(re.fullmatch(r'[0-9a-f]{40}', value)), 'Invalid revision')


def repository(value):
    require(type(value) is str and bool(re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', value)),
            'Invalid repository')


def number(value, low=0, high=1):
    require(type(value) in (int, float) and low <= value <= high
            and (type(value) is int or math.isfinite(value)),
            'Invalid numeric observation')


def count(value, maximum=MAX_TRIALS):
    require(type(value) is int and 0 <= value <= maximum, 'Invalid count')


def boolean(value):
    require(type(value) is bool, 'Invalid boolean')


def enum(value, values):
    require(value in values and type(value) is str, 'Invalid enum')


def optional(value, validator):
    if value is not None:
        validator(value)


def case_ids(values):
    from skillevaluator.tier3.case_ids import validate_case_ids
    require(type(values) is list and len(values) <= MAX_CASES, 'Case limit exceeded')
    canonical = validate_case_ids(values)
    require(canonical == values, 'Noncanonical case ID')
    return canonical


def validate_content(value):
    closed(value, ('digest', 'algorithm', 'scope', 'provenance', 'manifest'))
    optional(value['digest'], sha)
    enum(value['algorithm'], ('sha256-relative-file-manifest-v1',))
    enum(value['scope'], ('pinned-agent-visible',))
    enum(value['provenance'], PROVENANCE)
    require(type(value['manifest']) is list and len(value['manifest']) <= MAX_SOURCE_MEMBERS, 'Manifest limit')
    names = []
    for row in value['manifest']:
        closed(row, ('member', 'digest'))
        relative(row['member']); sha(row['digest']); names.append(row['member'])
    require(names == sorted(set(names)), 'Ambiguous content manifest')
    require(len({n.casefold() for n in names}) == len(names), 'Content member case collision')
    if value['digest'] is not None:
        require('SKILL.md' in names, 'Skill content missing root SKILL.md')
        require(value['digest'] == identity(value['manifest']), 'Content manifest mismatch')
    else:
        require(not names and value['provenance'] == 'unknown', 'Unknown content has manifest')


def content(manifest=(), provenance='unknown'):
    manifest = sorted(manifest, key=lambda row: row['member'])
    return {'digest': identity(manifest) if provenance != 'unknown' else None,
            'algorithm': 'sha256-relative-file-manifest-v1', 'scope': 'pinned-agent-visible',
            'provenance': provenance, 'manifest': manifest}


def skill_projection_files(path, files, *, directory_identities=None, directory_states=None):
    if directory_identities is not None and directory_states is None:
        for directory in directory_identities:
            if directory.is_relative_to(path):
                safe_path(directory, directory=True, directory_identities=directory_identities)
    if directory_states is not None:
        verify_directory_states(directory_states, directory_identities,
                                (directory for directory in directory_states if directory.is_relative_to(path)))
    # Match the pinned runtime's ordinary source boundary using captured names.
    # Its filesystem callback authenticates generated outputs and can load a
    # private key; generated markers are rejected separately, never authenticated.
    names = {p.relative_to(path).as_posix() for p in files}
    return [p for p in files if agent_visible_member(p.relative_to(path).as_posix(), names)]


def agent_visible_member(name, names):
    parts = PurePosixPath(name).parts
    if any(part in ('results', '__pycache__', '.git') for part in parts): return False
    return not any(part.casefold() == 'evals' and (i == 0 or i < len(parts) - 1 and any(
        '/'.join((*parts[:i], manifest)) in names for manifest in ('SKILL.md', 'skill.md')))
        for i, part in enumerate(parts))


def skill_content(path, *, reader=None, directory_identities=None, directory_states=None, file_states=None):
    directories = {} if directory_identities is None else directory_identities
    states = {} if directory_states is None else directory_states
    members = {} if file_states is None else file_states
    files = safe_tree(path, max_entries=2 * MAX_SOURCE_MEMBERS, max_files=MAX_SOURCE_MEMBERS,
                      directory_identities=directories, directory_states=states, file_states=members)
    reject_source_markers(path, files, directories)
    if reader is None:
        budget = ReadBudget()
        reader = lambda member: read_bytes(member, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
    safe_path(path, directory=True, directory_identities=directories)
    result = content([{'member': p.relative_to(path).as_posix(), 'digest': digest_bytes(reader(p))}
                     for p in skill_projection_files(path, files, directory_identities=directories, directory_states=states)], 'configured')
    verify_directory_states(states, directories,
                            (directory for directory in states if directory.is_relative_to(path)))
    verify_file_states(members, directories, states, files)
    return result


def reject_source_markers(path, files, directories):
    from skillevaluator.tier3.output_provenance import GENERATED_OUTPUT_MARKER
    marked = (any(p.name == GENERATED_OUTPUT_MARKER for p in files)
              or any(p.name == GENERATED_OUTPUT_MARKER and p.is_relative_to(Path(path).absolute()) for p in directories))
    require(not marked, 'Generated output inside inventory source')


def validate_source(value):
    closed(value, ('skill_id', 'owner', 'repository', 'revision', 'source_path', 'lineage', 'content'))
    skill_id(value['skill_id']); enum(value['owner'], ('local', 'upstream', 'unknown'))
    optional(value['repository'], repository); optional(value['revision'], revision)
    optional(value['source_path'], relative)
    if value['lineage'] is not None:
        closed(value['lineage'], ('repository', 'revision', 'source_path'))
        repository(value['lineage']['repository']); revision(value['lineage']['revision'])
        relative(value['lineage']['source_path'])
    validate_content(value['content'])


def source(name, owner='unknown', repo=None, rev=None, path=None, contents=None, lineage=None):
    return {'skill_id': name, 'owner': owner, 'repository': repo, 'revision': rev,
            'source_path': path, 'lineage': lineage, 'content': contents or content()}


def offline_git_environment():
    # Git's repository-local environment (rev-parse --local-env-vars), plus
    # discovery/namespace selectors, must not redirect the requested checkout.
    selectors = {'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_CONFIG', 'GIT_CONFIG_PARAMETERS',
                 'GIT_CONFIG_COUNT', 'GIT_OBJECT_DIRECTORY', 'GIT_DIR', 'GIT_WORK_TREE',
                 'GIT_IMPLICIT_WORK_TREE', 'GIT_GRAFT_FILE', 'GIT_INDEX_FILE', 'GIT_REPLACE_REF_BASE',
                 'GIT_PREFIX', 'GIT_SHALLOW_FILE', 'GIT_COMMON_DIR', 'GIT_NAMESPACE',
                 'GIT_CEILING_DIRECTORIES', 'GIT_DISCOVERY_ACROSS_FILESYSTEM'}
    env = {key: value for key, value in os.environ.items()
           if key not in selectors and not key.startswith(('GIT_CONFIG_KEY_', 'GIT_CONFIG_VALUE_', 'GIT_TRACE'))}
    # Trace2 can also inherit global/system targets. Explicitly disable all
    # targets rather than allowing an unset environment to fall back to them.
    env.update(GIT_NO_LAZY_FETCH='1', GIT_NO_REPLACE_OBJECTS='1',
               GIT_TRACE='0', GIT_TRACE2='0', GIT_TRACE2_PERF='0', GIT_TRACE2_EVENT='0')
    return env


def offline_git(workspace, *args, text=False, max_entries=None, budget=None):
    budget = ReadBudget() if budget is None else budget
    workspace = Path(workspace).absolute()
    if workspace not in budget.repository_locations:
        workspace_repository(workspace, budget=budget)
    if workspace not in budget.repository_locations:
        return subprocess.CompletedProcess(['git', *args], 1, '' if text else b'', '' if text else b'')
    with budget.repository_operation():
        return run_offline_git(workspace, *args, text=text, max_entries=max_entries, budget=budget)


def run_offline_git(workspace, *args, text=False, max_entries=None, budget=None):
    # Missing promisor objects stay unknown; replacement refs cannot alter exact evidence.
    command = ['git', '-C', str(workspace), *args]
    env = offline_git_environment()
    blob = args[:2] == ('cat-file', 'blob')
    if max_entries is None and not blob:
        return subprocess.run(command, capture_output=True, text=text, env=env)
    require(not text, 'Binary Git capture required')
    # Bound listings and blobs while reading, including growth after cat-file -s.
    # Discard diagnostics so a blocked stderr pipe cannot stall the bounded read.
    byte_limit = min(JSON_LIMIT, budget.remaining) if budget is not None else JSON_LIMIT
    with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, env=env, bufsize=0) as process:
        output = bytearray()
        entries = 0
        try:
            while chunk := process.stdout.read(min(4096, byte_limit - len(output) + 1)):
                if max_entries is not None:
                    entries += chunk.count(b'\0')
                    require(entries <= max_entries, 'Historical tree listing limit')
                require(len(output) + len(chunk) <= JSON_LIMIT,
                        'Oversized historical blob' if blob else 'Historical tree listing limit')
                if budget is not None:
                    budget.consume(len(chunk))
                output.extend(chunk)
            returncode = process.wait()
        finally:
            if process.poll() is None:
                process.kill()
    return subprocess.CompletedProcess(command, returncode, bytes(output), b'')


def git_revision(workspace):
    return resolve_git_revision(workspace, ReadBudget())


def resolve_git_revision(workspace, budget):
    result = offline_git(workspace, 'rev-parse', 'HEAD', text=True, budget=budget)
    return result.stdout.strip() if result.returncode == 0 else None


def workspace_repository(workspace, *, budget=None):
    """Associate local objects with a canonical origin, without remote attestation."""
    budget = ReadBudget() if budget is None else budget
    directories = {}; states = {}; members = {}
    workspace = safe_path(workspace, directory=True, directory_identities=directories)
    budget.repository_inputs.append((directories, states, members))
    def inspect(path, *, track_parent=True):
        safe_path(path.parent, directory=True, directory_identities=directories)
        fd = open_directory(path.parent, directories, directory_states=states)
        try:
            parent_state = directory_state(os.fstat(fd))
            if track_parent:
                states.setdefault(path.parent, parent_state)
            try:
                info = os.stat(path.name, dir_fd=fd, follow_symlinks=False)
            except FileNotFoundError:
                states.setdefault(path.parent, parent_state)
                budget.verify_repository()
                return None
            require(stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode), 'Unsafe Git metadata')
            if stat.S_ISREG(info.st_mode):
                members[path] = file_state(info)
            else:
                directories[path] = (info.st_dev, info.st_ino)
                states[path] = directory_state(info)
            return info
        finally:
            os.close(fd)
    def captured(path, limit=JSON_LIMIT):
        return read_bytes(path, limit=limit, budget=budget, directory_identities=directories,
                          directory_states=states, file_states=members, member_role="git_metadata")
    def pointer(parent, raw):
        text = raw.decode('utf-8').removesuffix('\n')
        require(text and '\n' not in text and '\0' not in text, 'Invalid Git metadata pointer')
        return Path(os.path.abspath(parent / text))
    gitdir = workspace / '.git'
    info = inspect(gitdir, track_parent=False)
    if info is None:
        return None
    linked = stat.S_ISREG(info.st_mode)
    if linked:
        raw = captured(gitdir, 4096)
        require(raw.startswith(b'gitdir: '), 'Invalid Git metadata pointer')
        gitdir = pointer(workspace, raw[len(b'gitdir: '):])
        back_pointer = gitdir / 'gitdir'
        if inspect(back_pointer) is None:
            return None
        associated = pointer(gitdir, captured(back_pointer, 4096)) == workspace / '.git'
        budget.verify_repository()
        if not associated:
            return None
    common = gitdir
    common_pointer = gitdir / 'commondir'
    if inspect(common_pointer) is not None:
        common = pointer(gitdir, captured(common_pointer, 4096))
    if (linked and (common == gitdir or gitdir.parent != common / 'worktrees')) or (not linked and common != gitdir):
        budget.verify_repository()
        return None
    config = common / 'config'
    if inspect(config) is None:
        return None
    raw_config = captured(config)
    budget.repository_locations[workspace] = (gitdir, common)
    # Clearing the environment does not disable repository-local alternates.
    # Anchor the object-store path and the absence of alternate lists, including
    # a missing info directory, for every subsequent Git read and publication.
    objects = common / 'objects'
    info = inspect(objects)
    require(info is not None and stat.S_ISDIR(info.st_mode), 'Unsafe Git object store')
    info = inspect(objects / 'info')
    if info is not None:
        require(stat.S_ISDIR(info.st_mode), 'Unsafe Git object store')
        for name in ('alternates', 'http-alternates'):
            require(inspect(objects / 'info' / name) is None, 'Alternate Git object store')
    # Git follows links below objects too (pack files, indexes and loose fanout
    # directories). Capture the complete bounded structure, not just selectors.
    safe_tree(objects, max_entries=MAX_INPUT_ENTRIES, directory_identities=directories,
              directory_states=states, file_states=members, member_role="git_object_store")
    # Git parses only the captured buffer. Includes and ambient repository
    # configuration cannot substitute another origin after the bounded read.
    result = subprocess.run(['git', 'config', '--file', '-', '--no-includes', '--null',
                             '--get-all', 'remote.origin.url'], input=raw_config,
                            capture_output=True, env=offline_git_environment())
    budget.verify_repository()
    if result.returncode:
        return None
    raw = result.stdout
    require(len(raw) <= 4096 and raw.count(b'\0') <= 1, 'Repository identity limit')
    # Read the literal common-repository config (also for linked worktrees),
    # without inherited config, includes, URL rewrites, credentials or fetching.
    match = re.fullmatch(rb'(?:https://github\.com/|ssh://git@github\.com/|git@github\.com:)'
                         rb'([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+?)(?:\.git)?\x00', raw, re.IGNORECASE)
    if match is None:
        return None
    repo = match[1].decode('ascii').lower()
    return repo if all(part not in ('.', '..') for part in repo.split('/')) else None


def inventory_revision(workspace, budget):
    """Anchor native Git reference storage before resolving the inventory HEAD."""
    directories = {}; states = {}; members = {}
    budget.repository_inputs.append((directories, states, members))
    for root in dict.fromkeys(budget.repository_locations[workspace]):
        safe_path(root, directory=True, directory_identities=directories)
        fd = open_directory(root, directories, directory_states=states)
        try:
            states.setdefault(root, directory_state(os.fstat(fd)))
            for name in ('HEAD', 'packed-refs', 'refs', 'reftable'):
                path = root / name
                try:
                    info = os.stat(name, dir_fd=fd, follow_symlinks=False)
                except FileNotFoundError:
                    continue  # The retained parent state also guards absent storage.
                if stat.S_ISDIR(info.st_mode):
                    require(name in ('refs', 'reftable'), 'Unsafe Git reference storage')
                    files = safe_tree(path, directory_identities=directories,
                                      directory_states=states, file_states=members, member_role="git_reference")
                else:
                    require(stat.S_ISREG(info.st_mode) and name in ('HEAD', 'packed-refs'),
                            'Unsafe Git reference storage')
                    members[path] = file_state(info); files = [path]
                require(len(directories) + len(members) <= MAX_INPUT_ENTRIES, 'Git reference entry limit')
                for member in files:
                    read_bytes(member, budget=budget, directory_identities=directories,
                               directory_states=states, file_states=members, member_role="git_reference")
        finally:
            os.close(fd)
    budget.verify_repository()
    rev = resolve_git_revision(workspace, budget)
    budget.verify_repository()
    return rev


def associated_repository(workspace, declared, *, budget):
    optional(declared, repository)
    actual = workspace_repository(workspace, budget=budget)
    require(actual is None or declared is None or actual == declared.lower(),
            'Declared repository conflicts with workspace origin')
    return actual if declared is not None else None


def historical_commit(workspace, rev):
    return checked_historical_commit(workspace, rev, ReadBudget())


def checked_historical_commit(workspace, rev, budget):
    revision(rev)
    kind = offline_git(workspace, 'cat-file', '-t', rev, text=True, budget=budget)
    if kind.returncode:
        return False
    require(kind.stdout.strip() == 'commit', 'Historical revision must be a commit')
    return True


def historical_blob(workspace, spec, *, budget=None):
    """Bound exact local object bytes before capturing content; missing stays unknown."""
    budget = ReadBudget() if budget is None else budget
    with budget.repository_operation():
        return captured_historical_blob(workspace, spec, budget)


def captured_historical_blob(workspace, spec, budget):
    if ':' in spec:
        rev, member = spec.split(':', 1)
        relative(member)
        if not checked_historical_commit(workspace, rev, budget):
            return None
    kind = offline_git(workspace, 'cat-file', '-t', spec, text=True, budget=budget)
    if kind.returncode:
        return None
    require(kind.stdout.strip() == 'blob', 'Historical member must be a blob')
    size = offline_git(workspace, 'cat-file', '-s', spec, text=True, budget=budget)
    if size.returncode:
        return None
    size = int(size.stdout.strip())
    require(0 <= size <= JSON_LIMIT, 'Oversized historical blob')
    require(size <= budget.remaining, 'Normalization byte limit')
    blob = offline_git(workspace, 'cat-file', 'blob', spec, budget=budget)
    if blob.returncode:
        return None
    require(len(blob.stdout) <= JSON_LIMIT, 'Oversized historical blob')
    return blob.stdout


def historical_content(workspace, rev, source_path, *, budget=None):
    """Read exact local Git blobs only. Never checkout or contact a remote."""
    budget = ReadBudget() if budget is None else budget
    with budget.repository_operation():
        return captured_historical_content(workspace, rev, source_path, budget)


def captured_historical_content(workspace, rev, source_path, budget):
    relative(source_path)
    if not checked_historical_commit(workspace, rev, budget):
        return content()
    listing = offline_git(workspace, 'ls-tree', '-rz', rev, '--', source_path,
                          max_entries=MAX_SOURCE_MEMBERS, budget=budget)
    if listing.returncode:
        return content()
    rows = listing.stdout.split(b'\0')
    filenames = [row.split(b'\t', 1)[1].decode() for row in rows if row]
    if not filenames:
        return content()
    prefix = source_path + '/'
    require(all(filename.startswith(prefix) for filename in filenames), 'Historical source must be a directory')
    tree_names = {filename[len(prefix):] for filename in filenames}
    require('SKILL.md' in tree_names, 'Historical skill root missing SKILL.md')
    from skillevaluator.tier3.output_provenance import GENERATED_OUTPUT_MARKER
    require(not any(GENERATED_OUTPUT_MARKER in PurePosixPath(name).parts for name in tree_names),
            'Generated output inside historical source')
    members = []
    for row in rows:
        if not row:
            continue
        header, filename = row.split(b'\t', 1)
        mode, kind, oid = header.split()
        require(mode == b'100644' or mode == b'100755', 'Unsafe historical source tree')
        require(kind == b'blob', 'Special historical source')
        name = filename.decode()[len(prefix):]
        relative(name)
        members.append((name, oid.decode()))
    records = []
    for name, oid in members:
        # Same root/nested skill eval boundary as the pinned runtime; generated
        # outputs are never accepted as historical authored source.
        if not agent_visible_member(name, tree_names):
            continue
        blob = historical_blob(workspace, oid, budget=budget)
        if blob is None:
            return content()
        records.append({'member': name, 'digest': digest_bytes(blob)})
    if not records:
        return content()
    return content(records, 'reconstructed_from_declared_revision')


class CapturedInput:
    """Bounded captured-tree path surface for the pinned native validators."""
    def __init__(self, path, reader, *, entries, directories, children=None):
        self.path = path
        self.reader = reader
        self.entries = frozenset(entries)
        self.directories = frozenset(directories)
        if children is None:
            index = {}
            for member in self.entries:
                index.setdefault(member.parent, []).append(member)
            children = {parent: tuple(members) for parent, members in index.items()}
        self.children = children

    def at(self, path):
        return CapturedInput(path, self.reader, entries=self.entries,
                             directories=self.directories, children=self.children)

    def __str__(self):
        return str(self.path)

    def __truediv__(self, member):
        return self.at(self.path / member)

    def __lt__(self, other):
        if not isinstance(other, CapturedInput):
            return NotImplemented
        return self.path < other.path

    @property
    def parent(self):
        return self.at(self.path.parent)

    @property
    def name(self):
        return self.path.name

    @property
    def suffix(self):
        return self.path.suffix

    def exists(self):
        return self.path in self.entries

    def is_dir(self):
        return self.path in self.directories

    def iterdir(self):
        require(self.is_dir(), 'Captured directory required')
        return (self.at(member) for member in self.children.get(self.path, ()))

    def stat(self):
        return SimpleNamespace(st_size=len(self.reader(self.path)))

    def read_text(self, encoding='utf-8', errors='strict'):
        return self.reader(self.path).decode(encoding, errors)


def strict_dataset(path, name, *, reader=None, directory_identities=None, directory_states=None, file_states=None):
    from skillevaluator.tier3.dataset_utils import normalize_dataset_entries
    from skillevaluator.tier3 import evals_spec as native_spec
    directories = {} if directory_identities is None else directory_identities
    states = {} if directory_states is None else directory_states
    members = {} if file_states is None else file_states
    files = safe_tree(path.parent.parent, directory_identities=directories, directory_states=states, file_states=members)
    captured_directories = frozenset(directory for directory in directories if directory.is_relative_to(path.parent.parent))
    tree_entries = frozenset(files) | captured_directories
    alternatives = [member for member in tree_entries if member.parent == path.parent and member.name.startswith('evals.')]
    require(path.name == 'evals.json' and set(alternatives) == {path}, 'Ambiguous authored dataset formats')
    if reader is None:
        reader = lambda member: read_bytes(member, directory_identities=directories, directory_states=states, file_states=members)
    captured = {}
    def optional_reader(member):
        require(member in tree_entries, 'Uncaptured native input')
        if member not in captured:
            captured[member] = reader(member)
        return captured[member]
    raw = optional_reader(path)
    data = parse_json(raw)
    require(type(data) is dict, 'Dataset object required')
    require(type(data.get('evals')) is list and len(data['evals']) <= MAX_CASES, 'Dataset case limit')
    require(type(data) is dict and data.get('skill_name') == name, 'Dataset skill mismatch')
    if installed_version('skillevaluator') == static_evaluator.VERSION:
        # Apply the release's authored-field rules before normalization can mask invalid values.
        require(all(type(entry) is dict and not native_spec._dataset_field_type_errors(entry)
                    for entry in data['evals']), 'Strict dataset contract failed')
    entries = normalize_dataset_entries(data)
    # The pinned path-based validator reopens the dataset. Apply its agentskills
    # checks to this buffer, retaining its optional-file checks separately.
    require(entries and all(native_spec.AGENTSKILLS_REQUIRED_FIELDS <= entry.keys() for entry in entries),
            'Strict dataset contract failed')
    from skillevaluator.tier3.case_ids import validate_case_ids
    ids = validate_case_ids(entry['id'] for entry in entries)
    case_ids(ids)
    checks = []
    captured_tree = CapturedInput(path.parent.parent, optional_reader, entries=tree_entries,
                                 directories=captured_directories)
    for spec in native_spec.EVALS_SPEC:
        if spec.rel_path == 'evals/evals.json' or spec.scope == native_spec.Scope.OUTPUT \
                or '<subdirs>' in spec.rel_path or spec.kind == 'dir':
            continue
        target = path.parent.parent / spec.rel_path
        if target in tree_entries:
            # Capture before invoking validators that may catch parse/read errors.
            optional_reader(target)
            if spec.rel_path in ('evals/config.yml', 'evals/config.yaml') and static_evaluator.is_owner():
                # The released validator opens configs through SecureRoot.
                # Use its parser on the confined bytes already captured above.
                static_evaluator.validate_captured_config(captured_tree)
            else:
                native_spec._run_file_checks(captured_tree.at(target), spec, checks)
    native_spec._check_unrecognised(captured_tree, checks)
    require(all(row.status == 'ok' for row in checks), 'Strict dataset contract failed')
    for entry in entries:
        for member in entry.get('files', []):
            relative(member)
            require(member.startswith('evals/files/'), 'Input outside evaluator fixture boundary')
            safe_path(path.parent.parent / member, directory_identities=directories)
    verify_directory_states(states, directories,
                            (directory for directory in states if directory.is_relative_to(path.parent.parent)))
    verify_file_states(members, directories, states, files)
    return {'owner': 'unknown',
            'path': None, 'authored_digest': digest_bytes(raw),
            'case_ids': sorted(ids), 'status': 'configured'}


def validate_skill_metadata(authored, name, *, reader=None):
    import yaml as metadata_yaml
    if reader is None:
        reader = read_bytes
    text = reader(authored / 'SKILL.md').decode()
    require(text.startswith('---\n') and '\n---' in text[4:], 'Missing skill metadata')
    # Front matter is bounded and duplicate-key ambiguity must not choose an owner.
    front = text.split('---', 2)[1]
    try:
        pairs = metadata_yaml.compose(front)
        metadata = metadata_yaml.safe_load(front)
    except (metadata_yaml.YAMLError, RecursionError) as exc:
        raise ValueError('Invalid skill metadata') from exc
    require(pairs is not None and isinstance(pairs, metadata_yaml.MappingNode), 'Invalid skill metadata')
    keys = [key.value for key, _ in pairs.value]
    require(len(keys) == len(set(keys)), 'Ambiguous skill metadata')
    require(type(metadata) is dict and metadata.get('name') == name
            and type(metadata.get('description')) is str and metadata['description'].strip(), 'Invalid skill metadata')
    from skillevaluator.models.skill import SkillFrontmatter
    SkillFrontmatter(**metadata)


def validate_captured_gh(workspace, owner, actual, owners, competing_files, entries, reader):
    """Apply gh-specific contracts to the bounded inventory, without tree rescans."""
    import gh_evaluations as gh
    require(owner['repo_url'] == 'cli/cli' and owner['virtual_path'] == 'skills/gh'
            and owner['resolved_commit'] == gh.UPSTREAM, 'Unreviewed gh upstream ownership or revision')
    require(set(actual) == {(gh.DEPLOYED / name).as_posix() for name in gh.SKILL_FILES}, 'Unreviewed upstream gh file set')
    competing = owners.get(gh.COMPETING, [])
    require(len(competing) == 1 and competing[0]['repo_url'] == 'github/awesome-copilot'
            and competing[0]['resolved_commit'] == reports.benchmark_policy('gh')['competing_revision'],
            'Unreviewed competing skill identity')
    require({p.relative_to(workspace).as_posix(): digest_bytes(reader(p)) for p in competing_files}
            == competing[0]['deployed_file_hashes'], 'Competing skill hash mismatch')
    overlay = workspace / gh.OVERLAY
    data = parse_json(reader(overlay / 'evals/evals.json'))
    require(type(data) is dict and data.get('skill_name') == 'gh'
            and type(data.get('evals')) is list and 0 < len(data['evals']) <= MAX_CASES, 'Invalid gh dataset')
    ids = [entry['id'] for entry in data['evals']]
    require(all(type(value) is str and re.fullmatch(r'gh-\d{3}(?:-[a-z-]+)?', value) for value in ids)
            and len(ids) == len(set(ids)), 'Invalid or duplicate gh case IDs')
    for entry in data['evals']:
        require(entry['contract'].get('fixture_contract') == 'gh-cli-subset-v2', 'Unsupported gh fixture contract')
        require(entry['contract']['evidence_classification'] in
                ('synthetic', 'documentation', 'observed-plus-synthetic'), 'Missing provenance classification')
        require(entry['expected_skill'] in ('gh', None), 'Invalid activation contract')
        for member in entry['files']:
            relative(member)
            require(member.startswith('evals/files/') and overlay / member in entries, 'Missing or escaping fixture input')


def inventory(workspace=ROOT):
    directories = {}
    states = {}
    members = {}
    workspace = safe_path(workspace, directory=True, directory_identities=directories)
    budget = ReadBudget()
    captured = {}
    repo = workspace_repository(workspace, budget=budget)
    def reader(path):
        path = safe_path(path, directory_identities=directories)
        if path not in captured:
            captured[path] = read_bytes(path, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
        else:
            verify_file_states(members, directories, states, [path])
        return captured[path]
    def present(path):
        safe_path(path.parent, directory=True, directory_identities=directories)
        fd = open_directory(path.parent, directories, directory_states=states)
        try:
            observed = directory_state(os.fstat(fd))
            states.setdefault(path.parent, observed)
            require(states[path.parent] == observed, 'Input directory entries changed')
            try:
                info = os.stat(path.name, dir_fd=fd, follow_symlinks=False)
                if stat.S_ISREG(info.st_mode):
                    observed_file = file_state(info)
                    require_unchanged_member(path not in members or members[path] == observed_file, require,
                        phase='inventory_presence', role='input_file', path=path,
                        expected=members.get(path, observed_file), info=info)
                    members[path] = observed_file
                return True
            except FileNotFoundError:
                return False
            finally:
                require(directory_state(os.fstat(fd)) == observed, 'Input directory entries changed')
        finally:
            os.close(fd)
    catalog = workspace / '.apm/skills'
    files = safe_tree(catalog, directory_identities=directories, directory_states=states, file_states=members)
    dataset_entries = set(files) | set(directories)
    names = sorted(p.parent.name for p in files if p.name == 'SKILL.md' and p.parent.parent == catalog)
    require(bool(names), 'No local skills found')
    lock_path = workspace / 'apm.lock.yaml'
    lock = read_yaml(lock_path, reader=reader) if present(lock_path) else {'dependencies': [], 'deployments': []}
    require(type(lock) is dict and type(lock.get('dependencies')) is list
            and type(lock.get('deployments')) is list, 'Invalid ownership metadata')
    closed_dependencies = lock.get('dependencies', [])
    deployments = lock.get('deployments', [])
    require(len(closed_dependencies) <= MAX_CASES and len(deployments) <= MAX_INPUT_ENTRIES,
            'Ownership record limit')
    require(all(type(item) is dict for records in (closed_dependencies, deployments) for item in records),
            'Invalid ownership records')
    owners_by_name = {}
    for owner in closed_dependencies:
        if type(owner.get('name')) is str:
            owners_by_name.setdefault(owner['name'], []).append(owner)
    deployments_by_member = {}
    for deployment in deployments:
        if deployment.get('target') == 'codex' and type(deployment.get('value')) is str:
            deployments_by_member.setdefault(deployment['value'], []).append(deployment)
    overlays = workspace / '.github/evals'
    overlay_names = []
    if present(overlays.parent) and present(overlays):
        overlay_files = safe_tree(overlays, directory_identities=directories, directory_states=states, file_states=members)
        safe_path(overlays, directory=True, directory_identities=directories)
        overlay_entries = set(overlay_files) | set(directories)
        dataset_entries.update(overlay_entries)
        overlay_names = [p.parent.parent.name for p in overlay_entries
                         if p.name.startswith('evals.') and p.parent.name == 'evals'
                         and p.parent.parent.parent == overlays]
    discovered = sorted(set(names + overlay_names))
    require(len(discovered) <= MAX_CASES, 'Inventory limit')
    head_revision = inventory_revision(workspace, budget) if repo else None
    rows = []
    with budget.repository_operation():
        for name in discovered:
            skill_id(name)
            owners = owners_by_name.get(name, [])
            require(len(owners) <= 1 and not (name in names and owners), 'Conflicting active source owners')
            if name in names:
                authored = catalog / name
                validate_skill_metadata(authored, name, reader=reader)
                source_path = authored.relative_to(workspace).as_posix()
                configured = skill_content(authored, reader=reader, directory_identities=directories,
                                           directory_states=states, file_states=members)
                rev = head_revision
                if rev is not None and historical_content(workspace, rev, source_path, budget=budget)['digest'] != configured['digest']:
                    rev = None
                src = source(name, 'local', repo, rev, source_path, configured)
                deployment = None
            else:
                require(len(owners) == 1, 'Overlay has no unique skill owner')
                owner = owners[0]
                repository(owner['repo_url']); revision(owner['resolved_commit']); relative(owner['virtual_path'])
                authored = workspace / '.agents/skills' / name
                files = safe_tree(authored, max_entries=2 * MAX_SOURCE_MEMBERS, max_files=MAX_SOURCE_MEMBERS,
                                  directory_identities=directories, directory_states=states, file_states=members)
                reject_source_markers(authored, files, directories)
                validate_skill_metadata(authored, name, reader=reader)
                visible = skill_projection_files(authored, files, directory_identities=directories, directory_states=states)
                actual = {p.relative_to(workspace).as_posix(): digest_bytes(reader(p)) for p in files}
                require(actual == owner['deployed_file_hashes'], 'Deployment content drift')
                for member, digest in actual.items():
                    matches = deployments_by_member.get(member, [])
                    ownership = owner['repo_url'] + '/' + owner['virtual_path']
                    require(len(matches) == 1 and matches[0]['active_owner'] == ownership
                            and matches[0]['owners'] == [ownership] and matches[0]['content_hash'] == digest,
                            'Ambiguous deployment ownership')
                if name == 'gh':
                    import gh_evaluations as gh
                    competing = workspace / '.agents/skills' / gh.COMPETING
                    competing_files = safe_tree(competing, max_entries=2 * MAX_SOURCE_MEMBERS,
                                                max_files=MAX_SOURCE_MEMBERS, directory_identities=directories, directory_states=states, file_states=members)
                    reject_source_markers(competing, competing_files, directories)
                    safe_path(competing, directory=True, directory_identities=directories)
                    validate_captured_gh(workspace, owner, actual, owners_by_name, competing_files,
                                         set(overlay_files), reader)
                src = source(name, 'upstream', owner['repo_url'], owner['resolved_commit'], owner['virtual_path'],
                             content([{'member': p.relative_to(authored).as_posix(),
                                       'digest': actual[p.relative_to(workspace).as_posix()]} for p in visible], 'configured'))
                deployment = '.agents/skills/' + name
            dataset_roots = [overlays / name / 'evals']
            if name in names:
                dataset_roots.append(authored / 'evals')
            datasets = [p for p in dataset_entries if p.parent in dataset_roots and p.name.startswith('evals.')]
            require(len(datasets) <= 1, 'Competing dataset sources')
            suite = strict_dataset(datasets[0], name, reader=reader, directory_identities=directories,
                                   directory_states=states, file_states=members) if datasets else None
            if suite:
                suite['owner'] = 'overlay' if datasets[0].is_relative_to(overlays) else 'local'
                suite['path'] = datasets[0].relative_to(workspace).as_posix()
            rows.append({'source': src, 'deployment': deployment, 'suite': suite,
                         'behavioral_status': 'configured' if suite else 'not_configured',
                         'measurement': {'status': 'unavailable', 'reasons': ['results_not_supplied']}})
    result = {'schema_version': 1, 'kind': 'inventory', 'skills': rows}
    budget.verify_repository()
    verify_directory_states(states, directories)
    verify_file_states(members, directories, states)
    validate_inventory(result)
    return _CapturedRecord(result, (input_guard(directories, states, members, budget),))


def validate_inventory(data):
    if type(data) is _CapturedRecord: data = dict(data)
    closed(data, ('schema_version', 'kind', 'skills'))
    require(type(data['schema_version']) is int and data['schema_version'] == 1 and data['kind'] == 'inventory', 'Inventory version')
    require(type(data['skills']) is list and len(data['skills']) <= MAX_CASES, 'Inventory limit')
    names = []
    for row in data['skills']:
        closed(row, ('source', 'deployment', 'suite', 'behavioral_status', 'measurement'))
        validate_source(row['source']); names.append(row['source']['skill_id']); optional(row['deployment'], relative)
        enum(row['behavioral_status'], ('configured', 'not_configured'))
        closed(row['measurement'], ('status', 'reasons'))
        require(row['measurement'] == {'status': 'unavailable', 'reasons': ['results_not_supplied']}, 'Invented measurement')
        if row['suite'] is not None:
            suite = row['suite']; closed(suite, ('owner', 'path', 'authored_digest', 'case_ids', 'status'))
            enum(suite['owner'], ('local', 'overlay')); relative(suite['path']); sha(suite['authored_digest'])
            case_ids(suite['case_ids']); require(suite['status'] == row['behavioral_status'] == 'configured', 'Suite status')
        else:
            require(row['behavioral_status'] == 'not_configured', 'Missing suite')
    require(names == sorted(set(names)), 'Duplicate inventory source')

POLICY_FIELDS = tuple(reports.POLICY) + ('upstream_revision', 'deterministic_gate', 'workspace_mode',
    'fixture_boundary', 'authorization_policy', 'task_source', 'task_build', 'competing_revision')
GATE_FIELDS = ('evidence', 'activation', 'commands', 'task', 'recovery', 'authorization', 'efficiency', 'gate')
SCORE_FIELDS = ('security', 'skill_execution', 'skill_efficiency', 'accuracy', 'goal_accuracy',
                'behavior_check', 'overall', 'custom')


def deterministic_observation(value, skill, *, released_native=False):
    keys = {field: 'gh_' + field for field in GATE_FIELDS}
    if released_native:
        from benchmark_native import GH_ACCESS_METRIC

        keys['authorization'] = GH_ACCESS_METRIC
    require(type(value) is dict and (not value or skill == 'gh' and set(value) == set(keys.values())),
            'Unsupported custom grading contract')
    if value:
        require(all(type(v) in (int, float) and v in (0, 1) for v in value.values()),
                'Invalid deterministic observation')
        require(value['gh_gate'] == float(all(v == 1 for k, v in value.items() if k != 'gh_gate')),
                'Gate consistency')
    return {key: value.get(native_key) for key, native_key in keys.items()}


def validate_build(value):
    closed(value, ('base_image', 'apt_snapshot', 'apt_packages'))
    require(type(value['base_image']) is str and bool(re.fullmatch(r'[a-z0-9./:_-]+@sha256:[0-9a-f]{64}', value['base_image'])), 'Invalid base image')
    require(type(value['apt_snapshot']) is str and bool(re.fullmatch(r'[0-9]{8}T[0-9]{6}Z', value['apt_snapshot'])), 'Invalid apt snapshot')
    closed(value['apt_packages'], reports.GH_TASK_BUILD['apt_packages'])
    for version in value['apt_packages'].values():
        token(version)


def policy_fields(value):
    require(type(value) is dict and set(value) <= set(POLICY_FIELDS), 'Unsupported policy fields')
    return {key: copy.deepcopy(value.get(key)) for key in POLICY_FIELDS}


def native_diagnostic_profile(revision, patch):
    if revision not in (profiles.RELEASE_BENCHMARK['revision'], profiles.CURRENT_RELEASE['revision']):
        return None
    from benchmark_native import native_owner, native_profile

    owner = native_owner(revision, patch)
    return native_profile(owner=owner) if owner else None


def released_policy_identity(value, *, custom_only, static):
    """A production score series has a distinct identity from offline candidates."""
    fields = value['fields']
    revision = fields.get('evaluator_revision')
    if revision not in (profiles.RELEASE_BENCHMARK['revision'], profiles.CURRENT_RELEASE['revision']):
        return False
    from benchmark_native import BACKENDS, native_owner, released_policy, score_series

    owner = native_owner(revision, value.get('patch_digest'))
    if owner is None or (custom_only and value.get('producer_profile')):
        return False
    say = 'Invalid released benchmark policy'
    require(not static and not custom_only and value.get('producer_profile') is None
            and value.get('metric_set') == 'skill-evaluator-default-v2', say)
    attempts = value.get('attempts')
    require(type(attempts) is dict and type(attempts.get('mode')) is str, say)
    mode = attempts['mode']
    require(mode in reports.MODES and attempts.get('maximum') == reports.MODES[mode]
            and attempts.get('stop_on_pass') is False and attempts.get('pass_threshold') == 0.5
            and value.get('provenance') == 'runtime_recorded', say)
    suite = next((name for name, backend in BACKENDS.items() if fields.get('environment') == backend), None)
    require(suite is not None and value.get('published_id') == score_series(suite, mode, owner=owner), say)
    expected = released_policy(suite, owner=owner)
    require(fields == policy_fields({key: expected[key] for key in POLICY_FIELDS if key in expected})
            and value['judge'] == {'model': expected['model'], 'provider': expected['provider'], 'enabled': True}, say)
    return True


def require_released_report_population(record):
    custom_only = record['policy']['fields']['grading'] == 'custom_only'
    if not released_policy_identity(record['policy'], custom_only=custom_only, static=False):
        return
    from benchmark_native import BACKENDS
    from skill_analysis import complete_numeric

    skill = record['source']['skill_id']
    require(record['policy']['fields']['environment'] == BACKENDS.get(skill),
            'Released report suite differs from its producer')
    require(record['dataset']['authored_digest'] is not None and record['dataset']['staged_digest'] is not None
            and complete_numeric(record) and not {'coverage_missing', 'case_details_missing', 'execution_incomplete',
                                                  'metadata_missing'}.intersection(record['availability']['reasons']),
            'Released benchmark requires an authenticated complete cohort')
    if skill == 'gh':
        require(all(obs['deterministic_gate'] is not None
                    and (obs['arm'] == 'without_skill' or obs['deterministic_gate'] == 1)
                    for obs in record['observations']), 'Released gh report lacks its required gates')


def validate_policy(value, *, custom_only=False, static=False):
    require(type(value) is dict, 'Invalid policy')
    require(type(value.get('fields')) is dict, 'Invalid policy fields')
    runtime_revision = value['fields'].get('evaluator_revision')
    require(static or value.get('published_id') not in static_evaluator.STATIC_PRODUCERS, 'Static producer policy requires static evidence')
    static_release = static_evaluator.STATIC_OWNERS.get(runtime_revision) if static and type(runtime_revision) is str else None
    released = released_policy_identity(value, custom_only=custom_only, static=static)
    diagnostic = native_diagnostic_profile(runtime_revision, value.get('patch_digest')) if custom_only else None
    candidate = None
    if not static_release and not released:
        candidate = diagnostic or profiles.candidate_revision(runtime_revision, producer_id=value.get('producer_profile'),
                                                             patch=value.get('patch_digest'))
    require(static_release or released or candidate is not None or profiles.candidate_revision(runtime_revision) is None,
            'Unsupported candidate producer identity')
    closed(value, ('id', 'published_id', 'provenance', 'patch_digest', 'fields', 'metric_set', 'judge', 'attempts') + (('producer_profile', 'scoring_policy') if candidate else ()))
    if candidate:
        require(value['judge']['enabled'] is False, 'Offline candidate judging must remain unavailable')
        require(value['producer_profile'] == candidate['id'] and value['scoring_policy'] == ('custom-overall-v1' if custom_only else candidate['scoring']), 'Unsupported candidate scoring profile')
        require(value['fields']['harbor'] == candidate['harbor'] and value['fields']['python'] == candidate['python'], 'Contradictory candidate policy')
        require(value['patch_digest'] == 'sha256:' + candidate['patch_sha256'], 'Candidate patch identity mismatch')
    optional(value['id'], sha); optional(value['published_id'], token); enum(value['provenance'], PROVENANCE)
    optional(value['patch_digest'], sha); optional(value['metric_set'], lambda v: enum(v, ('custom-only',) if custom_only else ('skill-evaluator-default-v2',)))
    fields = value['fields']; closed(fields, POLICY_FIELDS)
    for key, val in fields.items():
        if val is None:
            continue
        if key.endswith('revision'):
            revision(val)
        elif key in ('baseline', 'stop_on_pass'):
            boolean(val)
        elif key in ('concurrency', 'standard_attempts', 'deterministic_gate'):
            count(val, 100)
        elif key == 'timeout_multiplier':
            number(val, 0.01, 100)
        elif key == 'task_build':
            validate_build(val)
        else:
            token(val)
    if static_release:
        require(value['published_id'] == static_release['producer_profile'] and value['patch_digest'] is None
                and value['judge'] == {'model': None, 'provider': None, 'enabled': False}
                and all(fields[key] == static_release[key] for key in ('python', 'harbor')),
                'Contradictory static candidate policy')
    elif fields['evaluator_revision'] is not None:
        profiles.by_revision(fields['evaluator_revision'])
    judge = value['judge']; closed(judge, ('model', 'provider', 'enabled'))
    if diagnostic:
        from benchmark_native import DIAGNOSTIC_BACKEND

        require(fields['environment'] == DIAGNOSTIC_BACKEND and fields['grading'] == 'custom_only'
                and fields['task_source'] == 'native_harbor' and fields['workspace_mode'] == 'isolated'
                and fields['model'] == reports.POLICY['model'] and fields['provider'] == reports.POLICY['provider']
                and value['metric_set'] == 'custom-only' and value['published_id'] is None
                and judge == {'model': None, 'provider': None, 'enabled': False}
                and value['attempts'] == {'mode': 'confirmation', 'maximum': reports.MODES['confirmation'],
                                          'stop_on_pass': False, 'pass_threshold': None},
                'Invalid released diagnostic policy')
    optional(judge['model'], token); optional(judge['provider'], token); optional(judge['enabled'], boolean)
    closed(value['attempts'], ('mode', 'maximum', 'stop_on_pass', 'pass_threshold'))
    enum(value['attempts']['mode'], ('standard', 'confirmation', 'unknown'))
    optional(value['attempts']['maximum'], lambda v: count(v, 100))
    require(value['attempts']['maximum'] is None or value['attempts']['maximum'] > 0, 'Zero attempts')
    if value['attempts']['mode'] in reports.MODES and value['attempts']['maximum'] is not None:
        require(value['attempts']['maximum'] == reports.MODES[value['attempts']['mode']],
                'Benchmark mode attempt count mismatch')
    if value['attempts']['mode'] == 'standard' and value['attempts']['maximum'] is not None \
            and fields['standard_attempts'] is not None:
        require(fields['standard_attempts'] == value['attempts']['maximum'], 'Standard attempt policy mismatch')
    optional(value['attempts']['stop_on_pass'], boolean); optional(value['attempts']['pass_threshold'], number)
    if fields['stop_on_pass'] is not None and value['attempts']['stop_on_pass'] is not None:
        require(fields['stop_on_pass'] == value['attempts']['stop_on_pass'], 'Stop-on-pass policy mismatch')
    canonical = {key: value[key] for key in ('fields', 'patch_digest', 'metric_set', 'judge', 'attempts')}
    if candidate:
        canonical.update({key: value[key] for key in ('producer_profile', 'scoring_policy')})
    require(value['id'] == (identity(canonical) if value['provenance'] != 'unknown' else None), 'Policy identity mismatch')


def make_policy(fields=None, patch=None, metric_set=None, judge=None, attempts=None, provenance='unknown', published=None):
    value = {'fields': policy_fields(fields or {}), 'patch_digest': patch, 'metric_set': metric_set,
             'judge': judge or {'model': None, 'provider': None, 'enabled': None},
             'attempts': attempts or {'mode': 'unknown', 'maximum': None, 'stop_on_pass': None, 'pass_threshold': None}}
    revision = value['fields']['evaluator_revision']
    diagnostic = native_diagnostic_profile(revision, patch) if metric_set == 'custom-only' else None
    candidate = diagnostic or profiles.candidate_revision(revision, patch=patch)
    if published not in static_evaluator.STATIC_PRODUCERS and candidate:
        value.update(producer_profile=candidate['id'], scoring_policy='custom-overall-v1' if metric_set == 'custom-only' else candidate['scoring'])
    return {**value, 'id': identity(value) if provenance != 'unknown' else None,
            'provenance': provenance, 'published_id': published}


def validate_condition(value):
    closed(value, ('id', 'provenance', 'target_present', 'workspace_mode', 'competing_skills',
                   'instruction_digest', 'build_digest', 'fixture_digest', 'execution'))
    sha(value['id']); enum(value['provenance'], PROVENANCE); boolean(value['target_present'])
    optional(value['workspace_mode'], lambda v: enum(v, ('isolated', 'group')))
    for key in ('instruction_digest', 'build_digest', 'fixture_digest'):
        optional(value[key], sha)
    require(type(value['competing_skills']) is list and len(value['competing_skills']) <= 100, 'Competing skill limit')
    for src in value['competing_skills']:
        validate_source(src)
    names = [s['skill_id'] for s in value['competing_skills']]
    require(names == sorted(set(names)), 'Competing skill collision')
    closed(value['execution'], ('environment', 'base_image_mode', 'task_source', 'authorization_policy', 'fixture_boundary'))
    for val in value['execution'].values():
        optional(val, token)
    require(value['id'] == identity({k: v for k, v in value.items() if k != 'id'}), 'Arm condition identity mismatch')


def condition(present, provenance='unknown', workspace_mode=None, competing=(), instructions=None,
              build=None, fixture=None, execution=None):
    value = {'provenance': provenance, 'target_present': present, 'workspace_mode': workspace_mode,
             'competing_skills': sorted(competing, key=lambda s: s['skill_id']),
             'instruction_digest': instructions, 'build_digest': build, 'fixture_digest': fixture,
             'execution': execution or {k: None for k in ('environment', 'base_image_mode', 'task_source',
                                                        'authorization_policy', 'fixture_boundary')}}
    return {'id': identity(value), **value}


def validate_reference(value):
    closed(value, ('id', 'artifact_id', 'artifact_digest', 'member', 'locator', 'digest', 'provenance', 'availability'))
    sha(value['id']); token(value['artifact_id']); optional(value['artifact_digest'], sha)
    relative(value['member']); sha(value['digest']); enum(value['provenance'], PROVENANCE)
    enum(value['availability'], ('available', 'unavailable', 'expired'))
    require(type(value['locator']) is list and len(value['locator']) <= 12, 'Locator limit')
    for item in value['locator']:
        if type(item) is int:
            count(item)
        else:
            token(item)
    # Availability can change without changing the reference's stable identity.
    require(value['id'] == identity({k: value[k] for k in ('artifact_id', 'member', 'locator', 'digest')}), 'Reference identity mismatch')
    if any(artifact == value['artifact_id'] for artifact, _ in REVIEWED_REFERENCE_EXPIRY):
        require(value['provenance'] == 'reviewed_extract'
                and (value['artifact_id'], value['artifact_digest']) in REVIEWED_REFERENCE_EXPIRY,
                'Unrecognized reviewed reference identity')
    if value['provenance'] == 'reviewed_extract':
        require(identity({k: value[k] for k in ('artifact_id', 'artifact_digest', 'member', 'locator', 'digest')})
                in REVIEWED_REFERENCE_IDENTITIES, 'Unrecognized reviewed reference identity')


def reference(root, path, artifact, locator=(), extract=None):
    return reference_from_digest(root, path, artifact, digest_bytes(read_bytes(path)), locator, extract)


def reference_expired(record, observed_at):
    deadline = REVIEWED_REFERENCE_EXPIRY.get((record['artifact_id'], record['artifact_digest']))
    if record['provenance'] == 'reviewed_extract':
        require(deadline is not None, 'Missing reviewed reference expiration')
    return deadline is not None and observed_at >= datetime.fromisoformat(deadline)


def reference_from_digest(root, path, artifact, raw_digest, locator=(), extract=None):
    sha(raw_digest)
    member = path.relative_to(root).as_posix()
    value = {'artifact_id': artifact, 'member': member, 'locator': list(locator), 'digest': raw_digest}
    if extract is not None:
        member_record = extract['_members_by_name'].get(member)
        require(member_record is not None and member_record['extract_digest'] == raw_digest, 'Reviewed extract mismatch')
        value['digest'] = member_record['original_digest']
    return {'id': identity(value), **value, 'artifact_digest': extract['archive_digest'] if extract else None,
            'provenance': 'reviewed_extract' if extract else 'runtime_recorded',
            'availability': extract['_reference_availability'] if extract else 'available'}


def evidence(name, kind, cases=(), src=None, policy=None):
    return {'schema_version': 1, 'kind': kind, 'source': src or source(name), 'run_id': None,
            'dataset': {'owner': 'unknown', 'authored_digest': None, 'staged_digest': None,
                        'staged_algorithm': None, 'authored_provenance': 'unknown', 'staged_provenance': 'unknown', 'case_cohort_digest': identity(sorted(cases)), 'case_ids': sorted(cases)},
            'policy': policy or make_policy(), 'arms': [], 'metrics': [], 'observations': [], 'scans': [], 'findings': [],
            'references': [], 'availability': {'status': 'unavailable', 'reasons': ['results_not_supplied'],
                                             'provenance': 'unknown'}}


def observation_id(run, arm, case, native_id, trial, attempt):
    return identity([run, arm, case, native_id, trial, attempt])


def behavioral_identity_missing(data):
    return any(value is None for value in (data['run_id'], data['dataset']['staged_digest'],
               data['policy']['fields']['evaluator_revision'], data['policy']['patch_digest'],
               data['policy']['attempts']['maximum']))


def security_observation_fields(obs, data, references):
    if 'security_evidence' not in obs:
        return ()
    require(data['policy'].get('producer_profile') in (profiles.NEXT['id'], profiles.ACCOUNTING['id']),
            'Unversioned security diagnostic')
    unscored_security.validate_security(obs['security_evidence'])
    reports.public_strings(obs['security_evidence'])
    require(obs['score'] is None and obs['rubric_pass'] is None
            and all(v is None for v in obs['scores'].values())
            and all(v is None for v in obs['deterministic_scores'].values())
            and all(v is None for v in obs.get('raw_scores', {}).values())
            and all(v is None for v in obs.get('raw_deterministic_scores', {}).values()),
            'Unscored security diagnostic acquired measurements')
    result_parents = {ref['member'].rsplit('/', 1)[0] for ref in references
                      if ref['id'] in obs['references'] and ref['member'].endswith('/result.json')}
    require(any(ref['id'] in obs['references'] and ref['locator'] == ['details', 'security']
                and ref['member'].endswith('/reward.json')
                and ref['member'].rsplit('/', 1)[0] in result_parents
                for ref in references), 'Security diagnostic lacks supporting reference')
    return ('security_evidence',)


def validate_evidence(data, *, public=False, _observed_at=None):
    if isinstance(data, dict) and data.get('schema_version') == 2:
        return validate_custom_evidence(data, public=public, _observed_at=_observed_at)
    observed_at = _observed_at
    if type(data) in (_CapturedRecord, _StaticEvidence, _BehavioralEvidence):
        data = dict(data)
    fields = ('schema_version', 'kind', 'source', 'run_id', 'dataset', 'policy', 'arms', 'metrics',
              'observations', 'scans', 'findings', 'references', 'availability')
    if 'scanner_runtime' in data:
        require(data.get('kind') == 'static' and data['scanner_runtime'] in SCANNER_RUNTIMES,
                'Unsupported or contradictory scanner runtime')
        fields += ('scanner_runtime',)
    if 'coverage_caveats' in data:
        require(data.get('kind') == 'static' and data.get('scanner_runtime') in CAVEAT_SCANNER_RUNTIMES,
                'Caveats require the qualified adapter')
        fields += ('coverage_caveats',)
        caveats = data['coverage_caveats']
        require(type(caveats) is list and 0 < len(caveats) <= 100, 'Invalid coverage caveats')
        for item in caveats:
            closed(item, ('scanner', 'producer_status', 'reason', 'count', 'reference'))
            require(item['scanner'] == 'skillspector' and item['producer_status'] == 'complete_with_caveats'
                    and item['reason'] == 'reference_missing', 'Unsupported coverage caveat')
            count(item['count']); require(item['count'] > 0, 'Empty coverage caveat')
            require(item['reference'] in {ref['id'] for ref in data['references']}, 'Missing caveat reference')
            require(any(scan['scanner'] == 'skillspector' and scan['status'] == 'incomplete'
                        for scan in data['scans']), 'Caveats cannot waive coverage policy')
    if 'benchmark' in data:
        import benchmark_evidence
        benchmark_evidence.validate(data['benchmark'], data)
        fields += ('benchmark',)
    closed(data, fields)
    require(type(data['schema_version']) is int and data['schema_version'] == 1, 'Evidence version')
    enum(data['kind'], ('behavioral', 'static')); validate_source(data['source']); optional(data['run_id'], token)
    ds = data['dataset']; closed(ds, ('owner', 'authored_digest', 'staged_digest', 'staged_algorithm', 'authored_provenance', 'staged_provenance', 'case_cohort_digest', 'case_ids'))
    enum(ds['owner'], ('local', 'overlay', 'unknown'))
    for key in ('authored_digest', 'staged_digest'):
        optional(ds[key], sha)
    optional(ds['staged_algorithm'], lambda v: enum(v, ('skill-evaluator-dataset-snapshot/1',)))
    enum(ds['authored_provenance'], PROVENANCE); enum(ds['staged_provenance'], PROVENANCE)
    require((ds['authored_digest'] is None) == (ds['authored_provenance'] == 'unknown'), 'Authored provenance mismatch')
    require((ds['staged_digest'] is None) == (ds['staged_provenance'] == 'unknown'), 'Staged provenance mismatch')
    require(ds['staged_digest'] is None or ds['staged_algorithm'] == 'skill-evaluator-dataset-snapshot/1',
            'Missing staged digest algorithm')
    ids = case_ids(ds['case_ids']); require(ds['case_cohort_digest'] == identity(sorted(ids)), 'Cohort mismatch')
    validate_policy(data['policy'], static=data['kind'] == 'static')
    if data['kind'] == 'static':
        revision = data['policy']['fields']['evaluator_revision']
        if 'scanner_runtime' in data:
            require(scanner_owner_matches(data['scanner_runtime'], revision),
                    'Scanner adapter and public producer differ')
        if revision in static_evaluator.STATIC_OWNERS:
            require(data.get('scanner_runtime') in STATIC_SCANNER_RUNTIMES,
                    'Missing static candidate scanner provenance')
    availability = data['availability']; closed(availability, ('status', 'reasons', 'provenance'))
    enum(availability['status'], ('complete', 'incomplete', 'unavailable')); enum(availability['provenance'], PROVENANCE)
    require(type(availability['reasons']) is list and len(availability['reasons']) <= len(REASONS)
            and len(set(availability['reasons'])) == len(availability['reasons']), 'Invalid reasons')
    for reason in availability['reasons']:
        enum(reason, REASONS)
    require((availability['status'] == 'complete') == (not availability['reasons']), 'Contradictory availability')
    references = data['references']; require(type(references) is list and len(references) <= MAX_REFERENCES, 'Reference limit')
    ref_ids = set(); refs_by_id = {}
    for ref in references:
        validate_reference(ref); require(ref['id'] not in ref_ids, 'Duplicate reference'); ref_ids.add(ref['id'])
        refs_by_id[ref['id']] = ref
        if observed_at is None:
            observed_at = utc_now()
        if reference_expired(ref, observed_at):
            require(ref['availability'] == 'expired', 'Reviewed reference must be expired')
        if ref['availability'] != 'available':
            reason = 'reference_expired' if ref['availability'] == 'expired' else 'reference_unavailable'
            require(availability['status'] == 'incomplete' and reason in availability['reasons'], 'Missing reference limitation')
    if availability['provenance'] == 'reviewed_extract':
        require(bool(references) and all(ref['provenance'] == 'reviewed_extract' for ref in references),
                'Reviewed availability missing reviewed references')
    require(type(data['observations']) is list and len(data['observations']) <= MAX_TRIALS, 'Trial limit exceeded')
    seen = set(); native_ids = set(); observation_ids = set()
    for obs in data['observations']:
        obs_fields = OBSERVATION_FIELDS + security_observation_fields(obs, data, references)
        if 'producer_profile' in data['policy']: obs_fields += ('raw_scores', 'raw_deterministic_scores')
        closed(obs, obs_fields if public else obs_fields + ('native_id', 'native_trial', 'native_task'))
        if 'raw_scores' in obs:
            closed(obs['raw_scores'], SCORE_FIELDS)
            for val in obs['raw_scores'].values(): optional(val, number)
            closed(obs['raw_deterministic_scores'], GATE_FIELDS)
            for val in obs['raw_deterministic_scores'].values(): optional(val, number)
            require(obs['score'] is None and obs['rubric_pass'] is None and
                    all(obs['scores'][k] is None for k in ('accuracy', 'goal_accuracy', 'behavior_check', 'overall')),
                    'Offline candidate cannot acquire judged quality')
            if obs['raw_deterministic_scores']['evidence'] == 0:
                require(all(v is None for v in obs['deterministic_scores'].values()) and obs['scores']['security'] is None,
                        'Missing candidate evidence became a measurement')
        sha(obs['id']); enum(obs['arm'], ('with_skill', 'without_skill')); require(obs['case_id'] in ids, 'Unknown case')
        optional(obs['attempt'], lambda v: count(v, 100)); require(obs['attempt'] is None or obs['attempt'] >= 1, 'Invalid attempt index')
        if obs['attempt'] is None:
            require(availability['status'] == 'incomplete' and 'metadata_missing' in availability['reasons'],
                    'Missing attempt metadata limitation')
        optional(obs['score'], number); optional(obs['rubric_pass'], boolean)
        optional(obs['deterministic_gate'], number)
        closed(obs['scores'], SCORE_FIELDS)
        for val in obs['scores'].values():
            optional(val, number)
        require(obs['scores']['overall'] == obs['score'], 'Conflicting overall score')
        if obs['score'] is None:
            require(obs['rubric_pass'] is None, 'Unscored trial has rubric outcome')
        closed(obs['deterministic_scores'], GATE_FIELDS)
        for val in obs['deterministic_scores'].values():
            optional(val, lambda v: number(v, 0, 1))
        gates = obs['deterministic_scores']
        if any(value is not None for value in gates.values()):
            require(data['source']['skill_id'] == 'gh', 'Unsupported custom grading contract')
            require(all(value is not None and value in (0, 1) for value in gates.values()),
                    'Invalid deterministic observation')
        require((gates['gate'] is None) == (obs['deterministic_gate'] is None), 'Missing gate detail')
        if gates['gate'] is not None:
            require(all(v is not None for v in gates.values()) and gates['gate'] == obs['deterministic_gate']
                    and gates['gate'] == float(all(v == 1 for k, v in gates.items() if k != 'gate')), 'Gate consistency')
        key = (obs['arm'], obs['case_id'], obs['attempt'] if obs['attempt'] is not None else obs['id'])
        require(key not in seen and obs['id'] not in observation_ids, 'Duplicate attempt'); seen.add(key); observation_ids.add(obs['id'])
        if not public:
            token(obs['native_id']); token(obs['native_trial']); relative(obs['native_task'])
            require((obs['arm'], obs['native_id']) not in native_ids, 'Duplicate native trial ID')
            native_ids.add((obs['arm'], obs['native_id']))
            require(obs['id'] == observation_id(data['run_id'], obs['arm'], obs['case_id'], obs['native_id'],
                                              obs['native_trial'], obs['attempt']), 'Observation identity mismatch')
        require(type(obs['references']) is list and 1 <= len(obs['references']) <= 10
                and set(obs['references']) <= ref_ids, 'Dangling observation reference')
        if not public:
            trial_result_found = False
            for ref_id in obs['references']:
                ref = refs_by_id[ref_id]; parts = ref['member'].split('/')
                require(len(parts) >= 4 and parts[:2] == ['results', data['source']['skill_id']]
                        and (data['run_id'] is None or parts[2] == data['run_id']),
                        'Observation reference origin mismatch')
                if parts[3:] == ['result.json'] and ref['locator'] == ['agents', 'codex']:
                    require('metadata_missing' in availability['reasons'], 'Observation reference origin mismatch')
                    continue  # Existing partial-evidence fallback when the arm summary is absent.
                require(parts[3:5] == ['codex', obs['arm'].replace('_', '-')],
                        'Observation reference origin mismatch')
                tail = parts[5:]
                trial_result = tail == ['trials', obs['native_trial'], 'result.json']
                diagnostic_ref = ('security_evidence' in obs and
                    (tail == ['trials', obs['native_trial'], 'failure.json'] and ref['locator'] == []
                     or tail == ['trials', obs['native_trial'], 'reward.json']
                        and ref['locator'] == ['details', 'security']))
                accounting_ref = (data['policy'].get('producer_profile') == profiles.ACCOUNTING['id']
                    and tail == ['trials', obs['native_trial'], 'judge_accounting.json'] and ref['locator'] == [])
                require(trial_result and ref['locator'] in ([], ['verifier_result'], ['verifier_result', 'rewards'])
                        or tail in (['trials', obs['native_trial'], 'reward.json'], ['summary.json'])
                        and ref['locator'] == [] or diagnostic_ref or accounting_ref, 'Observation reference origin mismatch')
                trial_result_found |= trial_result
            require(trial_result_found, 'Observation reference origin mismatch')
    require(type(data['arms']) is list and len(data['arms']) <= 2, 'Invalid arms')
    arm_names = []
    for arm in data['arms']:
        closed(arm, ('name', 'condition', 'coverage', 'execution_status', 'execution_error_count', 'rubric'))
        enum(arm['name'], ('with_skill', 'without_skill')); arm_names.append(arm['name']); validate_condition(arm['condition'])
        require(arm['condition']['target_present'] == (arm['name'] == 'with_skill'), 'Arm target mismatch')
        for key in ('environment', 'task_source', 'authorization_policy', 'fixture_boundary', 'workspace_mode'):
            declared = data['policy']['fields'][key]
            observed = arm['condition'][key] if key == 'workspace_mode' else arm['condition']['execution'][key]
            require(declared is None or observed is None or declared == observed,
                    'Task source policy mismatch' if key == 'task_source' else 'Arm condition policy mismatch')
        enum(arm['execution_status'], ('succeeded', 'failed', 'incomplete', 'unknown'))
        count(arm['execution_error_count'])
        cov = arm['coverage']; closed(cov, ('expected_cases', 'expected_attempts', 'recorded_attempts', 'scored_attempts', 'unscored_attempts', 'case_details'))
        count(cov['expected_cases'], MAX_CASES); require(cov['expected_cases'] == len(ids), 'Case denominator mismatch')
        for key in ('expected_attempts', 'recorded_attempts', 'scored_attempts', 'unscored_attempts'):
            optional(cov[key], count)
        enum(cov['case_details'], ('complete', 'partial', 'unavailable'))
        if cov['expected_attempts'] is not None:
            require(all(cov[key] is None or cov[key] <= cov['expected_attempts']
                        for key in ('recorded_attempts', 'scored_attempts')), 'Excess native trials')
        if cov['scored_attempts'] is not None and cov['recorded_attempts'] is not None:
            require(cov['scored_attempts'] <= cov['recorded_attempts']
                    and cov['unscored_attempts'] == cov['recorded_attempts'] - cov['scored_attempts'], 'Invalid coverage counts')
        else:
            require(cov['unscored_attempts'] is None, 'Invented unscored count')
        attempts = data['policy']['attempts']['maximum']
        if attempts is not None and cov['expected_attempts'] is not None:
            require(cov['expected_attempts'] == len(ids) * attempts, 'Expected attempt mismatch')
        recorded = [o for o in data['observations'] if o['arm'] == arm['name']]
        if cov['recorded_attempts'] is not None:
            require(len(recorded) <= cov['recorded_attempts'], 'Details exceed recorded trials')
        if cov['scored_attempts'] is not None:
            require(sum(o['score'] is not None for o in recorded) <= cov['scored_attempts'], 'Details exceed scored trials')
        if cov['case_details'] == 'complete':
            require(len(recorded) == cov['recorded_attempts']
                    and sum(o['score'] is not None for o in recorded) == cov['scored_attempts'], 'Case detail coverage mismatch')
        if attempts is not None:
            require(all(o['attempt'] is None or o['attempt'] <= attempts for o in recorded), 'Excess attempt index')
        rubric = arm['rubric']; closed(rubric, ('passed_cases', 'total_cases', 'threshold'))
        optional(rubric['passed_cases'], lambda v: count(v, MAX_CASES)); optional(rubric['total_cases'], lambda v: count(v, MAX_CASES))
        optional(rubric['threshold'], number)
        policy_threshold = data['policy']['attempts']['pass_threshold']
        if rubric['threshold'] is not None and policy_threshold is not None:
            require(rubric['threshold'] == policy_threshold, 'Rubric attempt-policy threshold mismatch')
        threshold = rubric['threshold'] if rubric['threshold'] is not None else policy_threshold
        require((rubric['passed_cases'] is None) == (rubric['total_cases'] is None),
                'Missing rubric aggregate pair')
        if rubric['total_cases'] is not None:
            require(rubric['total_cases'] == len(ids) and rubric['passed_cases'] is not None
                    and rubric['passed_cases'] <= rubric['total_cases'], 'Rubric denominator mismatch')
            if cov['case_details'] == 'complete':
                passes = {o['case_id'] for o in recorded if o['rubric_pass'] is True}
                require(len(passes) == rubric['passed_cases'], 'Rubric count mismatch')
        if threshold is not None:
            if cov['case_details'] == 'complete':
                require(all(o['score'] is None or o['rubric_pass'] is not None for o in recorded),
                        'Missing scored rubric outcome')
            require(all(o['rubric_pass'] is None or o['score'] is not None
                        and o['rubric_pass'] == (o['score'] >= threshold) for o in recorded),
                    'Contradictory native rubric pass')
        if arm['execution_status'] == 'succeeded':
            require(arm['execution_error_count'] == 0, 'Succeeded arm has errors')
        elif availability['status'] != 'unavailable':
            require(availability['status'] == 'incomplete' and 'execution_incomplete' in availability['reasons'],
                    'Missing execution limitation')
        if availability['status'] == 'incomplete':
            if cov['recorded_attempts'] != cov['expected_attempts'] \
                    or cov['scored_attempts'] != cov['expected_attempts']:
                require('coverage_missing' in availability['reasons'], 'Missing coverage limitation')
            if cov['case_details'] != 'complete':
                require('case_details_missing' in availability['reasons'], 'Missing case detail limitation')
        if availability['status'] == 'complete':
            require(arm['execution_status'] == 'succeeded' and cov['scored_attempts'] == cov['expected_attempts']
                    and cov['recorded_attempts'] == cov['expected_attempts'] and cov['case_details'] == 'complete', 'Incomplete evidence promotion')
            require(all(o['attempt'] is not None for o in recorded), 'Unknown attempt identity')
    require(len(arm_names) == len(set(arm_names)), 'Duplicate arm')
    require(type(data['metrics']) is list and len(data['metrics']) <= 4, 'Metric limit')
    metric_names = []
    for row in data['metrics']:
        closed(row, ('name', 'unit', 'value')); require(row['name'] in reports.METRICS and row['unit'] == 'score', 'Unknown native metric')
        number(row['value'], -1 if row['name'] == 'Skill Lift' else 0, 1); metric_names.append(row['name'])
    require(len(metric_names) == len(set(metric_names)), 'Duplicate metric')
    require(type(data['scans']) is list and len(data['scans']) <= 100, 'Scan limit')
    scanner_ids = []
    for scan in data['scans']:
        scan_fields = ('scanner', 'status', 'passed', 'severity_counts', 'references')
        closed(scan, scan_fields + ('blocking',) if 'blocking' in scan else scan_fields)
        boolean(scan.get('blocking', True))
        token(scan['scanner']); scanner_ids.append(scan['scanner']); enum(scan['status'], ('passed', 'failed', 'incomplete', 'skipped'))
        optional(scan['passed'], boolean)
        if scan['status'] in ('passed', 'failed'):
            require(scan['passed'] == (scan['status'] == 'passed'), 'Contradictory scanner outcome')
        closed(scan['severity_counts'], ('critical', 'high', 'medium', 'low'))
        for val in scan['severity_counts'].values():
            optional(val, count)
        require(type(scan['references']) is list and set(scan['references']) <= ref_ids, 'Dangling scan reference')
        if scan['status'] in ('incomplete', 'skipped'):
            require('scan_incomplete' in availability['reasons'], 'Missing scan limitation')
        if availability['status'] == 'complete':
            require(scan['status'] not in ('incomplete', 'skipped'), 'Incomplete scan promotion')
            require(bool(scan['references']), 'Complete scan missing reference')
    require(len(scanner_ids) == len(set(scanner_ids)), 'Duplicate scanner')
    severity_fields = ('critical', 'high', 'medium', 'low')
    detailed = {scanner: dict.fromkeys(severity_fields, 0) for scanner in scanner_ids}
    require(type(data['findings']) is list and len(data['findings']) <= MAX_TRIALS, 'Finding limit')
    for finding in data['findings']:
        closed(finding, ('scanner', 'severity', 'check', 'member', 'line', 'reference'))
        require(finding['scanner'] in scanner_ids, 'Unknown finding scanner')
        enum(finding['severity'], ('critical', 'high', 'medium', 'low', 'info'))
        if finding['severity'] in severity_fields:
            detailed[finding['scanner']][finding['severity']] += 1
        optional(finding['check'], token); optional(finding['member'], relative)
        optional(finding['line'], lambda v: count(v, 10000000))
        require(finding['reference'] in ref_ids, 'Dangling finding reference')
    for scan in data['scans']:
        for level, total in detailed[scan['scanner']].items():
            reported = scan['severity_counts'][level]
            require(reported is None or total <= reported, 'Detailed findings exceed scanner total')
    aggregate = next((scan for scan in data['scans'] if scan['scanner'] == 'catalog-total'), None)
    if aggregate is not None:
        enum(aggregate['status'], ('passed', 'failed', 'incomplete'))
        require(type(aggregate['passed']) is bool, 'Missing static aggregate pass result')
        require(all(total is not None for total in aggregate['severity_counts'].values()),
                'Unknown static aggregate totals')
        validators = [scan for scan in data['scans'] if scan is not aggregate]
        for level, total in aggregate['severity_counts'].items():
            if total is not None:
                require(sum(counts[level] for counts in detailed.values()) <= total,
                        'Detailed findings exceed aggregate total')
                known = [scan['severity_counts'][level] for scan in validators]
                require(sum(value for value in known if value is not None) <= total,
                        'Scanner totals exceed aggregate total')
                if known and all(value is not None for value in known):
                    require(sum(known) == total, 'Contradictory static finding counts')
    if availability['status'] == 'unavailable':
        require('results_not_supplied' in availability['reasons'], 'Unavailable evidence missing results limitation')
        require(not data['observations'] and not data['metrics'] and not data['scans'] and not data['findings'], 'Unavailable evidence has observations')
        for arm in data['arms']:
            require(all(arm['coverage'][k] is None for k in ('recorded_attempts', 'scored_attempts', 'unscored_attempts')), 'Invented observed count')
    elif data['kind'] == 'behavioral':
        require(not data['scans'] and not data['findings'], 'Behavioral report implies static scans')
        require(sorted(arm_names) == ['with_skill', 'without_skill'], 'Missing comparison arms')
        if len(data['metrics']) < 4:
            require(availability['status'] == 'incomplete' and 'coverage_missing' in availability['reasons'],
                    'Missing metric coverage limitation')
        if data['source']['content']['digest'] is None:
            require(availability['status'] == 'incomplete' and 'source_unavailable' in availability['reasons'],
                    'Behavioral source unavailable')
        if behavioral_identity_missing(data):
            require(availability['status'] == 'incomplete' and 'metadata_missing' in availability['reasons'],
                    'Missing behavioral identity limitation')
        if availability['status'] == 'complete':
            require(bool(ids), 'Empty complete cohort')
            require(len(data['metrics']) == 4, 'Incomplete metrics')
    if data['kind'] == 'static':
        require(not data['arms'] and not data['metrics'] and not data['observations'], 'Static report implies behavior')
        require(availability['status'] == 'unavailable' or bool(data['scans']), 'Static evidence missing scans')
        require(availability['status'] == 'unavailable' or aggregate is not None,
                'Static evidence missing aggregate scan')
        if availability['status'] != 'unavailable' and data['source']['content']['digest'] is None:
            require(availability['status'] == 'incomplete' and 'source_unavailable' in availability['reasons'],
                    'Static source unavailable')
    if availability['status'] == 'complete':
        require(all(r['availability'] == 'available' for r in references), 'Unavailable reference promotion')
    for obs in data['observations']:
        if any(refs_by_id[ref]['provenance'] == 'reviewed_extract' for ref in obs['references']):
            require(identity({key: obs[key] for key in OBSERVATION_FIELDS}) in REVIEWED_OBSERVATION_PAYLOADS,
                    'Unrecognized reviewed observation payload')
    if data['kind'] == 'behavioral' and any(ref['provenance'] == 'reviewed_extract' for ref in references):
        require(availability['provenance'] == 'reviewed_extract', 'Reviewed availability provenance mismatch')
        require(all(REVIEWED_METRIC_VALUES.get(row['name']) == row['value'] for row in data['metrics']),
                'Unrecognized reviewed metric value')
        # A missing workspace association may only remove attribution. The
        # reviewed payload/reference/execution pins still authenticate the run;
        # this exact unknown source cannot claim a repository or local bytes.
        require(identity(data['source']) in REVIEWED_SOURCE_IDENTITIES
                or data['source'] == source('podman', path='.apm/skills/podman'),
                'Unrecognized reviewed source identity')
        require(identity({key: data[key] for key in ('run_id', 'dataset', 'policy', 'arms')})
                in REVIEWED_EXECUTION_CONTRACTS, 'Unrecognized reviewed execution contract')
    if data['kind'] == 'static' and aggregate is not None:
        report_pattern = r'reports/' + re.escape(data['source']['skill_id']) + r'/skillevaluator-output-[0-9]{14}\.json'
        report_refs = {ref['id'] for ref in references if re.fullmatch(report_pattern, ref['member'])}
        require(all(ref['id'] in report_refs or ref['member'] in ('reports/catalog-summary.json', 'versions.json')
                    for ref in references), 'Static reference skill mismatch')
        require(bool(report_refs) and all(ref in report_refs for ref in aggregate['references'])
                and all(ref in report_refs for scan in validators for ref in scan['references'])
                and all(finding['reference'] in report_refs for finding in data['findings']),
                'Static reference skill mismatch')
        report_keys = {(refs_by_id[ref]['artifact_id'], refs_by_id[ref]['member'], refs_by_id[ref]['digest']) for ref in report_refs}
        require(len(report_keys) == 1 and all(refs_by_id[ref]['locator'] == [] for ref in aggregate['references']),
                'Static claim locator mismatch')
        positions = {}; index = 0
        for scan in validators:
            diagnostic = (scan['status'] in ('incomplete', 'skipped') and scan['passed'] is None
                          and all(value is None for value in scan['severity_counts'].values())
                          and all(refs_by_id[ref]['locator'] == [] for ref in scan['references']))
            locator = [] if diagnostic else ['results', index]
            require(all(refs_by_id[ref]['locator'] == locator for ref in scan['references']), 'Static claim locator mismatch')
            if not diagnostic:
                positions[scan['scanner']] = index; index += 1
        finding_indices = dict.fromkeys(positions, 0)
        for finding in data['findings']:
            scanner = finding['scanner']
            require(scanner in positions and refs_by_id[finding['reference']]['locator'] ==
                    ['results', positions[scanner], 'findings', finding_indices[scanner]], 'Static claim locator mismatch')
            finding_indices[scanner] += 1
        require(aggregate['passed'] == all(scan['passed'] is True or not scan.get('blocking', True)
                                         for scan in validators), 'Static aggregate gate contradiction')
        if data['policy']['fields']['evaluator_revision'] in (profiles.NEXT['revision'], *static_evaluator.STATIC_OWNERS):
            failing = [scan for scan in validators if scan.get('blocking', True) and scan['passed'] is not True]
            expected = ('passed' if not failing else 'incomplete'
                        if all(scan['status'] == 'incomplete' for scan in failing) else 'failed')
        else:
            expected = ('incomplete' if any(scan['status'] == 'incomplete' for scan in validators)
                        else 'passed' if aggregate['passed'] else 'failed')
        require(aggregate['status'] == expected, 'Static aggregate status contradiction')
    depth(data, 12 if public else 32)
    if public:
        require(len(encoded(data)) <= PUBLIC_LIMIT, 'Public report size exceeded')
    return data


def static_claim_identity(data, blocking_defaults):
    claims = {key: copy.deepcopy(data[key]) for key in
              ('source', 'run_id', 'dataset', 'policy', 'arms', 'metrics', 'scans', 'findings', 'references')}
    if data['schema_version'] == 2: claims['custom'] = copy.deepcopy(data['custom'])
    if 'scanner_runtime' in data: claims['scanner_runtime'] = copy.deepcopy(data['scanner_runtime'])
    if 'coverage_caveats' in data: claims['coverage_caveats'] = copy.deepcopy(data['coverage_caveats'])
    claims['provenance'] = data['availability']['provenance']
    defaults = dict(blocking_defaults)
    for scan in claims['scans']:
        scan.setdefault('blocking', defaults.get(scan['scanner'], True))
        scan['references'].sort()
    claims['scans'].sort(key=lambda scan: scan['scanner'])
    claims['findings'].sort(key=lambda finding: finding['reference'])
    for ref in claims['references']:
        ref.pop('availability')  # Conservative availability changes do not relabel native claims.
    claims['references'].sort(key=lambda ref: ref['id'])
    return identity(claims)


def input_guard(directories, states, members, budget=None):
    """Retain capture state until the last publication check, without rereading bytes."""
    directories = dict(directories); states = dict(states); members = dict(members)
    def verify():
        if budget is not None: budget.verify_repository()
        verify_directory_states(states, directories)
        verify_file_states(members, directories, states)
    return verify


class _CapturedRecord(dict):
    """JSON-compatible data with private, nonserialized input-state guards."""
    __slots__ = ('_input_guards',)

    def __init__(self, data, input_guards=()):
        super().__init__(data)
        object.__setattr__(self, '_input_guards', tuple(input_guards))

    def __setattr__(self, name, value):
        raise AttributeError('Immutable input capture')

    def __deepcopy__(self, memo):
        result = _CapturedRecord(copy.deepcopy(dict(self), memo), self._input_guards)
        memo[id(self)] = result
        return result


def record_guards(data):
    return data._input_guards if type(data) in (_CapturedRecord, _StaticEvidence, _BehavioralEvidence) else ()


class _StaticEvidence(_CapturedRecord):
    """A data-only record with a transient witness from captured native bytes."""
    __slots__ = ('_claim_digest', '_blocking_defaults')

    def __init__(self, data, claim_digest, blocking_defaults, input_guards=()):
        super().__init__(data, input_guards)
        object.__setattr__(self, '_claim_digest', claim_digest)
        object.__setattr__(self, '_blocking_defaults', blocking_defaults)

    def __setattr__(self, name, value):
        raise AttributeError('Immutable native witness')

    def __deepcopy__(self, memo):
        result = _StaticEvidence(copy.deepcopy(dict(self), memo), self._claim_digest, self._blocking_defaults, self._input_guards)
        memo[id(self)] = result
        return result


def behavioral_claim_identity(data):
    claims = {key: copy.deepcopy(data[key]) for key in
              ('source', 'run_id', 'dataset', 'policy', 'arms', 'observations', 'metrics', 'references')}
    if 'benchmark' in data: claims['benchmark'] = copy.deepcopy(data['benchmark'])
    if data['schema_version'] == 2: claims['custom'] = copy.deepcopy(data['custom'])
    claims['provenance'] = data['availability']['provenance']
    for obs in claims['observations']:
        obs['references'].sort()
        if 'custom' in obs:
            obs['custom']['references'].sort()
            for measurement in obs['custom']['measurements']: measurement['references'].sort()
    claims['observations'].sort(key=lambda obs: obs['id'])
    claims['metrics'].sort(key=lambda row: row['name'])
    for ref in claims['references']:
        ref.pop('availability')
    claims['references'].sort(key=lambda ref: ref['id'])
    return identity(claims)


class _BehavioralEvidence(_CapturedRecord):
    """Transient witness for ordinary runtime observations and headline metrics."""
    __slots__ = ('_claim_digest', '_required_reasons')

    def __init__(self, data, claim_digest, *, required_reasons=None, input_guards=()):
        super().__init__(data, input_guards)
        object.__setattr__(self, '_claim_digest', claim_digest)
        object.__setattr__(self, '_required_reasons', tuple(data['availability']['reasons']
                           if required_reasons is None else required_reasons))

    def __setattr__(self, name, value):
        raise AttributeError('Immutable native witness')

    def __deepcopy__(self, memo):
        result = _BehavioralEvidence(copy.deepcopy(dict(self), memo), self._claim_digest,
                                     required_reasons=self._required_reasons, input_guards=self._input_guards)
        memo[id(self)] = result
        return result


def behavioral_claims_need_witness(data):
    # Every measured behavioral record needs authenticated claims. Reviewed
    # references are independently bound to the pinned payload allowlists.
    return (data['kind'] == 'behavioral' and data['availability']['status'] != 'unavailable'
            and not (data['references'] and all(ref['provenance'] == 'reviewed_extract' for ref in data['references'])))


def project(data, *, static_bundle=None, behavioral_bundle=None):
    observed_at = utc_now()
    guards = list(record_guards(data))
    validate_evidence(data, _observed_at=observed_at)
    if data['kind'] == 'static' and data['availability']['status'] != 'unavailable':
        if type(data) is _StaticEvidence:
            witness = data
        else:
            require(static_bundle is not None, 'Retained native static bundle required')
            witness = normalize_static(Path(static_bundle), data['source']['skill_id'])
        require(static_claim_identity(data, witness._blocking_defaults) == witness._claim_digest,
                'Static claims differ from retained native evidence')
        guards.extend(record_guards(witness))
    if behavioral_claims_need_witness(data):
        if type(data) is _BehavioralEvidence:
            witness = data
        else:
            require(behavioral_bundle is not None, 'Retained native behavioral bundle required')
            witness = normalize_behavioral(Path(behavioral_bundle), data['source']['skill_id'], data['run_id'])
            require(type(witness) is _BehavioralEvidence, 'Native behavioral provenance mismatch')
        require(behavioral_claim_identity(data) == witness._claim_digest,
                'Behavioral claims differ from retained native evidence')
        require(set(witness._required_reasons) <= set(data['availability']['reasons']),
                'Native behavioral limitations removed')
        guards.extend(record_guards(witness))
    # Every object is rebuilt from fixed fields. A native report is never accepted.
    out = {key: copy.deepcopy(data[key]) for key in ('schema_version', 'kind', 'source', 'run_id', 'dataset',
           'policy', 'arms', 'metrics', 'scans', 'findings', 'references', 'availability')}
    if 'benchmark' in data: out['benchmark'] = copy.deepcopy(data['benchmark'])
    if 'scanner_runtime' in data: out['scanner_runtime'] = copy.deepcopy(data['scanner_runtime'])
    if 'coverage_caveats' in data: out['coverage_caveats'] = copy.deepcopy(data['coverage_caveats'])
    out['observations'] = [{key: copy.deepcopy(obs[key]) for key in
        OBSERVATION_FIELDS + (('security_evidence',) if 'security_evidence' in obs else ())}
        for obs in data['observations']]
    if 'producer_profile' in data['policy']:
        for original, obs in zip(data['observations'], out['observations']):
            for key in ('raw_scores', 'raw_deterministic_scores'): obs[key] = copy.deepcopy(original[key])
    if data['schema_version'] == 2:
        out['custom'] = copy.deepcopy(data['custom'])
        for original, obs in zip(data['observations'], out['observations']): obs['custom'] = copy.deepcopy(original['custom'])
    validate_evidence(out, public=True, _observed_at=observed_at)
    return _CapturedRecord(out, tuple(dict.fromkeys(guards)))


def load_extract(root, *, budget=None, _observed_at=None, directory_identities=None, entries=None, directory_states=None, file_states=None, reader=None):
    path = root / 'extract-manifest.json'
    present = path in entries if entries is not None else path.exists()
    if not present:
        return None
    raw = reader(path) if reader is not None else read_bytes(path, budget=budget, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)
    require(digest_bytes(raw) in REVIEWED_EXTRACT_MANIFESTS, 'Unrecognized reviewed extract manifest')
    value = parse_json(raw)
    closed(value, ('schema_version', 'artifact_id', 'archive_digest', 'origin', 'members'))
    require(value['schema_version'] == 1, 'Extract version'); token(value['artifact_id']); sha(value['archive_digest'])
    closed(value['origin'], ('repository', 'run_id', 'artifact_id', 'artifact_name', 'expires_at'))
    repository(value['origin']['repository'])
    for key in ('run_id', 'artifact_id', 'artifact_name'):
        token(value['origin'][key])
    require(bool(re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z', value['origin']['expires_at'])), 'Invalid recorded expiration')
    require(value['artifact_id'] == 'github-artifact-' + value['origin']['artifact_id'], 'Extract artifact identity mismatch')
    require(REVIEWED_REFERENCE_EXPIRY.get((value['artifact_id'], value['archive_digest']))
            == value['origin']['expires_at'], 'Reviewed reference expiration mismatch')
    require(type(value['members']) is list and len(value['members']) <= MAX_REFERENCES, 'Extract limit')
    names = []
    for row in value['members']:
        closed(row, ('member', 'original_digest', 'extract_digest'))
        relative(row['member']); sha(row['original_digest']); sha(row['extract_digest']); names.append(row['member'])
    require(len(names) == len(set(names)), 'Duplicate extract member')
    value['_members_by_name'] = {row['member']: row for row in value['members']}
    # One time observation for the whole normalization. No durable-original
    # retention is recorded by the supported manifest, so expiry is fail-closed.
    deadline = datetime.fromisoformat(value['origin']['expires_at'])
    observed_at = utc_now() if _observed_at is None else _observed_at
    value['_reference_availability'] = 'expired' if observed_at >= deadline else 'available'
    return value


def select_run(root, name, selected, *, entries=None, directory_identities=None):
    base = root / 'results' / name
    safe_path(base, directory=True, directory_identities=directory_identities)
    candidates = []
    children = sorted(p for p in entries if p.parent == base) if entries is not None else base.iterdir()
    for path in children:
        # An alias is never selected or followed; all links are rejected by safe_tree.
        if path.name == 'latest':
            continue
        safe_path(path, directory=True, directory_identities=directory_identities); token(path.name); candidates.append(path)
    if selected:
        token(selected)
        matches = [p for p in candidates if p.name == selected]
        require(len(matches) == 1, 'Unknown selected run')
        return matches[0]
    require(len(candidates) == 1, 'Explicit --run required for ambiguous native runs')
    return candidates[0]


def scanner_owner_matches(runtime, revision):
    expected = revision if revision in (profiles.NEXT['revision'], *static_evaluator.STATIC_OWNERS) else None
    return runtime.get('evaluator_revision') == expected


def validate_runtime_versions(versions, *, historical_read=False):
    require(type(versions) is dict, 'Native versions object required')
    if 'scanner_runtime' in versions:
        require(versions['scanner_runtime'] in SCANNER_RUNTIMES
                and versions.get('scanners') == versions['scanner_runtime']['versions']
                and versions.get('skillspector_revision') == versions['scanner_runtime']['skillspector_revision'],
                'Unsupported or contradictory scanner provenance')
    elif versions.get('skillspector_revision') in (SCANNER_RUNTIME_2134['skillspector_revision'],
                                                 SCANNER_RUNTIME_2136['skillspector_revision'],
                                                 SCANNER_RUNTIME['skillspector_revision']):
        require(False, 'Missing scanner runtime provenance')
    if versions.get('producer_profile') in static_evaluator.STATIC_PRODUCERS:
        require(versions.get('scanner_runtime') in STATIC_SCANNER_RUNTIMES
                and scanner_owner_matches(versions['scanner_runtime'], versions.get('evaluator_revision')),
                'Missing static candidate scanner provenance')
        return static_evaluator.validate_owner(versions)
    historical_reader = (
        historical_read and versions.get('evaluator_revision') in (None, profiles.HISTORICAL_REVISION)
        and versions.get('skillevaluator') in (None, '0.3.0') and static_evaluator.is_owner()
    )
    if historical_reader:
        # Authenticate the reader independently of the provenance in the input.
        # The benchmark installation carries a separately pinned provider patch.
        installed = installed_version('skillevaluator')
        try:
            backend = installed_version('aeb-gh-fixture')
        except PackageNotFoundError:
            backend = None
        candidate = next((entry for entry in (profiles.CURRENT_RELEASE, profiles.RELEASE_BENCHMARK,
                                               profiles.RETAINED_RELEASE_BENCHMARK)
                          if entry['version'] == installed and entry['dependencies']['aeb-gh-fixture'] == backend), None)
        if candidate is None:
            owner = next(entry for entry in static_evaluator.STATIC_OWNERS.values() if entry['skillevaluator'] == installed)
            static_evaluator.validate_install(owner=owner)
        else:
            try:
                profiles.validate_install(candidate)
            except ValueError:
                from benchmark_native import native_profile

                profiles.validate_install(native_profile(backend=candidate))
    profile = profiles.runtime(versions, owning=not historical_reader)
    if 'scanner_runtime' in versions:
        require(scanner_owner_matches(versions['scanner_runtime'], profile['revision']),
                'Scanner adapter and evaluator owner differ')
    return profile


def native_error_count(record):
    errors = record.get('execution_errors', [])
    require(type(errors) is list and len(errors) <= MAX_TRIALS
            and all(type(error) is str for error in errors), 'Invalid native execution errors')
    return len(errors)


def historical_trial_ordinal(trial):
    """Read the explicit attempt marker the original collector used."""
    match = re.search(r'attempt0*(\d+)', trial, flags=re.IGNORECASE)
    return int(match[1]) if match else None


def historical_metric_mean(row, metrics):
    # Recorded v0.3 overalls averaged native metric values before rounding.
    return sum(row[name] for name in metrics) / len(metrics)


def validate_native_metrics(agent, *, historical_scores=False):
    """Check native report arithmetic using the pinned producer's pure helpers."""
    from skillevaluator.tier3.harbor.collector import _compute_lift
    from skillevaluator.tier3.harbor.metrics import DEFAULT_METRICS, dimension_scores
    lift = agent['lift']; require(type(lift) is dict, 'Invalid native metric components')
    scores = {}
    for arm in ('with_skill', 'without_skill'):
        supplied = agent.get(arm, {})
        require(type(supplied) is dict, 'Invalid native metric components')
        scores[arm] = {key: supplied[key] for key in DEFAULT_METRICS if key in supplied}
        for value in scores[arm].values(): number(value)
        for key in DEFAULT_METRICS:
            if key not in lift: continue
            row = lift[key]; require(type(row) is dict, 'Invalid native metric components')
            if arm in row:
                number(row[arm])
                require(key not in scores[arm] or scores[arm][key] == row[arm], 'Native metric component disagreement')
                scores[arm][key] = row[arm]
    expected = _compute_lift(scores['with_skill'], scores['without_skill'])
    if not all(set(DEFAULT_METRICS) <= set(values) for values in scores.values()):
        expected.pop('overall', None)  # This adapter requires the v2 metric set.
    elif historical_scores:
        with_skill, without_skill = (
            historical_metric_mean(scores[arm], DEFAULT_METRICS)
            for arm in ('with_skill', 'without_skill')
        )
        expected['overall'] = {
            'with_skill': round(with_skill, 4), 'without_skill': round(without_skill, 4),
            'delta': round(with_skill - without_skill, 4),
        }
    for key, row in lift.items():
        if key not in (*DEFAULT_METRICS, 'overall'): continue
        require(type(row) is dict, 'Invalid native metric components')
        for field in ('with_skill', 'without_skill', 'delta'):
            if field in row: number(row[field], -1 if field == 'delta' else 0)
        if key in expected:
            for field, value in row.items():
                if field in expected[key]:
                    require(value == expected[key][field], 'Native metric component disagreement')
    complete = 'overall' in expected
    if not complete and type(lift.get('overall')) is dict:
        row = lift['overall']
        if all(key in row for key in ('with_skill', 'without_skill', 'delta')):
            # Overall component means and their difference are rounded separately.
            require(abs(row['delta'] - round(row['with_skill'] - row['without_skill'], 4)) <= 0.0001000000001,
                    'Native metric component disagreement')
    for arm in ('with_skill', 'without_skill'):
        supplied = agent.get('dimensions_' + arm, {})
        require(type(supplied) is dict, 'Invalid native metric dimensions')
        dimensions = dimension_scores(scores[arm])
        for key, row in supplied.items():
            require(type(row) is dict, 'Invalid native metric dimensions')
            if key in dimensions:
                if 'score' in row:
                    number(row['score'])
                    require(row['score'] == dimensions[key]['score'], 'Native metric dimension disagreement')
                if 'sources' in row:
                    require(type(row['sources']) is dict, 'Invalid native metric dimensions')
                    for value in row['sources'].values(): number(value)
                    require(row['sources'] == dimensions[key]['sources'], 'Native metric dimension disagreement')
            elif arm == 'with_skill' and key in ('effectiveness', 'correctness', 'discoverability'):
                complete = False
    return complete


def validate_summary_rollups(payload, cases, ids, maximum, stop_on_pass, *, versioned=False):
    """Reconcile retained collector rollups without collecting filesystem data."""
    def match(record, key, expected):
        if key in record:
            value = record[key]
            numeric = key in ('best_score', 'rate', 'avg_attempts_used') and expected is not None
            require(type(value) in (int, float) if numeric else type(value) is type(expected),
                    'Summary case/aggregate rollup type mismatch')
            require(value == expected, 'Summary case/aggregate rollup mismatch')
    k = payload.get('k', maximum)
    if k is not None:
        require(type(k) is int and 1 <= k <= 100, 'Summary aggregate rollup attempt limit')
        if maximum is not None: match(payload, 'k', maximum)
    stop = payload.get('stop_on_pass', stop_on_pass)
    if stop is not None:
        require(type(stop) is bool, 'Summary aggregate rollup stop policy')
        if stop_on_pass is not None: match(payload, 'stop_on_pass', stop_on_pass)
    passed_cases = 0; attempts_used = 0
    threshold = payload.get('pass_threshold')
    optional(threshold, number)
    for row in cases.values():
        attempts = row.get('attempts', [])
        if threshold is not None and not versioned:
            for attempt in attempts:
                if attempt.get('score') is not None and attempt.get('passed') is not None:
                    match(attempt, 'passed', attempt['score'] >= threshold)
        passing = [i for i, attempt in enumerate(attempts, 1) if attempt.get('passed') is True]
        scores = [attempt['score'] for attempt in attempts if attempt.get('score') is not None]
        passed = bool(passing); used = len(attempts)
        match(row, 'passed', passed)
        match(row, 'first_pass_attempt', passing[0] if passing else None)
        match(row, 'best_score', max(scores) if scores else None)
        match(row, 'attempts_used', used)
        for key in ('attempts_skipped', 'attempts_missing'):
            if key in row:
                require(type(row[key]) is int and 0 <= row[key] <= MAX_TRIALS, 'Summary case rollup attempt bounds')
        if k is not None and all(key in row for key in ('attempts_skipped', 'attempts_missing')):
            require(row['attempts_skipped'] + row['attempts_missing'] == max(0, k - used),
                    'Summary case rollup missing attempts')
        if k is not None and stop is not None:
            unscored = max(0, k - used)
            skipped = unscored if stop and passed else 0
            match(row, 'attempts_skipped', skipped)
            match(row, 'attempts_missing', 0 if skipped else unscored)
        passed_cases += passed; attempts_used += used
    total = len(ids)
    if payload:
        match(payload, 'total_cases', total)
        match(payload, 'extra_cases', [])
        if k is not None: match(payload, 'max_attempts_possible', total * k)
    recorded_passes = payload.get('passed_cases')
    if recorded_passes is not None:
        require(type(recorded_passes) is int and passed_cases <= recorded_passes <= passed_cases + total - len(cases),
                'Summary aggregate rollup case bounds')
        match(payload, 'failed_cases', total - recorded_passes)
        match(payload, 'rate', round(recorded_passes / total, 4) if total else 0.0)
    recorded_attempts = payload.get('attempts_used')
    if recorded_attempts is not None:
        require(type(recorded_attempts) is int and attempts_used <= recorded_attempts <= MAX_TRIALS,
                'Summary aggregate rollup attempt bounds')
        match(payload, 'avg_attempts_used', round(recorded_attempts / total, 4) if total else 0.0)
    if set(cases) == set(ids):
        match(payload, 'passed_cases', passed_cases)
        match(payload, 'failed_cases', total - passed_cases)
        match(payload, 'attempts_used', attempts_used)
        match(payload, 'rate', round(passed_cases / total, 4) if total else 0.0)
        match(payload, 'avg_attempts_used', round(attempts_used / total, 4) if total else 0.0)


def validate_101_partial_rollups(payload, cases, ids, maximum, stop_on_pass, *, versioned=True):
    """Authenticate the release's incomplete rollups without inventing a rate."""
    partial = {'failed_cases', 'unresolved_cases', 'rate', 'rate_interval'}
    require(partial | {'passed_cases', 'attempts_used'} <= payload.keys()
                    and payload['rate'] is None and payload['rate_interval'] is None
                    and set(cases) == set(ids) and maximum in reports.MODES.values() and stop_on_pass is False,
                    'Invalid partial benchmark rollup')
    validate_summary_rollups({key: value for key, value in payload.items() if key not in partial},
             cases, ids, maximum, stop_on_pass, versioned=versioned)
    require(all(type(row.get('attempts_recovered')) is int and row['attempts_recovered'] == 0
                        and type(row.get('attempts')) is list and len(row['attempts']) <= maximum
                        and type(row.get('passed')) is bool for row in cases.values()),
                    'Unexpected partial benchmark attempt accounting')
    passed = sum(row['passed'] for row in cases.values())
    failed = sum(len(row['attempts']) == maximum and not row['passed'] for row in cases.values())
    unresolved = len(ids) - passed - failed
    require(payload['attempts_used'] < len(ids) * maximum
                    and type(payload['failed_cases']) is int and payload['failed_cases'] == failed
                    and type(payload['unresolved_cases']) is int and payload['unresolved_cases'] == unresolved,
                    'Partial benchmark rollup count mismatch')


def reconcile_native_arm(agent, arm, summary, observations, details, *, candidate=False, historical_scores=False):
    """Bind retained arm summaries and report metrics to logical trial scores."""
    from skillevaluator.tier3.harbor.metrics import DEFAULT_METRICS, average_metrics, dimension_scores, overall_score
    from skillevaluator.tier3.harbor.collector import _average_overall
    condition = agent['conditions'][arm]
    for field, summary_field in (('agent_runtime_failures', None), ('trial_failures', 'trial_failures'),
                                 ('job_failures', 'job_failure')):
        carriers = agent.get(field, {})
        require(type(carriers) is dict and set(carriers) <= {'with_skill', 'without_skill'},
                'Invalid native failure carriers')
        if arm not in carriers: continue
        value = carriers[arm]
        require(type(value) is str if field == 'job_failures' else type(value) is list
                and len(value) <= MAX_TRIALS and all(type(row) is dict for row in value),
                'Invalid native failure carriers')
        if summary_field in summary:
            require(value == summary[summary_field], 'Native failure carrier disagreement')
        require(not value or condition.get('execution_status') != 'succeeded'
                and native_error_count(condition) > 0, 'Native failure contradicts successful execution')
    components = {}
    for carrier in (agent.get(arm, {}), summary.get('scores', {}),
                    {key: row[arm] for key, row in agent.get('lift', {}).items()
                     if key in DEFAULT_METRICS and type(row) is dict and arm in row}):
        require(type(carrier) is dict, 'Invalid native arm scores')
        for key in DEFAULT_METRICS:
            if key not in carrier: continue
            number(carrier[key])
            require(key not in components or components[key] == carrier[key], 'Native arm score disagreement')
            components[key] = carrier[key]
    dimensions = summary.get('dimensions', {})
    require(type(dimensions) is dict, 'Invalid native arm dimensions')
    expected_dimensions = dimension_scores(components)
    for key, row in dimensions.items():
        require(type(row) is dict, 'Invalid native arm dimensions')
        if 'score' in row: number(row['score'])
        if 'sources' in row:
            require(type(row['sources']) is dict, 'Invalid native arm dimensions')
            for value in row['sources'].values(): number(value)
        if key in expected_dimensions:
            for field in ('score', 'sources'):
                if field in row:
                    require(row[field] == expected_dimensions[key][field], 'Native arm dimension disagreement')
    if summary.get('metric_set') is not None:
        require(summary['metric_set'] == 'skill-evaluator-default-v2', 'Native metric-set identity mismatch')
    if summary.get('metrics') is not None:
        require(summary['metrics'] == list(DEFAULT_METRICS), 'Native metric-set identity mismatch')
    rewards = [obs['scores'] for obs in observations if obs['score'] is not None]
    complete = all(all(row.get(key) is not None for key in DEFAULT_METRICS) for row in rewards)
    for row in rewards:
        for value in row.values(): optional(value, number)
        if all(row.get(key) is not None for key in DEFAULT_METRICS):
            score = historical_metric_mean(row, DEFAULT_METRICS) if historical_scores else overall_score(row)
            require(row['overall'] == round(score, 4), 'Native trial metric disagreement')
    optional(summary.get('overall_score'), number)
    if details == 'complete' and complete and rewards and len(rewards) == len(observations):
        means = average_metrics(rewards)[0]
        for key, value in components.items():
            require(value == means[key], 'Native arm/trial metric disagreement')
        if summary.get('overall_score') is not None:
            number(summary['overall_score'])
            overall = (round(sum(historical_metric_mean(row, DEFAULT_METRICS) for row in rewards) / len(rewards), 4)
                       if historical_scores else _average_overall(rewards))
            require(summary['overall_score'] == overall or
                    candidate and abs(summary['overall_score'] - overall) <= 0.000100000001,
                    'Native arm/trial metric disagreement')
    return complete


def summary_error_count(summary):
    errors = native_error_count(summary)
    job_failure = summary.get('job_failure')
    require(job_failure is None or type(job_failure) is str, 'Invalid native job failure')
    trial_failures = summary.get('trial_failures', [])
    require(type(trial_failures) is list and len(trial_failures) <= MAX_TRIALS
            and all(type(failure) is dict for failure in trial_failures), 'Invalid native trial failures')
    # The pinned load_agent_data appends job failure and each trial failure to
    # condition errors; raw summary and reported arm arrays need not have equal lengths.
    return errors + bool(job_failure) + len(trial_failures)


def native_trial_failed(trial, reward):
    """Inspect captured structured carriers only; never run the native collector."""
    from skillevaluator.tier3.harbor.collector import _constituent_default_reward_failure
    try:
        constituent_failure = bool(_constituent_default_reward_failure(trial))
    except OverflowError:
        raise ValueError('Invalid native numeric observation') from None
    return (constituent_failure or trial.get('exception_info') is not None
            or str((reward or {}).get('evaluation_status') or '').casefold() in ('error', 'failed'))


def reconcile_policy(fields, versions, config, agent, attempt_policy):
    """Reject supplied identities that contradict known runtime/configuration values."""
    fields = policy_fields(fields)
    if fields['evaluator_revision'] is not None:
        profiles.by_revision(fields['evaluator_revision'])
    harbor = config.get('harbor', {})
    observations = {key: [versions.get(key)] for key in
                    ('evaluator_revision', 'harbor', 'docker_compose', 'python')}
    observations.update({
        'model': [config.get('provider', {}).get('model'), config.get('agents', {}).get('codex', {}).get('model'),
                  agent.get('model')],
        'provider': [config.get('provider', {}).get('name')],
        'grading': [config.get('grading', {}).get('mode')],
        'environment': [harbor.get('environment', {}).get('value')],
        'concurrency': [harbor.get('n_concurrent')],
        'timeout_multiplier': [harbor.get('timeout_multiplier')],
        'task_source': [config.get('task_source')],
        'stop_on_pass': [harbor.get('stop_on_pass'), attempt_policy.get('stop_on_pass')],
    })
    for key, values in observations.items():
        declared = fields[key]
        if declared is None:
            continue
        for observed in values:
            if observed is None:
                continue
            if key == 'python':
                require(type(declared) is str and type(observed) is str
                        and re.fullmatch(r'[0-9]+(?:\.[0-9]+){0,2}', declared)
                        and re.fullmatch(r'[0-9]+(?:\.[0-9]+){0,2}', observed), 'Invalid Python version')
                expected = tuple(map(int, declared.split('.')))
                actual = tuple(map(int, observed.split('.')))
                require(actual[:len(expected)] == expected, 'Runtime/policy disagreement')
            else:
                if key == 'timeout_multiplier':
                    number(observed, 0.01, 100)
                else:
                    require(type(declared) is type(observed), 'Runtime/policy disagreement')
                require(declared == observed, 'Runtime/policy disagreement')
    for key in ('max_attempts', 'stop_on_pass'):
        config_key = 'n_attempts' if key == 'max_attempts' else key
        if harbor.get(config_key) is not None and attempt_policy.get(key) is not None:
            require(type(harbor[config_key]) is type(attempt_policy[key])
                    and harbor[config_key] == attempt_policy[key], 'Attempt policy disagreement')


def _normalize_behavioral_v1(root, name, selected=None, workspace=ROOT, *, native_layout=False, _numeric_excerpts=None, _custom_admission=False):
    from skillevaluator.tier3.harbor import report_data as native_reports
    from skillevaluator.evaluation import EvaluationService
    from skillevaluator.tier3.case_ids import validate_case_id
    directory_identities = {}
    directory_states = {}
    file_states = {}
    root = safe_path(root, directory=True, directory_identities=directory_identities)
    skill_id(name)
    files = safe_tree(root, directory_identities=directory_identities, directory_states=directory_states,
                      file_states=file_states, native_layout_skill=name if native_layout else None)
    scanned_entries = set(files) | set(directory_identities)
    run = select_run(root, name, selected, entries=scanned_entries, directory_identities=directory_identities)
    budget = ReadBudget()
    observed_at = utc_now()
    extract = load_extract(root, budget=budget, _observed_at=observed_at,
                           directory_identities=directory_identities, entries=scanned_entries, directory_states=directory_states, file_states=file_states)
    artifact = extract['artifact_id'] if extract else run.name
    member_digests = {}
    def read_member(path, *, native_snapshot=False):
        require(path in scanned_entries, 'Unscanned behavioral member')
        require(path not in member_digests, 'Duplicate behavioral member read')
        raw = read_bytes(path, budget=budget, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)
        if native_snapshot:
            require(len(raw) <= native_reports._MAX_JSON_BYTES, 'Native snapshot byte limit')
        value = parse_json(raw)
        if native_snapshot:
            native_reports._validate_json_tree(value)
        member_digests[path] = digest_bytes(raw)
        return value
    result_path = run / 'result.json'; result = read_member(result_path)
    require(type(result) is dict, 'Native report object required')
    require(result.get('skill_name') == name and type(result.get('agents')) is dict
            and set(result['agents']) == {'codex'} and type(result['agents']['codex']) is dict,
            'Native identity/agent mismatch')
    require(result.get('report_status') in ('complete', 'incomplete'), 'Unknown native envelope')
    config_path = run / 'run_config.json'
    has_config = config_path in scanned_entries
    config = read_member(config_path) if has_config else result.get('run_config', {})
    require(type(config) is dict, 'Native configuration object required')
    if has_config and 'run_config' in result:
        require(config == result['run_config'], 'Conflicting native configuration')
    refs = []; ref_ids = set()
    def ref(path, locator=()):
        row = reference_from_digest(root, path, artifact, member_digests[path], locator, extract)
        if row['id'] not in ref_ids:
            refs.append(row)
            ref_ids.add(row['id'])
        return row['id']
    ref(result_path)
    if has_config:
        ref(config_path)
    limitations = set()
    provenance_path = root / 'provenance.json'
    has_provenance = provenance_path in scanned_entries
    provenance = read_member(provenance_path) if has_provenance else {}
    require(type(provenance) is dict, 'Native provenance object required')
    benchmark_meta = provenance.get('benchmark')
    if benchmark_meta is not None:
        import benchmark_evidence
        benchmark_evidence.metadata(benchmark_meta)
    recovery = provenance.get('status') == 'incomplete'
    if recovery:
        require(result['report_status'] == 'incomplete' or result.get('diagnostic_only') is True,
                'Contradictory recovery status')
    if provenance:
        require((recovery and 'schema_version' not in provenance or
                 type(provenance.get('schema_version')) is int and provenance['schema_version'] == 1)
                and (recovery and 'skill' not in provenance or provenance.get('skill') == name),
                'Provenance identity mismatch')
        require(recovery and 'mode' not in provenance or provenance.get('mode') in ('standard', 'confirmation'),
                'Unknown benchmark mode')
    if has_provenance:
        ref(provenance_path)
    versions = {}
    if root / 'versions.json' in scanned_entries:
        versions = read_member(root / 'versions.json')
        ref(root / 'versions.json')
    if any(versions.get(key) is None for key in ('skillevaluator', 'evaluator_revision')):
        limitations.add('metadata_missing')
    producer = validate_runtime_versions(versions, historical_read=benchmark_meta is None)
    released_native = False
    if versions.get('producer_profile') is not None and producer.get('id') == versions['producer_profile']:
        from benchmark_native import NATIVE_OWNERS, released_policy, score_series

        released_native = producer['id'] in NATIVE_OWNERS
    if released_native:
        owner = producer['id']
        require(benchmark_meta is None and not recovery and not provenance, 'Unexpected released native provenance')
        prepared_path = root / 'native-preparation.json'
        prepared = read_member(prepared_path)
        closed(prepared, ('schema_version', 'revision', 'skill', 'mode', 'backend', 'producer_profile',
                          'dataset_profile', 'dataset_sha256', 'gh_manifest'))
        mode = prepared['mode']
        require(type(prepared['schema_version']) is int and prepared['schema_version'] == 1
                and prepared['skill'] == name and mode in reports.MODES
                and prepared['producer_profile'] == owner, 'Released preparation differs from the report')
        revision(prepared['revision'])
        sha('sha256:' + prepared['dataset_sha256'])
        expected = released_policy(name, owner=owner)
        require(prepared['backend'] == expected['environment'] and prepared['dataset_profile'] == expected['dataset_profile'],
                'Released preparation policy differs from the report')
        require((name == 'gh' and isinstance(prepared['gh_manifest'], str)
                 and re.fullmatch(r'manifest-[0-9a-f]{64}\.json', prepared['gh_manifest']))
                or (name == 'podman' and prepared['gh_manifest'] is None), 'Released preparation manifest differs')
        ref(prepared_path)
        provenance = {'schema_version': 1, 'skill': name, 'mode': mode, 'revision': prepared['revision'],
                      'policy_id': score_series(name, mode, owner=owner), 'patch_sha256': producer['patch_sha256'],
                      'policy': {key: expected[key] for key in POLICY_FIELDS if key in expected}}
    historical_scores = producer['revision'] == profiles.HISTORICAL_REVISION
    if benchmark_meta is not None:
        require(producer['id'] == profiles.benchmark_profile(benchmark_meta['profile'])['producer'], 'Versioned benchmark producer mismatch')
    expected_scoring = producer['scoring']
    if result.get('score_policy') is not None:
        require(result['score_policy'] == expected_scoring, 'Contradictory native scoring identity')
    arm_summaries = {}
    for arm in ('with_skill', 'without_skill'):
        summary_path = run / 'codex' / arm.replace('_', '-') / 'summary.json'
        if summary_path in scanned_entries:
            summary = read_member(summary_path)
            require(type(summary) is dict, 'Invalid native summary')
            if summary.get('score_policy') is not None:
                require(summary['score_policy'] == expected_scoring, 'Contradictory native scoring identity')
            arm_summaries[arm] = summary
    snapshot_path = run / 'dataset_snapshot.json'
    if snapshot_path in scanned_entries:
        snapshot = read_member(snapshot_path, native_snapshot=True)
        require(type(snapshot) is dict, 'Native snapshot object required')
        require(type(snapshot.get('dataset')) is list and len(snapshot['dataset']) <= MAX_CASES, 'Snapshot case limit')
        producer = profiles.runtime(versions)
        require(snapshot.get('evaluator_version') == producer['version'], 'Invalid native snapshot')
        # Match load_dataset_snapshot's pinned canonical checks on this buffer,
        # preserving its byte/node bounds without reopening the input member.
        expected = native_reports.build_dataset_snapshot(
            [entry for entry in snapshot['dataset'] if type(entry) is dict], evaluator_version=producer['version'])
        if historical_scores:
            # Schema 1.0 derived activation intent from expected_skill presence.
            entries = expected['dataset']
            positive = sum(row.get('expected_skill') is not None for row in entries)
            negative = sum('expected_skill' in row and row['expected_skill'] is None for row in entries)
            expected['schema_version'] = '1.0'
            expected['dataset_summary'].update(
                positive_tasks=positive, negative_tasks=negative,
                unclassified_tasks=len(entries) - positive - negative,
            )
        require(all(snapshot.get(key) == value for key, value in expected.items()), 'Invalid native snapshot')
        ids = sorted(case_ids([validate_case_id(e['id']) for e in snapshot['dataset']]))
        require(result.get('dataset_digest') == snapshot['dataset_digest']
                and result.get('dataset_summary') == snapshot['dataset_summary'], 'Snapshot/result mismatch')
        if result.get('dataset_digest_algorithm') is not None:
            require(result['dataset_digest_algorithm'] == snapshot['dataset_digest_algorithm'],
                    'Snapshot/result algorithm mismatch')
        if result.get('dataset_snapshot') is not None:
            embedded = {key: value for key, value in snapshot.items() if key != 'dataset'} if released_native else snapshot
            require(result['dataset_snapshot'] == embedded, 'Embedded snapshot mismatch')
        ref(snapshot_path)
    else:
        # Explicit summary case identities suffice for partial evidence, never guessed task names.
        rollups = result['agents']['codex'].get('pass_at_k')
        require(rollups is None or type(rollups) is dict, 'Invalid native pass data')
        cohort = set()
        for arm in ('with_skill', 'without_skill'):
            for carrier in ((rollups or {}).get(arm), arm_summaries.get(arm, {}).get('pass_at_k')):
                require(carrier is None or type(carrier) is dict, 'Invalid summary pass data')
                cases = (carrier or {}).get('cases')
                require(cases is None or type(cases) is dict, 'Invalid summary cases')
                cohort.update(case_ids(list(cases or {})))
                require(len(cohort) <= MAX_CASES, 'Case limit exceeded')
        ids = sorted(case_ids(list(cohort)))
        snapshot = None; limitations.add('metadata_missing')
    declared = config.get('evaluated_source', {})
    require(type(declared) is dict, 'Invalid recorded behavioral source')
    repo = declared.get('repository'); rev = declared.get('commit')
    optional(repo, repository); optional(rev, revision)
    if provenance.get('revision') is not None:
        require(provenance['revision'] == rev, 'Declared revision mismatch')
    repo = associated_repository(workspace, repo, budget=budget)
    if repo is None:
        rev = None
    upstream = provenance.get('policy', {}).get('upstream_revision')
    for key in ('upstream_revision', 'competing_revision'):
        recorded = provenance.get('policy', {}).get(key)
        require(recorded is None or name == 'gh' and recorded == reports.benchmark_policy('gh')[key],
                'Unreviewed upstream attribution')
    historical_owner = 'upstream' if upstream is not None else 'local'
    src_path = 'skills/' + name if historical_owner == 'upstream' else '.apm/skills/' + name
    src_repo = 'cli/cli' if historical_owner == 'upstream' and name == 'gh' else repo
    src_rev = upstream if historical_owner == 'upstream' else rev
    src_contents = historical_content(workspace, src_rev, src_path, budget=budget) if src_rev and historical_owner == 'local' else content()
    src = source(name, historical_owner if src_repo and src_rev else 'unknown', src_repo, src_rev, src_path, src_contents)
    if src_contents['digest'] is None:
        limitations.add('source_unavailable')
    attempt_path = run / 'attempt_policy.json'
    has_attempt = attempt_path in scanned_entries
    attempt_policy = read_member(attempt_path) if has_attempt else {}
    if has_attempt:
        ref(attempt_path)
    harbor = config.get('harbor', {})
    maximum = harbor.get('n_attempts')
    if maximum is None:
        maximum = attempt_policy.get('max_attempts')
    optional(maximum, lambda v: count(v, 100))
    require(maximum is None or maximum > 0, 'Zero attempts')
    reconcile_policy(provenance.get('policy', {}), versions, config, result['agents']['codex'], attempt_policy)
    stop_on_pass = harbor.get('stop_on_pass')
    if stop_on_pass is None:
        stop_on_pass = attempt_policy.get('stop_on_pass')
    attempts = {'mode': provenance.get('mode', 'unknown'), 'maximum': maximum,
                'stop_on_pass': stop_on_pass, 'pass_threshold': attempt_policy.get('pass_threshold')}
    judge = config.get('judge', {})
    declared_fields = provenance.get('policy', {})
    patch_digest = 'sha256:' + provenance['patch_sha256'] if provenance.get('patch_sha256') else None
    if released_native:
        require(has_attempt and attempts['pass_threshold'] == 0.5 and result['report_status'] == 'complete',
                'Released benchmark needs complete execution and its exact attempt policy')
    elif profiles.is_candidate(producer):
        # Missing policy metadata cannot erase an independently captured producer.
        # Supplied contradictions were rejected above; fill only recorded runtime facts.
        declared_fields = dict(declared_fields)
        for key in ('evaluator_revision', 'harbor', 'python'):
            if declared_fields.get(key) is None: declared_fields[key] = versions[key]
        if patch_digest is None: patch_digest = 'sha256:' + versions['patch_sha256']
    else:
        require(not profiles.candidate_revision(declared_fields.get('evaluator_revision')),
                'Incomplete candidate runtime provenance')
    policy = make_policy(declared_fields, patch_digest,
                         result.get('metric_set'), {k: judge.get(k) for k in ('model', 'provider', 'enabled')},
                         attempts, 'runtime_recorded', provenance.get('policy_id'))
    if not provenance.get('policy') or maximum is None:
        limitations.add('metadata_missing')
    data = evidence(name, 'behavioral', ids, src, policy); data['run_id'] = run.name
    data['dataset'].update({'owner': 'overlay' if historical_owner == 'upstream' else 'local',
                           'staged_digest': snapshot['dataset_digest'] if snapshot else None,
                           'staged_algorithm': snapshot['dataset_digest_algorithm'] if snapshot else None,
                           'staged_provenance': 'runtime_recorded' if snapshot else 'unknown'})
    # Authored-file identity is reconstructed only from exact objects, independently of staged entries.
    if rev:
        ds_path = '.github/evals/' + name + '/evals/evals.json' if historical_owner == 'upstream' else src_path + '/evals/evals.json'
        blob = historical_blob(workspace, rev + ':' + ds_path, budget=budget)
        if blob is not None:
            data['dataset']['authored_digest'] = digest_bytes(blob)
            data['dataset']['authored_provenance'] = 'reconstructed_from_declared_revision'
            if released_native and set(ids) != {str(row['id']) for row in parse_json(blob)['evals']}:
                limitations.add('coverage_missing')
    agent = result['agents']['codex']
    native_conditions = agent['conditions']
    require(type(native_conditions) is dict and set(native_conditions) == {'with_skill', 'without_skill'}, 'Invalid native conditions')
    for key in ('expected_attempts', 'scored_attempts'):
        values = [native_conditions[arm].get(key) for arm in ('with_skill', 'without_skill')]
        for value in values:
            optional(value, count)
        if all(value is not None for value in values):
            for carrier in (result, agent):
                if key in carrier:
                    require(type(carrier[key]) is int and carrier[key] == sum(values), 'Conflicting aggregate coverage')
    if released_native:
        released_rewards = {arm: [] for arm in native_conditions}
        data['metrics'] = reports.metric_rows(agent)
    elif benchmark_meta is not None:
        pass  # Versioned native aggregates are checked against captured rewards below.
    elif all(k in agent for k in ('lift', 'dimensions_with_skill')):
        complete_metrics = validate_native_metrics(agent, historical_scores=historical_scores)
        if not complete_metrics: limitations.add('coverage_missing')
        try:
            if complete_metrics or not _custom_admission:
                data['metrics'] = reports.metric_rows(agent)
        except OverflowError:
            raise ValueError('Invalid native numeric observation') from None
    else:
        limitations.add('coverage_missing')
    if provenance.get('metrics') is not None:
        require(provenance['metrics'] == data['metrics'], 'Provenance metrics disagreement')
    if provenance.get('dataset_digest') is not None:
        require(provenance['dataset_digest'] == data['dataset']['staged_digest'], 'Provenance dataset disagreement')
    trials_by_arm = {arm: sorted(path for path in scanned_entries if path.name == 'result.json'
                                and path.parent.parent == run / 'codex' / arm.replace('_', '-') / 'trials')
                    for arm in ('with_skill', 'without_skill')}
    orphan_rewards = {arm: {path.parent for path in scanned_entries if path.name == 'reward.json'
                            and path.parent.parent == run / 'codex' / arm.replace('_', '-') / 'trials'}
                      - {path.parent for path in trials_by_arm[arm]} for arm in trials_by_arm}
    require(sum(len(trials_by_arm[arm]) + len(orphan_rewards[arm]) for arm in trials_by_arm) <= MAX_TRIALS,
            'Trial input limit')
    known_cases = set(ids)
    models = [value for value in (policy['fields']['model'], agent.get('model'),
              config.get('provider', {}).get('model'), config.get('agents', {}).get('codex', {}).get('model'))
              if value is not None]
    for model in models:
        token(model)
    models = set(models)
    require(len(models) <= 1, 'Native model identity mismatch')
    metric_sets = set()
    for value in (policy['metric_set'], result.get('metric_set')):
        if value is not None:
            require(value == 'skill-evaluator-default-v2', 'Native metric-set identity mismatch')
            metric_sets.add(value)
    summary_attempts = 0
    benchmark_rows = []
    for arm in ('with_skill', 'without_skill'):
        arm_dir = run / 'codex' / arm.replace('_', '-')
        native_condition = agent['conditions'][arm]
        summary_path = arm_dir / 'summary.json'
        if arm in arm_summaries:
            summary = arm_summaries[arm]
            summary_ref = ref(summary_path)
        else:
            # Retain run-recorded identities/counts where available, without
            # interpreting a missing summary as a zero-trial run.
            summary = {**native_condition,
                       'num_trials': agent.get('num_trials_with' if arm == 'with_skill' else 'num_trials_without'),
                       'pass_at_k': (agent.get('pass_at_k') or {}).get(arm)}
            summary_ref = ref(result_path, ('agents', 'codex'))
            limitations.add('metadata_missing')
        if summary.get('agent') is not None:
            require(summary['agent'] == 'codex', 'Native agent identity mismatch')
        if summary.get('model') is not None:
            token(summary['model']); models.add(summary['model'])
            require(len(models) == 1, 'Native model identity mismatch')
        aggregate_pass = (agent.get('pass_at_k') or {}).get(arm)
        if aggregate_pass is not None:
            require(aggregate_pass == summary.get('pass_at_k'), 'Conflicting native pass data')
        for key in ('execution_status', 'expected_attempts', 'scored_attempts'):
            require(summary[key] == native_condition[key], 'Conflicting native coverage')
        condition_errors = native_error_count(native_condition)
        if _custom_admission or benchmark_meta is not None:
            validate_custom_error_ledger(summary, native_condition, arm)
        else:
            require(summary_error_count(summary) == condition_errors, 'Conflicting native error count')
        recorded = summary.get('num_trials'); scored = native_condition.get('scored_attempts')
        optional(recorded, count); optional(scored, count)
        native_recorded = recorded
        if benchmark_meta is not None:
            failures = summary.get('trial_failures', [])
            names = {row.get('trial') for row in failures}
            require(None not in names and len(names) == len(failures), 'Invalid benchmark failure population')
            scored_names = {a.get('trial') for c in (summary.get('pass_at_k') or {}).get('cases', {}).values() for a in c.get('attempts', [])}
            recorded = max(recorded + len(names - scored_names), len(trials_by_arm[arm]))
        if _custom_admission:
            # Native 0.3 counts scoreable rewards in num_trials. The registered
            # v2 boundary independently binds unique failed trial identities.
            failures = summary.get('trial_failures', [])
            require(recorded is not None and type(failures) is list, 'Missing custom population')
            names = [row.get('trial') for row in failures]
            require(all(type(name) is str and name for name in names) and len(names) == len(set(names)), 'Invalid custom failure population')
            recorded += len(names)
        pass_data = summary.get('pass_at_k')
        require(pass_data is None or type(pass_data) is dict, 'Invalid summary pass data')
        pass_data = pass_data or {}
        native_cases = pass_data.get('cases')
        require(native_cases is None or type(native_cases) is dict, 'Invalid summary cases')
        native_cases = native_cases or {}
        require(set(native_cases) <= set(ids), 'Unknown summary case identity')
        lookup = {}
        summary_scored = 0
        for case, case_row in native_cases.items():
            require(type(case_row) is dict, 'Invalid summary case')
            entries = case_row.get('attempts', [])
            require(type(entries) is list and len(entries) <= (maximum or MAX_TRIALS), 'Summary attempt limit')
            ordinals = set()
            for attempt in entries:
                summary_attempts += 1
                require(summary_attempts <= MAX_TRIALS, 'Summary attempt limit')
                require(type(attempt) is dict, 'Invalid summary attempt')
                trial = attempt.get('trial'); token(trial)
                ordinal = attempt.get('attempt')
                optional(ordinal, lambda v: count(v, maximum or 100))
                require(ordinal is None or ordinal >= 1 and ordinal not in ordinals, 'Invalid summary ordinal')
                if ordinal is not None:
                    ordinals.add(ordinal)
                optional(attempt.get('score'), number); optional(attempt.get('passed'), boolean)
                summary_scored += attempt.get('score') is not None
                require(recorded is None or len(lookup) < recorded, 'Summary attempts exceed recorded trials')
                require(scored is None or summary_scored <= scored, 'Summary attempts exceed scored trials')
                expected = native_condition.get('expected_attempts')
                require(expected is None or len(lookup) < expected, 'Summary attempt limit')
                require(trial not in lookup, 'Duplicate summary trial')
                lookup[trial] = (case, attempt)
        validate_summary_rollups(pass_data, native_cases, ids, maximum, stop_on_pass,
                                 versioned=benchmark_meta is not None or released_native)
        observed = []; missing_rubric_details = False
        if trials_by_arm[arm]:
            for path in trials_by_arm[arm]:
                trial_result = read_member(path)
                trial = trial_result['trial_name']; token(trial)
                require(trial == path.parent.name, 'Trial directory identity mismatch')
                native_id = trial_result['id']; token(native_id)
                reward_path = path.parent / 'reward.json'
                reward = read_member(reward_path) if reward_path in scanned_entries else None
                if reward is not None:
                    require(type(reward) is dict, 'Reward object required')
                    if reward.get('score_policy') is not None:
                        require(reward['score_policy'] == expected_scoring, 'Contradictory native scoring identity')
                    require(reward.get('agent') is None or reward['agent'] == 'codex', 'Reward identity mismatch')
                    if reward.get('model') is not None:
                        token(reward['model']); models.add(reward['model'])
                        require(len(models) == 1, 'Reward identity mismatch')
                    if reward.get('metric_set') is not None:
                        require(reward['metric_set'] == 'skill-evaluator-default-v2', 'Reward identity mismatch')
                        metric_sets.add(reward['metric_set'])
                        require(len(metric_sets) == 1, 'Reward identity mismatch')
                matched = lookup.pop(trial, None)
                from skillevaluator.tier3.harbor.collector import _entry_id_from_harbor_result, _attempt_ordinal, _canonical_case_id
                task_case = validate_case_id(_canonical_case_id(_entry_id_from_harbor_result(trial_result), known_cases))
                case = validate_case_id(reward['entry_id']) if reward is not None else matched[0] if matched else task_case
                require(task_case == case and task_case in known_cases, 'Trial task case identity mismatch')
                require(case in known_cases and (matched is None or case == matched[0]), 'Trial case identity mismatch')
                # Attempt index must be runtime recorded. A missing index never comes from directory order.
                attempt = {'attempt': None, 'score': None, 'passed': None}
                if matched:
                    attempt.update(matched[1])
                elif historical_scores:
                    attempt['attempt'] = historical_trial_ordinal(trial)
                else:
                    attempt['attempt'] = _attempt_ordinal({'_trial_name': trial})
                if attempt['attempt'] is None:
                    limitations.add('metadata_missing')
                diagnostic = None
                if producer in (profiles.NEXT, profiles.ACCOUNTING) and reward is not None and reward.get('evaluation_status') == 'failed' and 'trial_id' not in reward:
                    failure_path = path.with_name('failure.json')
                    require(failure_path in scanned_entries, 'Unscored diagnostic lacks native failure identity')
                    validate_unscored_diagnostic(reward, read_member(failure_path), trial_result, case, arm, producer, versioned=benchmark_meta is not None)
                    diagnostic = reward
                    reward = None
                if reward is not None:
                    require(reward['trial_id'] == trial and reward['has_skill'] == (arm == 'with_skill'), 'Reward trial/arm mismatch')
                verifier = (trial_result.get('verifier_result') or {}).get('rewards') or {}
                if diagnostic is not None or (benchmark_meta is not None and reward is None
                        and native_condition.get('execution_status') != 'succeeded'):
                    verifier = {}  # Native transport zero is not a task-quality measurement.
                overall = verifier.get('overall')
                if (_custom_admission or benchmark_meta is not None) and matched is None and not native_cases and native_condition.get('execution_status') == 'failed':
                    # The pinned collector suppresses pass_at_k for failed arms.
                    # Retain actual trial scores; do not invent rubric outcomes.
                    missing_rubric_details |= overall is not None
                else:
                    require(overall == attempt.get('score'), 'Native trial/summary score mismatch')
                scores = {k: verifier.get(k) for k in SCORE_FIELDS}
                if native_trial_failed(trial_result, reward):
                    require(all(value is None for value in scores.values()) and attempt.get('passed') is None,
                            'Native failure contradicts retained scores')
                    require(native_condition.get('execution_status') != 'succeeded',
                            'Native failure contradicts successful execution')
                    limitations.add('execution_incomplete')
                if reward is not None:
                    for key in SCORE_FIELDS:
                        if key in reward:
                            require(reward[key] == verifier.get(key), 'Reward score mismatch')
                    if released_native and overall is not None:
                        released_rewards[arm].append(reward)
                deterministic = (reward or {}).get('custom_metrics', {})
                if _numeric_excerpts is not None:
                    deterministic = restore_captured_numeric_fields(deterministic, _numeric_excerpts, arm, native_id, case)
                gates = deterministic_observation(deterministic, name, released_native=released_native)
                if released_native and name == 'gh' and reward is not None and overall is not None:
                    require(gates['gate'] is not None, 'Missing released gh measurements')
                locator = ()
                if 'verifier_result' in trial_result:
                    locator = ('verifier_result',)
                    if type(trial_result['verifier_result']) is dict and 'rewards' in trial_result['verifier_result']:
                        locator += ('rewards',)
                obs_refs = [ref(path, locator), summary_ref]
                if reward is not None or diagnostic is not None:
                    obs_refs.append(ref(reward_path))
                if diagnostic is not None:
                    obs_refs.append(ref(failure_path))
                    if producer in (profiles.NEXT, profiles.ACCOUNTING):
                        obs_refs.append(ref(reward_path, ('details', 'security')))
                obs = {'id': observation_id(run.name, arm, case, native_id, trial, attempt['attempt']),
                       'arm': arm, 'case_id': case, 'attempt': attempt['attempt'], 'native_id': native_id,
                       'native_trial': trial, 'native_task': trial_result['task_name'], 'score': overall,
                       'scores': scores, 'rubric_pass': attempt.get('passed'),
                       'deterministic_gate': gates['gate'], 'deterministic_scores': gates, 'references': obs_refs}
                if diagnostic is not None and producer in (profiles.NEXT, profiles.ACCOUNTING):
                    obs['security_evidence'] = copy.deepcopy(diagnostic['details']['security'])
                observed.append(obs)
                if benchmark_meta is not None:
                    if producer is profiles.ACCOUNTING:
                        import judge_accounting
                        accounting_path = path.parent / 'judge_accounting.json'
                        trial_result = copy.deepcopy(trial_result)
                        accounting = None
                        state = 'absent'
                        if accounting_path in scanned_entries:
                            try:
                                raw_accounting = read_member(accounting_path)
                                obs['references'].append(ref(accounting_path))
                                accounting = judge_accounting.validate(raw_accounting)
                                state = 'observed'
                            except ValueError:
                                state = 'invalid'
                        trial_result['_judge_accounting'] = {'status': state, 'evidence': accounting}
                    benchmark_rows.append((copy.deepcopy(obs), diagnostic or reward, trial_result))
        cardinality = agent.get('num_trials_with' if arm == 'with_skill' else 'num_trials_without')
        if cardinality is not None:
            require(type(cardinality) is int and cardinality == native_recorded, 'Conflicting aggregate trial count')
        details = 'complete' if len(observed) == recorded else 'partial' if observed else 'unavailable'
        require(details != 'complete' or not lookup, 'Unmatched summary attempts')
        if orphan_rewards[arm] or missing_rubric_details:
            details = 'partial' if observed else 'unavailable'
        if benchmark_meta is None and not released_native and not reconcile_native_arm(
            agent, arm, summary, observed, details, candidate=profiles.is_candidate(producer),
            historical_scores=historical_scores,
        ):
            limitations.add('coverage_missing')
        if details != 'complete':
            limitations.add('case_details_missing')
        if scored != native_condition.get('expected_attempts') or recorded != native_condition.get('expected_attempts'):
            limitations.add('coverage_missing')
        if native_condition.get('execution_status') != 'succeeded' or condition_errors:
            limitations.add('execution_incomplete')
        workspace_modes = {e.get('skill_workspace_mode') for e in snapshot['dataset']} if snapshot else set()
        workspace_mode = next(iter(workspace_modes)) if len(workspace_modes) == 1 else None
        competing = []
        if name == 'gh' and policy['fields']['competing_revision']:
            competing = [source('github-actions-hardening', 'upstream', 'github/awesome-copilot',
                                policy['fields']['competing_revision'], 'skills/github-actions-hardening')]
        execution = {'environment': (harbor.get('environment') or {}).get('value'),
                     'base_image_mode': harbor.get('base_image_mode'), 'task_source': config.get('task_source'),
                     'authorization_policy': policy['fields']['authorization_policy'],
                     'fixture_boundary': policy['fields']['fixture_boundary']}
        cond = condition(arm == 'with_skill', 'runtime_recorded', workspace_mode, competing,
                         instructions=native_condition.get('instruction_digest'),
                         fixture=native_condition.get('fixture_digest'),
                         build=native_condition.get('build_digest') or (identity(policy['fields']['task_build']) if policy['fields']['task_build'] else None),
                         execution=execution)
        data['arms'].append({'name': arm, 'condition': cond,
            'coverage': {'expected_cases': len(ids), 'expected_attempts': native_condition.get('expected_attempts'),
                         'recorded_attempts': recorded, 'scored_attempts': scored,
                         'unscored_attempts': recorded - scored if recorded is not None and scored is not None else None,
                         'case_details': details}, 'execution_status': native_condition.get('execution_status', 'unknown'),
            'execution_error_count': condition_errors,
            'rubric': {'passed_cases': pass_data.get('passed_cases'), 'total_cases': pass_data.get('total_cases'),
                       'threshold': pass_data.get('pass_threshold')}})
        data['observations'].extend(observed)
    if released_native:
        from benchmark_native import validate_released_aggregates

        validate_released_aggregates(agent, released_rewards, ids)
    if EvaluationService.failure_reason(result) is not None or recovery or result['report_status'] != 'complete' or result.get('diagnostic_only'):
        limitations.add('execution_incomplete')
    if not config.get('evaluated_source'):
        limitations.add('metadata_missing')
    if behavioral_identity_missing(data):
        limitations.add('metadata_missing')
    data['references'] = sorted(refs, key=lambda r: r['id'])
    if any(row['availability'] == 'expired' for row in refs):
        limitations.add('reference_expired')
    data['observations'].sort(key=lambda o: (o['arm'], o['case_id'], o['attempt'] or 0, o['id']))
    data['availability'] = {'status': 'incomplete' if limitations else 'complete',
                            'reasons': sorted(limitations), 'provenance': 'reviewed_extract' if extract else 'runtime_recorded'}
    budget.verify_repository()
    verify_directory_states(directory_states, directory_identities)
    verify_file_states(file_states, directory_identities, directory_states)
    if 'producer_profile' in policy:
        for obs in data['observations']:
            obs['raw_scores'] = copy.deepcopy(obs['scores'])
            obs['raw_deterministic_scores'] = copy.deepcopy(obs['deterministic_scores'])
            if obs['raw_deterministic_scores']['evidence'] == 0:
                obs['deterministic_scores'] = dict.fromkeys(GATE_FIELDS)
                obs['deterministic_gate'] = None
                for k in ('security', 'skill_execution', 'skill_efficiency'): obs['scores'][k] = None
        if judge.get('enabled') is False:
            for obs in data['observations']:
                for key in ('accuracy', 'goal_accuracy', 'behavior_check', 'overall'): obs['scores'][key] = None
                obs['score'] = obs['rubric_pass'] = None
            data['metrics'] = []
            for arm in data['arms']:
                arm['coverage']['scored_attempts'] = 0
                arm['coverage']['unscored_attempts'] = arm['coverage']['recorded_attempts']
                arm['rubric'].update(passed_cases=None, total_cases=None)
            data['availability']['status'] = 'incomplete'
            data['availability']['reasons'] = sorted(set(data['availability']['reasons']) | {'coverage_missing'})
    if benchmark_meta is not None:
        import benchmark_evidence
        from evaluator_090 import validate_native_aggregates
        aggregates = validate_native_aggregates(agent, benchmark_rows, ids)
        data['benchmark'] = benchmark_evidence.capture(benchmark_meta, data, benchmark_rows, result['report_status'], recovery, aggregates)
    validate_evidence(data, _observed_at=observed_at)
    guards = (input_guard(directory_identities, directory_states, file_states, budget),)
    return _CapturedRecord(data, guards) if extract else _BehavioralEvidence(data, behavioral_claim_identity(data), input_guards=guards)


def static_required_gate(scan, *, blocking_only=False):
    """Match the pinned reporter's blocking and advisory-skip semantics."""
    boolean(scan['passed'])
    enum(scan['status'], ('passed', 'failed', 'incomplete', 'skipped'))
    gating = scan.get('gating')
    require(gating is None or type(gating) is dict, 'Invalid static gating')
    if gating is not None:
        boolean(gating.get('blocking', True))
    tier3 = scan.get('tier3', {})
    provenance = tier3.get('provenance', {}) if type(tier3) is dict else {}
    advisory_skip = (scan['validator'] == 'AGENT_EVAL'
                     and not (gating is not None and gating.get('blocking', False))
                     and type(provenance) is dict and provenance.get('advisory') is True
                     and provenance.get('reason') == 'skipped')
    expected = ('skipped' if advisory_skip else 'incomplete' if scan.get('incomplete_scans')
                else 'passed' if scan['passed'] else 'failed')
    require(scan['status'] == expected, 'Static validator status contradiction')
    blocking = gating.get('blocking', True) if gating is not None else not advisory_skip
    return blocking if blocking_only else scan['passed'] or not blocking


def static_scanner(value):
    """Map exact pinned reporter titles into the existing schema-v1 token domain."""
    titles = {
        'Schema & Repository Governance': 'SCHEMA',
        'Semantic Version Validation': 'VERSION',
        'Security Scan': 'SECURITY',
        'PII Scan': 'PII',
        'License Compliance': 'LICENSE',
        'Code Risk Analysis': 'CODE_RISK',
        'Secrets Detection': 'SECRETS',
        'Code Integrity & Hygiene': 'HYGIENE',
        'Unicode Smuggling Detection': 'UNICODE',
        'Harness Compatibility': 'HARNESS',
    }
    require(type(value) is str, 'Invalid scanner identity')
    value = titles.get(value, value)
    token(value)
    return value


def static_check(scanner, value):
    """Retain the rule ID from the pinned SECURITY pattern-label formatter."""
    if value is None:
        return None
    require(type(value) is str, 'Invalid static check identity')
    if scanner == 'SECURITY':
        match = re.fullmatch(r'[\x21-\x7e][\x20-\x7e]* \(([A-Za-z0-9][A-Za-z0-9._+~:-]{0,127})\)', value)
        if match:
            value = match[1]
    token(value)
    return value


def normalize_static(root, name, workspace=ROOT):
    directory_identities = {}
    directory_states = {}
    file_states = {}
    root = safe_path(root, directory=True, directory_identities=directory_identities)
    scanned_entries = set(safe_tree(root, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)); skill_id(name)
    budget = ReadBudget()
    catalog_path = root / 'reports/catalog-summary.json'
    require(catalog_path in scanned_entries, 'Unscanned static member')
    catalog, catalog_digest = read_json_and_digest(catalog_path, budget=budget, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)
    require(type(catalog) is dict, 'Static catalog object required')
    require(type(catalog['skills']) is list and catalog['total'] == len(catalog['skills']), 'Catalog cardinality mismatch')
    names = [row['name'] for row in catalog['skills']]
    require(type(catalog['failed']) is int and catalog['failed'] == sum(row['passed'] is False for row in catalog['skills']), 'Catalog failure count mismatch')
    require(len(names) == len(set(names)), 'Ambiguous static skill identity')
    rows = [row for row in catalog['skills'] if row['name'] == name]
    require(len(rows) == 1, 'Missing static skill report')
    row = rows[0]; boolean(row['passed'])
    require(row.get('reason', '') == ('' if row['passed'] else 'validation failed'), 'Catalog infrastructure failure')
    filename = row['json_report']
    require(type(filename) is str and bool(re.fullmatch(r'skillevaluator-output-[0-9]{14}\.json', filename)), 'Unsafe static report member')
    report_path = root / 'reports' / name / filename
    require(report_path in scanned_entries, 'Unscanned static member')
    native, report_digest = read_json_and_digest(report_path, budget=budget, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)
    require(type(native) is dict and type(native.get('results')) is list
            and len(native['results']) <= 100, 'Invalid bounded static report')
    require(len(native['skills']) == 1 and native['skills'][0]['name'] == name, 'Static identity mismatch')
    require(native['overall_passed'] == row['passed'] and type(native['overall_passed']) is bool, 'Static pass mismatch')
    enum(native['overall_status'], ('passed', 'failed', 'incomplete'))
    require(type(native['incomplete_scans']) is list and len(native['incomplete_scans']) <= 100, 'Scanner limit')
    for scanner in native['incomplete_scans']:
        token(scanner)
    released = native.get('version') in reports.RELEASED_STATIC_VERSIONS
    if released:
        require(root / 'versions.json' in scanned_entries, 'Missing static producer provenance')
        producer = read_json_and_digest(root / 'versions.json', budget=budget, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)[0]
        require(validate_runtime_versions(producer).get('version') == native['version'], 'Static producer version mismatch')
        from skillevaluator.reporting.base import passes_required_gate
        released_gates = [passes_required_gate(result) for result in reports.released_static_results(native)]
    else:
        expected = 'incomplete' if native['incomplete_scans'] else 'passed' if row['passed'] else 'failed'
        require(native['overall_status'] == expected, 'Static status contradiction')
    require(native['total_validators'] == len(native['results']) > 0, 'Static status contradiction')
    severity = native['severity_counts']; closed(severity, ('critical', 'high', 'medium', 'low'))
    for val in severity.values():
        count(val)
    finding_count = 0
    for scan in native['results']:
        require(type(scan) is dict and type(scan.get('findings', [])) is list, 'Invalid static findings')
        finding_count += len(scan.get('findings', []))
        require(finding_count <= MAX_TRIALS, 'Finding limit')
        extra_scanners = scan.get('incomplete_scans', [])
        require(type(extra_scanners) is list and len(extra_scanners) <= 100, 'Scanner limit')
        for scanner in extra_scanners:
            token(scanner)
        require(set(extra_scanners) <= set(native['incomplete_scans']), 'Inconsistent incomplete scanner identity')
    # The released rehydrator validates status precedence, gate failures and
    # finding severity together. It is used only for its exact owning producer.
    if released:
        blocking = [scan.get('gating', {}).get('blocking', True) for scan in native['results']]
        gates = released_gates
    else:
        blocking = [static_required_gate(scan, blocking_only=True) for scan in native['results']]
        gates = [scan['passed'] or not required for scan, required in zip(native['results'], blocking)]
    require(native['overall_passed'] == all(gates),
            'Static required gate contradiction')
    detailed = dict.fromkeys(severity, 0)
    for scan in native['results']:
        scan_counts = dict.fromkeys(severity, 0)
        summary = scan.get('summary', {})
        require(type(summary) is dict, 'Invalid scanner summary')
        for finding in scan.get('findings', []):
            require(type(finding) is dict, 'Invalid static finding')
            enum(finding['severity'], (*severity, 'info'))
            if finding['severity'] in severity:
                scan_counts[finding['severity']] += 1
                detailed[finding['severity']] += 1
        for level, total in scan_counts.items():
            reported = summary.get(level + '_count')
            optional(reported, count)
            require(reported is None or total <= reported, 'Detailed findings exceed scanner total')
    for level, total in detailed.items():
        require(total <= severity[level], 'Detailed findings exceed aggregate total')
    for level, total in severity.items():
        counts = [scan.get('summary', {}).get(level + '_count') for scan in native['results']]
        if all(value is not None for value in counts):
            require(sum(counts) == total, 'Contradictory static finding counts')
    data = evidence(name, 'static')
    declared = native.get('evaluated_source')
    if declared is not None:
        require(type(declared) is dict, 'Invalid recorded static source')
        repo = declared.get('repository'); rev = declared.get('commit')
        optional(repo, repository); optional(rev, revision)
        repo = associated_repository(workspace, repo, budget=budget)
        if repo is None:
            rev = None
        path = '.apm/skills/' + name
        data['source'] = source(name, 'local' if repo and rev else 'unknown', repo, rev, path,
                                historical_content(workspace, rev, path, budget=budget) if rev else content())
    def report_reference(locator=()):
        return reference_from_digest(root, report_path, 'skill-quality', report_digest, locator)
    refs = [reference_from_digest(root, catalog_path, 'skill-quality', catalog_digest), report_reference()]
    # Aggregate native counts remain their own observation; scanner counts are
    # not invented when the pinned report does not supply them.
    data['scans'] = [{'scanner': 'catalog-total', 'status': native['overall_status'], 'passed': native['overall_passed'],
                      'blocking': True, 'severity_counts': severity, 'references': [refs[1]['id']]}]
    for index, scan in enumerate(native['results']):
        scanner = static_scanner(scan['validator'])
        enum(scan['status'], ('passed', 'failed', 'incomplete', 'skipped'))
        scan_ref = report_reference(('results', index)); refs.append(scan_ref)
        data['scans'].append({'scanner': scanner, 'status': scan['status'], 'passed': scan.get('passed'), 'blocking': blocking[index],
            'severity_counts': {k: scan.get('summary', {}).get(k + '_count')
                                for k in ('critical', 'high', 'medium', 'low')}, 'references': [scan_ref['id']]})
    recorded_incomplete = set()
    for index, scan in enumerate(native['results']):
        for scanner in scan.get('incomplete_scans', []):
            token(scanner); recorded_incomplete.add(scanner)
            if scanner not in {s['scanner'] for s in data['scans']}:
                data['scans'].append({'scanner': scanner, 'status': 'incomplete', 'passed': None,
                    'blocking': False, 'severity_counts': {k: None for k in ('critical', 'high', 'medium', 'low')}, 'references': [refs[1]['id']]})
        for finding_index, finding in enumerate(scan.get('findings', [])):
            finding_ref = report_reference(('results', index, 'findings', finding_index))
            refs.append(finding_ref)
            member = finding.get('file_path')
            try:
                relative(member)
            except ValueError:
                member = None  # Never publish an artifact-supplied absolute path.
            scanner = static_scanner(scan['validator'])
            check = static_check(scanner, finding.get('check_name') or None)
            data['findings'].append({'scanner': scanner, 'severity': finding['severity'],
                'check': check, 'member': member, 'line': finding.get('line_number'), 'reference': finding_ref['id']})
    require(set(native['incomplete_scans']) == recorded_incomplete, 'Inconsistent incomplete scanner identity')
    incomplete = any(s['status'] in ('incomplete', 'skipped') for s in data['scans'])
    data['references'] = refs
    limitations = {'scan_incomplete'} if incomplete else set()
    if data['source']['content']['digest'] is None:
        limitations.add('source_unavailable')
    data['availability'] = {'status': 'incomplete' if limitations else 'complete',
                            'reasons': sorted(limitations), 'provenance': 'runtime_recorded'}
    if root / 'versions.json' in scanned_entries:
        versions, versions_digest = read_json_and_digest(root / 'versions.json', budget=budget, directory_identities=directory_identities, directory_states=directory_states, file_states=file_states)
        producer = validate_runtime_versions(versions, historical_read=not released)
        require(native.get('version', producer['version']) == producer['version'], 'Static producer version mismatch')
        if 'scanner_runtime' in versions: data['scanner_runtime'] = copy.deepcopy(versions['scanner_runtime'])
        has_caveats = any(error.startswith('skillspector complete_with_caveats:')
                          for scan in native['results'] for error in scan.get('legacy', {}).get('errors', []))
        require(not has_caveats or versions.get('scanner_runtime') in CAVEAT_SCANNER_RUNTIMES,
                'Missing qualified caveat adapter provenance')
        if versions.get('scanner_runtime') in CAVEAT_SCANNER_RUNTIMES:
            for index, scan in enumerate(native['results']):
                for error in scan.get('legacy', {}).get('errors', []):
                    match = re.fullmatch(
                        r'skillspector complete_with_caveats: ([1-9][0-9]*) reference_missing caveat\(s\); '
                        r'producer is_complete=true; repository coverage remains incomplete', error)
                    if versions.get('scanner_runtime') in RELEASED_SCANNER_RUNTIMES:
                        # The released adapter names up to three missing-reference
                        # rows, followed by the exact remaining count. Retain that
                        # producer claim without promoting incomplete coverage.
                        if (error.startswith("skillspector JSON field 'analysis_completeness' reports caveats that SkillEvaluator does not accept (status 'complete_with_caveats'): ")
                                and error.endswith('Missing references require a standalone target with complete, matching reference and scan evidence. See https://docs.nvidia.com/skills/skillevaluator/tier1-validation.')):
                            shown = error.count('[reference_resolution; reference_missing]')
                            remaining = re.search(r'; and ([1-9][0-9]*) more; security scan did not complete', error)
                            require(1 <= shown <= 3, 'Invalid released caveat diagnostic')
                            caveats = shown + (int(remaining[1]) if remaining else 0)
                            require('skillspector' in scan['incomplete_scans'], 'Caveat coverage missing')
                            data.setdefault('coverage_caveats', []).append({
                                'scanner': 'skillspector', 'producer_status': 'complete_with_caveats',
                                'reason': 'reference_missing', 'count': caveats,
                                'reference': report_reference(('results', index))['id']})
                    if match:
                        require(scan['validator'] == 'Security Scan' and scan['status'] == 'incomplete',
                                'Contradictory caveat coverage')
                        data.setdefault('coverage_caveats', []).append({
                            'scanner': 'skillspector', 'producer_status': 'complete_with_caveats',
                            'reason': 'reference_missing', 'count': int(match[1]),
                            'reference': report_reference(('results', index))['id']})

        if released:
            data['policy'] = make_policy(
                {key: versions[key] for key in ('evaluator_revision', 'harbor', 'python')},
                patch='sha256:' + producer['patch_sha256'] if 'patch_sha256' in producer else None,
                judge={'model': None, 'provider': None, 'enabled': False}, provenance='runtime_recorded',
                published=producer.get('producer_profile'))
        else:
            data['policy'] = make_policy({'evaluator_revision': versions.get('evaluator_revision')}, provenance='runtime_recorded')
        data['references'].append(reference_from_digest(root, root / 'versions.json', 'skill-quality', versions_digest))
        if versions.get('fixture') == 'synthetic':
            data['availability']['provenance'] = 'synthetic'
            for record in data['references']:
                record['provenance'] = 'synthetic'
    budget.verify_repository()
    verify_directory_states(directory_states, directory_identities)
    verify_file_states(file_states, directory_identities, directory_states)
    validate_evidence(data)
    blocking_defaults = tuple((scan['scanner'], scan['blocking']) for scan in data['scans'])
    return _StaticEvidence(data, static_claim_identity(data, blocking_defaults), blocking_defaults,
                           (input_guard(directory_identities, directory_states, file_states, budget),))


def open_directory(path, identities=None, changed_message='Input directory changed', trusted_output=False, *, directory_states=None):
    """Anchor each directory component without following replacement links."""
    boundary = "output" if trusted_output else "integrity"
    require = boundary_check(boundary)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = boundary_call(boundary, os.open, path.anchor, flags)
    def validate_owner():
        if trusted_output:
            info = os.fstat(fd)
            require(info.st_uid in (0, os.geteuid())
                    and (not info.st_mode & 0o022 or info.st_mode & stat.S_ISVTX), 'Untrusted output parent')
    try:
        validate_owner()
        current = Path(path.anchor)
        if directory_states is not None and current in directory_states:
            require(directory_state(os.fstat(fd)) == directory_states[current], 'Input directory entries changed')
        for part in path.parts[1:]:
            current /= part
            child = boundary_call(boundary, os.open, part, flags, dir_fd=fd)
            os.close(fd); fd = child
            if identities is not None:
                info = os.fstat(fd)
                require(identities.get(current) == (info.st_dev, info.st_ino), changed_message)
            if directory_states is not None and current in directory_states:
                require(directory_state(os.fstat(fd)) == directory_states[current], 'Input directory entries changed')
            validate_owner()
        return fd
    except BaseException:
        os.close(fd)
        raise


def write_outputs(values, destination=None, workspace=ROOT, input_path=None, *,
                  rendered=None, input_paths=(), input_guards=()):
    require = boundary_check("output")
    # Finish validation/serialization before reserving an output directory.
    require(SECURE_DIRECTORY_OUTPUT, 'Secure directory output unsupported')
    rendered = {} if rendered is None else rendered
    require(type(rendered) is dict and all(type(value) is bytes for value in rendered.values()),
            'Invalid rendered output')
    require(not set(values) & set(rendered), 'Duplicate output member')
    for name in (*values, *rendered):
        relative(name); require('/' not in name, 'Nested output member')
    payloads = {name: encoded(value) for name, value in values.items()}
    payloads.update(rendered)
    guards = tuple(dict.fromkeys((*input_guards,
        *(guard for value in values.values() for guard in record_guards(value)))))
    for guard in guards: guard()
    workspace = Path(workspace).absolute()
    boundaries = tuple(dict.fromkeys(Path(path).absolute() for path in
        (*input_paths, *((input_path,) if input_path is not None else ()))))
    parent_identities = {}
    if destination is None:
        # Validate explicit settings without tempfile's probing/fallback writes.
        parent = next((os.environ[key] for key in ('TMPDIR', 'TEMP', 'TMP') if os.environ.get(key)), None)
        parent = safe_path(parent if parent is not None else tempfile.gettempdir(), directory=True,
                           directory_identities=parent_identities, boundary="output")
        require(not parent.is_relative_to(workspace), 'Output must be outside checkout')
        for boundary in boundaries:
            require(not parent.is_relative_to(boundary), 'Output overlaps input')
    else:
        destination = Path(destination).absolute()
        parent = safe_path(destination.parent, directory=True, directory_identities=parent_identities, boundary="output")
        require(not os.path.lexists(destination), 'Output directory must be new')
    if destination is not None:
        safe_path(destination, directory=True, missing=True, boundary="output")
        require(not destination.is_relative_to(workspace) and destination != workspace, 'Output must be outside checkout')
        for boundary in boundaries:
            require(not destination.is_relative_to(boundary) and not boundary.is_relative_to(destination),
                    'Output overlaps input')
    forbidden_directories = set()
    for boundary in (workspace, *boundaries):
        if boundary is not None and boundary.exists():
            info = boundary_call("integrity", boundary.lstat)
            if stat.S_ISDIR(info.st_mode): forbidden_directories.add((info.st_dev, info.st_ino))
    parent_fd = open_directory(parent, parent_identities, 'Output parent directory changed', True)
    try:
        if destination is None:
            for _ in range(100):
                destination = parent / ('skill-evidence-' + secrets.token_hex(8))
                try:
                    boundary_call("output", os.mkdir, destination.name, mode=0o700, dir_fd=parent_fd,
                                  allow_collision=True)
                    break
                except FileExistsError:
                    destination = None
            require(destination is not None, 'Temporary output collision limit')
        else:
            boundary_call("output", os.mkdir, destination.name, mode=0o700, dir_fd=parent_fd)
        created = None
        reservation_parent = None
        reserved = False
        directory_fd = None
        owned = False
        members = []
        def private_reservation(info):
            return (stat.S_ISDIR(info.st_mode) and (info.st_dev, info.st_ino) not in forbidden_directories
                    and info.st_uid == os.geteuid() and not info.st_mode & 0o077)
        try:
            try:
                reservation_parent = directory_state(os.fstat(parent_fd))
            except OSError:
                # Recover identity for cleanup after one transient metadata-read
                # failure. Never retry creation or proceed with publication.
                try: reservation_parent = directory_state(os.fstat(parent_fd))
                except OSError: pass
                raise
            created = boundary_call("output", os.stat, destination.name, dir_fd=parent_fd, follow_symlinks=False)
            reserved = private_reservation(created)
            require(reserved, 'Output directory changed')
            directory_fd = boundary_call("output", os.open, destination.name,
                                         os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent_fd)
            original = os.fstat(directory_fd)
            require((original.st_dev, original.st_ino) == (created.st_dev, created.st_ino)
                    and (original.st_dev, original.st_ino) not in forbidden_directories
                    and original.st_uid == os.geteuid()
                    and not original.st_mode & 0o077 and not os.listdir(directory_fd), 'Output directory changed')
            owned = True
            def unchanged():
                current = boundary_call("output", destination.lstat)
                require(stat.S_ISDIR(current.st_mode) and (current.st_dev, current.st_ino) ==
                        (original.st_dev, original.st_ino), 'Output directory changed')
            unchanged()
            for name, payload in payloads.items():
                fd = boundary_call("output", os.open, name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                             mode=0o600, dir_fd=directory_fd)
                members.append(name)
                try:
                    stream = os.fdopen(fd, 'wb')
                except BaseException:
                    os.close(fd)
                    raise
                with stream:
                    stream.write(payload)
                unchanged()
            for guard in guards: guard()
            unchanged()
        except BaseException:
            if created is None and reservation_parent is not None:
                # One recovery lookup for a transient initial stat failure. A
                # changed parent entry set cannot establish reservation identity.
                try:
                    if directory_state(os.fstat(parent_fd)) == reservation_parent:
                        recovered = os.stat(destination.name, dir_fd=parent_fd, follow_symlinks=False)
                        if directory_state(os.fstat(parent_fd)) == reservation_parent and private_reservation(recovered):
                            created = recovered; reserved = True
                except OSError:
                    pass
            if owned:
                # Remove only members created here, through the retained descriptor.
                for name in members:
                    try:
                        os.unlink(name, dir_fd=directory_fd)
                    except FileNotFoundError:
                        pass
            if reserved:
                # Descriptor acquisition/validation can fail before owned is set.
                # The anchored parent still identifies the empty reservation.
                try:
                    current = os.stat(destination.name, dir_fd=parent_fd, follow_symlinks=False)
                    if stat.S_ISDIR(current.st_mode) and (current.st_dev, current.st_ino) == (created.st_dev, created.st_ino):
                        os.rmdir(destination.name, dir_fd=parent_fd)
                except OSError:
                    pass  # Preserve the rejection if removed, replaced or no longer empty.
            raise
        finally:
            if directory_fd is not None: os.close(directory_fd)
    finally:
        os.close(parent_fd)
    return destination



def resolve_locator(value, locator):
    """Resolve captured JSON without rereading or executing supplied content."""
    require = boundary_check("locator")
    require(type(locator) is list and len(locator) <= 12, 'Locator limit')
    for component in locator:
        if type(component) is int:
            require(type(value) is list and 0 <= component < len(value), 'Invalid structured locator')
        else:
            require(type(component) is str and type(value) is dict and component in value,
                    'Invalid structured locator')
        value = value[component]
    return value


def verify_reference(bundle, record, *, reader=None):
    """Verify retained original bytes and resolve a structured locator, without execution."""
    validate_reference(record)
    require(record['availability'] == 'available', 'Reference unavailable or expired')
    require(not reference_expired(record, utc_now()), 'Reference unavailable or expired')
    safe_path(bundle, directory=True)
    path = bundle / record['member']
    raw = (read_bytes if reader is None else reader)(path)
    require(digest_bytes(raw) == record['digest'], 'Evidence member digest mismatch')
    return resolve_locator(parse_json(raw), record['locator'])


def verify_source_snapshot(snapshot, src):
    """Compare retained skill bytes with the declared agent-visible manifest."""
    validate_source(src)
    require(src['content']['digest'] is not None, 'Exact source unavailable')
    require(skill_content(snapshot)['digest'] == src['content']['digest'], 'Exact source mismatch')


def validate_public(data):
    return validate_evidence(data, public=True)


# Custom metrics are data contracts, not executable grader plugins. Native
# consistency is established here; public consumers validate reported claims.
CUSTOM_CAPTURE = 'custom-metric-capture.json'
CUSTOM_REGISTRY = '.github/evals/custom-metrics.json'
SOURCE_SUCCESSORS = '.github/evals/source-v37.json'
MODEL_SUCCESSORS = '.github/evals/source-v38.json'
SCORED_SUCCESSORS = '.github/evals/source-v39.json'
PODMAN_SOURCE_SUCCESSORS = '.github/evals/source-v40.json'
PROBE_SOURCE_SUCCESSORS = '.github/evals/source-v41.json'
MOUNT_SOURCE_SUCCESSORS = '.github/evals/source-v42.json'
CAMPAIGN_SOURCE_SUCCESSORS = '.github/evals/source-v43.json'
RETIREMENT_SOURCE_SUCCESSORS = '.github/evals/source-v44.json'
PUBLICATION_SOURCE_SUCCESSORS = '.github/evals/source-v45.json'
DIAGNOSTIC_SOURCE_SUCCESSORS = '.github/evals/source-v46.json'
DIRECT_TOOL_SOURCE_SUCCESSORS = '.github/evals/source-v47.json'
NATIVE_RETIREMENT_SOURCE_SUCCESSORS = '.github/evals/source-v48.json'
RELEASE_121_SOURCE_SUCCESSORS = '.github/evals/source-v49.json'
CUSTOM_OUTCOMES = ('passed', 'failed', 'invalid', 'unsupported', 'timeout',
                   'infrastructure_error', 'interrupted', 'unknown')
CUSTOM_MEASURED = ('passed', 'failed')
CUSTOM_NATIVE_EXCEPTIONS = {
    'VerifierTimeoutError': 'timeout', 'AgentTimeoutError': 'timeout',
    'AgentSetupTimeoutError': 'timeout', 'EnvironmentBuildTimeoutError': 'timeout',
    'CancelledError': 'interrupted', 'KeyboardInterrupt': 'interrupted',
}
CUSTOM_ASSURANCE = {'native_consistency': 'producer_reported_at_admission',
                    'producer_authentication': 'not_established',
                    'execution_authentication': 'not_established'}


def validate_unscored_diagnostic(reward, failure, trial, case_id, arm, producer=None, *, collector_agent=None, versioned=False):
    """Bind a collector diagnostic to native failure evidence without grading it.

    The pinned collector omits trial_id only on its failed-judge projection.
    That projection is diagnostic data, not a reward with a missing identity.
    Never infer or insert a trial_id, and reject all measurement-bearing forms.
    """
    allowed = {'metric_set', 'evaluation_status', 'entry_id', 'evaluation_errors',
               'agent', 'variant', 'model', 'model_source'}
    current = producer in (profiles.NEXT, profiles.ACCOUNTING)
    if current:
        allowed |= {'diagnostic_version', 'diagnostic_trial', 'details'}
        require(reward.get('diagnostic_version') == unscored_security.VERSION
                and reward.get('diagnostic_trial') == trial['trial_name'], 'Unscored diagnostic contract mismatch')
        closed(reward.get('details'), ('security',))
        unscored_security.validate_security(reward['details']['security'])
        reports.public_strings(reward['details']['security'])
    exception = trial.get('exception_info') or {}
    require(set(reward) <= allowed and reward.get('evaluation_status') == 'failed'
            and reward.get('metric_set') == 'skill-evaluator-default-v2'
            and reward.get('entry_id') == case_id
            and reward.get('agent') == (collector_agent if current and collector_agent is not None else
                                         (trial.get('agent_info') or {}).get('name'))
            and reward.get('variant') == arm, 'Invalid unscored diagnostic')
    require(failure.get('status') == 'unscored'
            and failure.get('trial') == failure.get('trial_name') == trial['trial_name']
            and failure.get('task_name') == trial['task_name']
            and all(failure.get(k) == reward.get(k) for k in
                    ('agent', 'variant', 'model', 'model_source', 'evaluation_status', 'evaluation_errors')),
            'Unscored diagnostic failure identity mismatch')
    agent = trial.get('agent_info') or {}
    native_model = (agent.get('model_info') or {}).get('name') or agent.get('model_name')
    require(reward.get('model') is None or reward['model'] == native_model,
            'Unscored diagnostic model mismatch')
    error = failure.get('error') or {}
    require(exception and error.get('type') == exception.get('exception_type')
            and error.get('message') == exception.get('exception_message')
            and error.get('occurred_at') == exception.get('occurred_at'),
            'Unscored diagnostic native failure mismatch')
    raw = ((trial.get('verifier_result') or {}).get('rewards') or {})
    if versioned:
        require(current, 'Versioned diagnostic requires offline-v3')
        from evaluator_090 import diagnostic_observations
        diagnostic_observations(reward, trial)  # Explicit judge failure can retain deterministic observations.
    else:
        require(raw == {} or raw == {'overall': 0.0}, 'Unscored diagnostic acquired measurements')


def validate_custom_error_ledger(summary, condition, arm):
    """Require an exact raw or pinned-loader ledger, never just equal counts."""
    enum(arm, ('with_skill', 'without_skill'))
    native_error_count(summary); native_error_count(condition)
    raw = summary.get('execution_errors', [])
    augmented = list(raw)
    label = 'With skill' if arm == 'with_skill' else 'Without skill'
    job = summary.get('job_failure')
    require(job is None or type(job) is str, 'Invalid native job failure')
    if job: augmented.append(f'{label} aggregate job: {job}')
    failures = summary.get('trial_failures', [])
    require(type(failures) is list and len(failures) <= MAX_TRIALS, 'Invalid native failure ledger')
    for failure in failures:
        require(type(failure) is dict and type(failure.get('reason')) is str, 'Invalid native failure ledger')
        token(failure.get('trial'))
        augmented.append(f"{label} trial {failure['trial']}: {failure['reason']}")
    require(condition.get('execution_errors', []) in (raw, augmented), 'Custom execution error ledger contradiction')


def frozen_registry(workspace=ROOT):
    registry = parse_json(read_bytes(workspace / CUSTOM_REGISTRY))
    closed(registry, ('schema_version', 'metrics', 'profiles', 'active_profiles'))
    require(type(registry['schema_version']) is int and registry['schema_version'] == 1, 'Custom registry version')
    validate_custom_metrics(registry['metrics'])
    return registry


def validate_custom_metrics(metrics):
    require(type(metrics) is dict and 0 < len(metrics) <= 32, 'Metric definition limit')
    for native, definition in metrics.items():
        token(native)
        closed(definition, ('native_name', 'id', 'title', 'definition', 'competency', 'unit', 'basis', 'aggregation', 'role'))
        require(definition['id'] == native, 'Metric identity mismatch')
        token(definition['native_name'])
        token(definition['id']); token(definition['competency'])
        for key in ('title', 'definition'):
            require(type(definition[key]) is str and 0 < len(definition[key]) <= 500
                    and not any(ord(c) < 32 for c in definition[key]), 'Invalid metric description')
        enum(definition['basis'], ('binary', 'ratio'))
        require(definition['unit'] == ('fraction' if definition['basis'] == 'ratio' else 'binary_score')
                and definition['aggregation'] == 'mean_of_applicable_trial_values', 'Unsupported scoring definition')
        enum(definition['role'], ('diagnostic', 'mandatory_with_skill_gate'))


def custom_registry(workspace=ROOT):
    """Apply reviewed source-only successors to the immutable grading records."""
    registry = frozen_registry(workspace)
    version = parse_json(read_bytes(workspace / SOURCE_SUCCESSORS))
    closed(version, ('replay_adapter', 'runtime_digests'))
    sha(version['replay_adapter'])
    profiles = registry['profiles']
    parents = {'pester-effectiveness-v40': 'pester-effectiveness-v39',
               'pester-cli-pilot-retained-v21': 'pester-cli-pilot-retained-v20',
               'gh-deterministic-gate-v7': 'gh-deterministic-gate-v6',
               'gh-native-oracle-v3': 'gh-native-oracle-v2'}
    for successor, runtime in version['runtime_digests'].items():
        parent = parents.get(successor, successor.replace('-source-v37-', '-source-v36-'))
        require(parent in profiles and successor not in profiles, 'Invalid source successor')
        sha(runtime)
        result = dict(profiles[parent], id=successor, runtime_digest=runtime)
        if 'adapter_sha256' in result.get('campaign', {}):
            result['campaign'] = dict(result['campaign'], adapter_sha256=version['replay_adapter'])
        profiles[successor] = result
    for version_path in (MODEL_SUCCESSORS, SCORED_SUCCESSORS, PODMAN_SOURCE_SUCCESSORS, PROBE_SOURCE_SUCCESSORS, MOUNT_SOURCE_SUCCESSORS, CAMPAIGN_SOURCE_SUCCESSORS, RETIREMENT_SOURCE_SUCCESSORS, PUBLICATION_SOURCE_SUCCESSORS, DIAGNOSTIC_SOURCE_SUCCESSORS, DIRECT_TOOL_SOURCE_SUCCESSORS, NATIVE_RETIREMENT_SOURCE_SUCCESSORS, RELEASE_121_SOURCE_SUCCESSORS):
        version = parse_json(read_bytes(workspace / version_path))
        sha(version['replay_adapter'])
        for successor, update in version['profiles'].items():
            parent = profiles[update['parent']]
            sha(update['runtime_digest'])
            result = dict(parent, id=successor, runtime_digest=update['runtime_digest'])
            if 'grader_digest' in update:
                require(version_path in (MOUNT_SOURCE_SUCCESSORS, CAMPAIGN_SOURCE_SUCCESSORS)
                        and parent['skill_id'] == 'podman',
                        'Unregistered grader successor')
                sha(update['grader_digest'])
                result['grader_digest'] = update['grader_digest']
            if 'adapter_sha256' in result.get('campaign', {}):
                result['campaign'] = dict(result['campaign'], adapter_sha256=version['replay_adapter'])
            if 'definition' in update:
                member = update['definition']
                result['campaign'] = dict(result['campaign'], definition=member)
                result['runtime'] = dict(parent['runtime'], model='gpt-6.2-sol', profile=update['runtime_profile'])
                if 'cli' in update:
                    result['runtime'].update(cli=update['cli'], codex=update['cli'])
            elif successor in ('pester-cli-pilot-retained-v22', 'pester-effectiveness-v41'):
                result['runtime'] = dict(parent['runtime'], model='gpt-6.2-sol',
                                         workspace_profile=parent['runtime']['workspace_profile'] + '-sol62')
            require(successor not in profiles, 'Duplicate runtime successor')
            profiles[successor] = result
        if version_path == PODMAN_SOURCE_SUCCESSORS:
            require(not (registry['metrics'].keys() & version['new_metrics'].keys())
                    and not (profiles.keys() & version['new_profiles'].keys()),
                    'Duplicate campaign metric or profile')
            registry['metrics'].update(version['new_metrics'])
            validate_custom_metrics(registry['metrics'])
            profiles.update(version['new_profiles'])
    registry['active_profiles']['gh'] = 'gh-deterministic-gate-v10'
    return registry


def campaign_purpose(value):
    return type(value) is str and value.startswith('campaign-')



def replay_purpose(value):
    return value == 'cli_pilot_replay' or (campaign_purpose(value) and value.endswith('-replay'))


def validate_replay_metadata(value, profile, purpose, workspace=ROOT):
    if purpose == 'cli_pilot_replay':
        from codex_pilot_replay import validate_retrospective
        validate_retrospective(value)
    else:
        from codex_pilot_replay import validate_campaign_retrospective
        validate_campaign_retrospective(value,profile,workspace)


def profile_family(profile):
    return profile.get('semantics', profile['id'])


def validate_custom_purpose(value):
    if campaign_purpose(value):
        profile = custom_registry()['profiles'].get(value, {})
        require('campaign' in profile, 'Unknown campaign purpose')
    else:
        enum(value, ('benchmark', 'oracle_qualification', 'cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'))


def oracle_purpose(value):
    return value in ('oracle_qualification', 'cli_pilot_control', 'cli_pilot_replay', 'skill_effectiveness_control') or (campaign_purpose(value) and value.endswith(('-oracle','-replay')))


def custom_agent(profile, purpose):
    return 'oracle' if oracle_purpose(purpose) else profile['runtime'].get('agent', 'codex')


def custom_carrier(profile):
    return profile['runtime'].get('agent', 'codex') if 'campaign' in profile else 'codex'


def custom_defect_files(profile, workspace, case):
    if 'campaign' in profile:
        from evaluation_evidence import task
        return task(profile).files()
    from codex_pilot_effectiveness import case_files
    return case_files(workspace, case)


def custom_contract(name, workspace=ROOT, *, profile_id=None, purpose=None):
    registry = custom_registry(workspace)
    if profile_id is None and campaign_purpose(purpose):
        profile_id = purpose
    if profile_id is None and purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
        profile_id = 'pester-effectiveness-v52'
    if profile_id is None and name == 'powershell-pester-6' and purpose in ('cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
        profile_id = 'pester-cli-pilot-retained-v24'
    if profile_id is None and name == 'gh' and purpose == 'oracle_qualification':
        profile_id = 'gh-native-oracle-v6'
    profile_id = registry['active_profiles'].get(name) if profile_id is None else profile_id
    require(profile_id in registry['profiles'], 'Unknown custom metric namespace or profile')
    registered = registry['profiles'][profile_id]
    require(registered['id'] == profile_id and registered['skill_id'] == name, 'Custom profile owner mismatch')
    ids = sorted({key for case in registered['cases'].values() for key in case['metrics']})
    require(set(ids) <= registry['metrics'].keys(), 'Unknown registered metric')
    definitions = {registry['metrics'][key]['native_name']: registry['metrics'][key] for key in ids}
    require(len(definitions) == len(ids), 'Ambiguous native metric mapping')
    profile = copy.deepcopy(registered)
    for case in profile['cases'].values():
        case['metrics'] = [registry['metrics'][key]['native_name'] for key in case['metrics']]
        case['denominators'] = {registry['metrics'][key]['native_name']: value for key, value in case['denominators'].items()}
    return profile, definitions, identity({'profile': registered, 'definitions': definitions})


def custom_source_manifest(workspace, name, *, purpose=None):
    if campaign_purpose(purpose):
        from evaluation_evidence import source_manifest
        return source_manifest(workspace, name, purpose)
    root = workspace / '.github/evals' / name
    directories = {}; states = {}; members = {}; budget = ReadBudget()
    files = safe_tree(root, directory_identities=directories, directory_states=states, file_states=members)
    values = [{'member': p.relative_to(root).as_posix(), 'digest': digest_bytes(read_bytes(p, budget=budget,
        directory_identities=directories, directory_states=states, file_states=members))}
        for p in sorted(files) if p.relative_to(root).parts[0] in ('evals', 'support')]
    helper = 'pester_evaluations.py' if name == 'powershell-pester-6' else 'gh_evaluations.py'
    values.append({'member': 'producer/' + helper, 'digest': digest_bytes(read_bytes(workspace / '.github/scripts' / helper))})
    if purpose in ('cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
        from codex_pilot_contract import pilot_inputs
        values.extend(pilot_inputs(workspace))
        if purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
            from codex_pilot_effectiveness import inputs
            values.extend(inputs(workspace))
            values.append({'member': 'producer/unscored_security.py',
                           'digest': digest_bytes(read_bytes(workspace / '.github/scripts/unscored_security.py'))})
            for member in ('scripts/benchmark_evidence.py',
                           'scripts/evaluator_090.py', 'scripts/evaluator_profiles.py', 'evals/benchmark-090.json'):
                values.append({'member': 'producer/' + member,
                               'digest': digest_bytes(read_bytes(workspace / '.github' / member))})
    input_guard(directories, states, members)()
    return values


def custom_input_identities(workspace, name, inputs=None, *, purpose=None):
    if campaign_purpose(purpose):
        from evaluation_evidence import identities
        return identities(workspace, name, purpose, inputs)
    inputs = custom_source_manifest(workspace, name, purpose=purpose) if inputs is None else inputs
    if purpose in ('cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
        from codex_pilot_iteration import runner_bytes
        from codex_pilot_contract import grader_bytes
        if purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
            from codex_pilot_effectiveness import grader_bytes, runner_bytes, execution_profile_bytes
        replacements = {'support/Runner.ps1': digest_bytes(runner_bytes(workspace)), 'evals/grader.py': digest_bytes(grader_bytes(workspace))}
        if purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
            replacements['support/EXECUTION-PROFILE.md'] = digest_bytes(execution_profile_bytes(workspace))
        inputs = [dict(row, digest=replacements[row['member']]) if row['member'] in replacements else row for row in inputs]
    grader = [row for row in inputs if row['member'] in ('evals/grader.py', 'support/Runner.ps1', 'support/test.sh', 'evals/files/fixture.py')]
    fixture = [row for row in inputs if row['member'].startswith(('support/cases/', 'evals/files/'))
               or row['member'] == 'support/EXECUTION-PROFILE.md']
    if purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
        from codex_pilot_effectiveness import CASES, case_files
        fixture = [row for row in fixture if not row['member'].startswith('support/cases/') or '/input/' in row['member']]
        fixture += [{'member': 'support/cases/' + case + '/' + name, 'digest': digest_bytes(raw)}
                    for case in CASES for name, raw in sorted(case_files(workspace, case).items())]
    runtime = [row for row in inputs if row['member'].startswith(('producer/', 'pilot/'))
               or row['member'] in ('support/install-runtime.py', 'evals/config.yml')]
    return {'grader_digest': identity(grader), 'fixture_digest': identity(fixture),
            'runtime_digest': identity({'files': runtime, 'build': reports.GH_TASK_BUILD})}


def custom_task_checksum(files):
    """Pinned Harbor/dirhash name+data protocol over captured bytes; no traversal."""
    from dirhash import Protocol
    protocol = Protocol()
    def node(prefix):
        names = {name[len(prefix):].split('/')[0] for name in files if name.startswith(prefix)}
        directories = []; ordinary = []
        for name in names:
            member = prefix + name
            is_directory = member not in files
            path = SimpleNamespace(name=name, is_dir=lambda value=is_directory: value)
            target = directories if is_directory else ordinary
            target.append((path, node(member + '/') if is_directory else files[member].removeprefix('sha256:')))
        return hashlib.sha256(protocol.get_descriptor(SimpleNamespace(directories=directories, files=ordinary)).encode()).hexdigest()
    return node('')


def capture_custom_tasks(workspace, name, tasks, arm, *, purpose='benchmark'):
    """Capture verifier-owned staging before execution; publish hashes only."""
    profile, definitions, contract = custom_contract(name, workspace, purpose=purpose)
    if 'campaign' in profile:
        from evaluation_evidence import capture_tasks
        return capture_tasks(workspace, profile, tasks, arm)
    enum(arm, ('with_skill', 'without_skill'))
    rows = []
    for task in tasks:
        directories = {}; states = {}; members = {}; budget = ReadBudget()
        files = safe_tree(task, directory_identities=directories, directory_states=states, file_states=members)
        captured = {p.relative_to(task).as_posix(): read_bytes(p, budget=budget,
            directory_identities=directories, directory_states=states, file_states=members) for p in files}
        entry = parse_json(captured['tests/entry.json'])
        case = entry['id']; token(case)
        source_case = profile['qualification_cases'].get(case) if purpose in ('oracle_qualification', 'cli_pilot_control', 'skill_effectiveness_control') else case
        shared_pester = profile_family(profile) in ('pester-pilot-v3', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-cli-pilot-v1', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6')
        require(source_case in profile['cases'] and entry['grading_mode'] == profile['grading']
                and (('has_skill' not in entry and shared_pester)
                     or entry.get('has_skill') is (arm == 'with_skill')), 'Staged custom identity mismatch')
        if shared_pester:
            prefix = 'environment/skills/' + name + '/'
            actual_skill = {key.removeprefix(prefix): raw for key, raw in captured.items() if key.startswith(prefix)}
            source = workspace / ('.apm/skills' if name == 'powershell-pester-6' else '.agents/skills') / name
            expected_skill = {p.relative_to(source).as_posix(): read_bytes(p) for p in safe_tree(source)
                              if p.relative_to(source).parts[0] != 'evals'} if arm == 'with_skill' else {}
            require(actual_skill == expected_skill, 'Staged target skill drift')
        overlay = workspace / '.github/evals' / name
        grader = read_bytes(overlay / 'evals/grader.py')
        if profile_family(profile) in ('pester-cli-pilot-v1', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
            from codex_pilot_contract import grader_bytes
            if purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
                from codex_pilot_effectiveness import grader_bytes
            grader = grader_bytes(workspace)
        if name == 'gh':
            grader = read_bytes(overlay / 'evals/files/fixture.py').decode().rsplit('\nif __name__ ==', 1)[0].encode() + b'\n' + grader
        if name == 'gh':
            from importlib.metadata import version
            if profiles.is_candidate(profiles.by_version(version('skillevaluator'))):
                from gh_candidate import grader_source
                grader = grader_source(grader, fixture=purpose == 'oracle_qualification')
        if purpose == 'cli_pilot_replay':
            from codex_pilot_replay import SUBMISSIONS
            require(case == 'pester-001' and digest_bytes(captured.get('solution/candidate', b'')) == 'sha256:' + SUBMISSIONS[arm], 'Replay candidate identity mismatch')
        require(captured['tests/verifier/grader.py' if shared_pester else 'tests/grader.py'] == grader, 'Unapproved staged grader')
        if profile_family(profile) == 'gh-native-oracle-v1':
            require(captured['tests/test.sh'] == b'#!/bin/sh\nset -eu\nexec python3 -I /tests/grader.py\n', 'Unapproved fixture verifier entry')
        if shared_pester:
            require(captured['tests/test.sh'] == read_bytes(overlay / 'support/test.sh'), 'Staged verifier entry drift')
        if name == 'powershell-pester-6':
            from codex_pilot_iteration import runner_bytes
            if purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
                from codex_pilot_effectiveness import runner_bytes
            expected_runner = runner_bytes(workspace) if purpose in ('cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control') else read_bytes(overlay / 'support/Runner.ps1')
            require(captured['tests/Runner.ps1'] == expected_runner, 'Staged runner drift')
            fixture_root = overlay / 'support/cases' / source_case
            expected = {p.relative_to(fixture_root).as_posix(): read_bytes(p)
                        for p in safe_tree(fixture_root) if p.relative_to(fixture_root).parts[0] != 'input'}
            if purpose in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
                from codex_pilot_effectiveness import case_files
                expected = case_files(workspace, source_case)
            actual = {key.removeprefix('tests/case/'): value for key, value in captured.items() if key.startswith('tests/case/')}
            require(actual == expected, 'Staged reference or mutant drift')
        hashes = {key: digest_bytes(raw) for key, raw in captured.items()}
        input_guard(directories, states, members)()
        rows.append({'case_id': case, 'source_case_id': source_case, 'arm': arm,
                     'task_checksum': custom_task_checksum(hashes), 'members': hashes})
    require(len(rows) <= MAX_CASES, 'Custom task limit')
    return sorted(rows, key=lambda row: row['case_id'])


def custom_case_mapping(profile, purpose):
    if 'campaign' in profile:
        return profile['qualification_cases']
    if purpose in ('oracle_qualification', 'cli_pilot_control', 'skill_effectiveness_control'):
        return profile['qualification_cases']
    return {case: case for case in profile['cases']
            if profile_family(profile) not in ('pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6') or purpose not in ('skill_effectiveness', 'skill_effectiveness_probe') or case != 'pester-001'}


def custom_prepared_entries(workspace, name, ids, purpose):
    profile, _, _ = custom_contract(name, workspace, purpose=purpose)
    if 'campaign' in profile:
        from evaluation_evidence import task
        adapter = task(profile)
        rows = adapter.entries(profile['campaign']['mode'])
        require(set(ids) <= {r['id'] for r in rows}, 'Unknown campaign cases')
        return sorted((r for r in rows if r['id'] in ids), key=lambda row: row['id'])
    authored = read_json(workspace / '.github/evals' / name / 'evals/evals.json')
    base = {entry['id']: entry for entry in authored['evals']}
    mapping = custom_case_mapping(profile, purpose)
    rows = []
    for case in ids:
        require(case in mapping, 'Unknown prepared case')
        entry = copy.deepcopy(base[mapping[case]])
        if name == 'gh':
            import gh_evaluations as gh
            entry = gh.enriched(entry, workspace)
            if profile_family(profile) == 'gh-native-oracle-v1':
                entry['contract']['allowed_reads'] = sorted(entry['contract']['allowed_reads'])
        entry['id'] = case
        rows.append(entry)
    return rows


def capture_custom_numeric_fields(workspace, name, original_jobs, source_root, tasks, *, purpose=None):
    """Retain only enrolled numeric fields that native key-redaction would lose.

    This is a producer-captured native extract, not an authentication receipt.
    Original private reports remain untouched and outside publication allowlists.
    """
    from skillevaluator.utils.redaction import is_sensitive_key
    profile, definitions, _ = custom_contract(name, workspace, purpose=purpose)
    enrolled = {key: definition for key, definition in definitions.items() if is_sensitive_key(key)}
    if not enrolled: return []
    directories = {}; states = {}; members = {}; budget = ReadBudget()
    files = safe_tree(original_jobs, directory_identities=directories, directory_states=states, file_states=members)
    expected = {(task['arm'], task['case_id']): task['task_checksum'] for task in tasks}
    rows = []
    for path in sorted(files):
        if path.name != 'result.json' or not (path.parent / 'verifier/reward.json') in files: continue
        raw = read_bytes(path, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
        result = parse_json(raw)
        if result.get('exception_info') is not None or not result.get('finished_at'): continue
        sidecar_path = path.parent / 'verifier/skill_evaluator_reward.json'
        require(sidecar_path in files, 'Missing verifier identity sidecar')
        sidecar = parse_json(read_bytes(sidecar_path, budget=budget, directory_identities=directories, directory_states=states, file_states=members))
        if sidecar.get('evaluation_status') in ('failed', 'error'): continue
        case = sidecar.get('entry_id'); present = sidecar.get('has_skill')
        boolean(present); arm = 'with_skill' if present else 'without_skill'
        require((arm, case) in expected and result.get('task_checksum') == expected[arm, case], 'Numeric extract task mismatch')
        for key, definition in enrolled.items():
            value = (result.get('verifier_result') or {}).get('rewards', {}).get(key)
            if value is None: continue
            number(value)
            require(definition['basis'] != 'binary' or value in (0, 1), 'Invalid enrolled numeric field')
            require((sidecar.get('custom_metrics') or {}).get(key) == value, 'Original numeric carrier mismatch')
            rows.append({'native_id': result['id'], 'case_id': case, 'arm': arm,
                         'task_checksum': result['task_checksum'], 'metric_id': definition['id'], 'value': value,
                         'source_member': path.relative_to(source_root).as_posix(), 'source_digest': digest_bytes(raw),
                         'locator': ['verifier_result', 'rewards', key]})
    input_guard(directories, states, members)()
    require(len(rows) <= MAX_TRIALS * len(enrolled), 'Native numeric extract limit')
    return sorted(rows, key=lambda row: (row['arm'], row['native_id'], row['metric_id']))


def custom_numeric_excerpts(capture, definitions):
    from skillevaluator.utils.redaction import is_sensitive_key
    rows = capture['numeric_excerpts']
    enrolled = {definition['id']: key for key, definition in definitions.items() if is_sensitive_key(key)}
    require(type(rows) is list and len(rows) <= MAX_TRIALS * len(enrolled), 'Numeric excerpt limit')
    output = {}; seen = set()
    tasks = {(task['arm'], task['case_id']): task['task_checksum'] for task in capture['tasks']}
    for row in rows:
        closed(row, ('native_id', 'case_id', 'arm', 'task_checksum', 'metric_id', 'value', 'source_member', 'source_digest', 'locator'))
        token(row['native_id']); enum(row['arm'], ('with_skill', 'without_skill'))
        require(row['metric_id'] in enrolled and (row['arm'], row['case_id']) in tasks
                and tasks[row['arm'], row['case_id']] == row['task_checksum'], 'Unapproved numeric extract origin')
        key = row['arm'], row['native_id'], row['metric_id']; require(key not in seen, 'Duplicate numeric extract'); seen.add(key)
        relative(row['source_member']); sha(row['source_digest']); number(row['value'])
        native = enrolled[row['metric_id']]
        require(row['locator'] == ['verifier_result', 'rewards', native] and row['source_member'].endswith('/result.json'), 'Numeric extract locator mismatch')
        if definitions[native]['basis'] == 'binary': require(row['value'] in (0, 1), 'Nonbinary original field')
        output.setdefault((row['arm'], row['native_id']), {})[native] = row
    return output


def restore_captured_numeric_fields(values, excerpts, arm, native_id, case):
    """Use a typed original field only for the pinned redaction placeholder."""
    output = copy.deepcopy(values)
    for native, row in excerpts.get((arm, native_id), {}).items():
        require(row['case_id'] == case, 'Numeric extract trial mismatch')
        if native not in output:
            from importlib.metadata import version
            require(profiles.is_candidate(profiles.by_version(version('skillevaluator'))), 'Numeric extract trial mismatch')
            output[native] = '<redacted>'
        require(output[native] == '<redacted>' or type(output[native]) in (int, float) and output[native] == row['value'],
                'Numeric extract contradicts retained carrier')
        output[native] = row['value']
    return output


def custom_staged_inputs(tasks, purpose):
    """Dataset identity excludes the target skill, grader and staging nonces."""
    cases = {}
    for task in tasks:
        members = task['members']
        value = {'case_id': task['case_id'], 'instruction_digest': members['instruction.md'],
                 'agent_inputs': {key.removeprefix('environment/input/'): digest for key, digest in members.items()
                                  if key.startswith('environment/input/')}}
        if purpose == 'oracle_qualification' or (campaign_purpose(purpose) and purpose.endswith(('-oracle','-replay'))):
            require('solution/candidate' in members, 'Missing oracle candidate identity')
            value['candidate_digest'] = members['solution/candidate']
        previous = cases.setdefault(task['case_id'], value)
        require(previous == value, 'With/without task input drift')
    return [cases[key] for key in sorted(cases)]


def custom_authored_digest(workspace, name, profile):
    campaign_dataset = profile.get('campaign', {}).get('dataset')
    if campaign_dataset is None:
        return digest_bytes(read_bytes(workspace / '.github/evals' / name / 'evals/evals.json'))
    closed(campaign_dataset, ('path', 'digest'))
    member = campaign_dataset['path']
    require(name == 'podman' and member == '.github/evals/podman/storage/eval.json',
            'Unregistered campaign dataset path')
    digest = digest_bytes(read_bytes(workspace / member))
    require(digest == campaign_dataset['digest'] == profile['dataset_digest'], 'Authored dataset drift')
    return digest


def custom_capture(workspace, name, bundle, task_rows, *, purpose, attempts, agent, execution_policy, numeric_excerpts=(),
                   retrospective=None, scheduler_digest=None, producer_versions=None):
    """Prospective capture used by shared collection and credential-free qualification."""
    from importlib.metadata import version
    producer = profiles.by_version(version('skillevaluator'))
    if producer_versions is not None:
        from benchmark_native import native_versions

        require(name == 'powershell-pester-6' and purpose == 'benchmark' and producer_versions == native_versions(),
                'Invalid released diagnostic capture owner')
        producer = profiles.runtime(producer_versions, owning=True)
    require(version('skillevaluator') == producer['version'] and version('harbor') == producer['harbor']
            and '.'.join(map(str,sys.version_info[:3])).startswith(producer['python']), 'Unsupported capture runtime')
    profile, definitions, contract = custom_contract(name, workspace, purpose=purpose)
    validate_custom_purpose(purpose)
    expected = custom_case_mapping(profile, purpose)
    dataset = read_json(bundle / 'evals/evals.json')
    ids = case_ids(sorted(row['id'] for row in dataset['evals']))
    require(set(ids) == set(expected) and bool(ids), 'Unapproved custom cohort')
    prepared = custom_prepared_entries(workspace, name, ids, purpose)
    require(sorted(dataset['evals'], key=lambda row: row['id']) == prepared, 'Prepared dataset drift')
    if purpose == 'oracle_qualification': require(set(ids) == set(expected), 'Incomplete qualification profile')
    for arm in ('with_skill', 'without_skill'):
        rows = [row for row in task_rows if row['arm'] == arm]
        require(sorted(row['case_id'] for row in rows) == ids, 'Incomplete staged custom arms')
    inv = inventory(workspace)
    src = next(row['source'] for row in inv['skills'] if row['source']['skill_id'] == name)
    if 'skill_source' in profile:
        from evaluation_evidence import selected_identity
        src = selected_identity(workspace, profile, src)
    capture = {'schema_version': 1, 'skill': name, 'contract_digest': contract, 'purpose': purpose,
            'source': src, 'inputs': custom_source_manifest(workspace, name, purpose=purpose),
            'authored_digest': custom_authored_digest(workspace, name, profile),
            'prepared_dataset_digest': identity(prepared),
            'case_ids': ids, 'tasks': sorted(task_rows, key=lambda row: (row['arm'], row['case_id'])),
            'attempts': attempts, 'agent': agent, 'execution_policy': execution_policy, 'numeric_excerpts': list(numeric_excerpts),
            'evaluator_revision': producer['revision'], 'evaluator_version': producer['version'],
            'harbor_version': version('harbor'), 'python_version': '.'.join(map(str, sys.version_info[:3])), 'runtime': profile['runtime']}

    if profile.get('campaign', {}).get('scheduler'):
        sha(scheduler_digest); capture['scheduler_digest'] = scheduler_digest
    else:
        require(scheduler_digest is None, 'Unexpected scheduler witness')
    if replay_purpose(purpose):
        validate_replay_metadata(retrospective,profile,purpose,workspace)
        capture['retrospective'] = copy.deepcopy(retrospective)
    else:
        require(retrospective is None, 'Unexpected retrospective metadata')
    if producer_versions is not None:
        capture['producer'] = producer_versions
    elif profiles.is_candidate(producer):
        capture['producer'] = profiles.candidate_versions(producer)
        profiles.runtime(capture['producer'], owning=True)
    return capture


def restore_historical_gh_file_order(prepared, snapshot):
    from gh_evaluations import COMPETING

    prefix = f'skills/{COMPETING}/'
    require(type(snapshot) is dict, 'Invalid historical gh preparation')
    stored = snapshot.get('dataset')
    require(type(stored) is list and all(type(row) is dict and type(row.get('contract')) is dict
            and 'allowed_reads' in row['contract'] for row in stored), 'Invalid historical gh preparation')
    case_ids([row.get('id') for row in stored])
    require({row['id'] for row in stored} == {row['id'] for row in prepared},
            'Historical gh preparation cohort differs')
    by_case = {row['id']: row['contract']['allowed_reads'] for row in stored}
    for row in prepared:
        reads = row['contract']['allowed_reads']
        recorded = by_case[row['id']]
        require(type(recorded) is list and len(recorded) == len(reads)
                and all(type(item) is str for item in recorded), 'Invalid historical gh file order')
        offset = next((index for index, item in enumerate(reads) if item.startswith(prefix)), len(reads))
        require(reads[:offset] == recorded[:offset] and sorted(reads[offset:]) == sorted(recorded[offset:]),
                'Historical gh preparation file membership differs')
        row['contract']['allowed_reads'] = recorded


def validate_custom_capture(capture, name, workspace, *, captured_state=None, read_prepared_snapshot=None):
    require(type(capture) is dict, 'Invalid custom capture')
    closed(capture, ('schema_version', 'skill', 'contract_digest', 'purpose', 'source', 'inputs',
        'authored_digest', 'prepared_dataset_digest', 'case_ids', 'tasks', 'attempts', 'agent', 'execution_policy', 'numeric_excerpts',
        'evaluator_revision', 'evaluator_version', 'harbor_version', 'python_version', 'runtime') +
        (('producer',) if profiles.candidate_revision(capture.get('evaluator_revision')) else ()) +
        (('retrospective',) if replay_purpose(capture.get('purpose')) else ()) +
        (('scheduler_digest',) if 'scheduler_digest' in capture else ()))
    local_podman = name == 'podman' and campaign_purpose(capture.get('purpose'))
    if captured_state is not None:
        directories, states, members, budget = captured_state
        for source_root in (workspace / '.github/evals' / name, workspace / '.apm/skills' / name
                            if name == 'powershell-pester-6' or local_podman else workspace / '.agents/skills' / name):
            for member in safe_tree(source_root, directory_identities=directories, directory_states=states, file_states=members):
                read_bytes(member, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
        for registry_member in (CUSTOM_REGISTRY, SOURCE_SUCCESSORS, MODEL_SUCCESSORS,
                                SCORED_SUCCESSORS, PODMAN_SOURCE_SUCCESSORS, PROBE_SOURCE_SUCCESSORS, MOUNT_SOURCE_SUCCESSORS, CAMPAIGN_SOURCE_SUCCESSORS, RETIREMENT_SOURCE_SUCCESSORS, PUBLICATION_SOURCE_SUCCESSORS, DIAGNOSTIC_SOURCE_SUCCESSORS, DIRECT_TOOL_SOURCE_SUCCESSORS, NATIVE_RETIREMENT_SOURCE_SUCCESSORS, RELEASE_121_SOURCE_SUCCESSORS):
            read_bytes(workspace / registry_member, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
        if local_podman:
            for member in ('.apm/skills/podman/evals/evals.json', '.apm/skills/podman/evals/files/vendor-compose.yaml',
                           '.apm/skills/podman/evals/files/vendor-web/Containerfile'):
                read_bytes(workspace / member, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
        else:
            helper = 'pester_evaluations.py' if name == 'powershell-pester-6' else 'gh_evaluations.py'
            read_bytes(workspace / '.github/scripts' / helper, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
    purpose = capture['purpose']
    profile, definitions, contract = custom_contract(name, workspace, purpose=purpose)
    approved_inputs = custom_source_manifest(workspace, name, purpose=purpose)
    if name == 'gh' and capture['contract_digest'] != contract and purpose in ('benchmark', 'oracle_qualification'):
        historical = {'benchmark': 'gh-deterministic-gate-v9', 'oracle_qualification': 'gh-native-oracle-v5'}
        profile, definitions, contract = custom_contract(name, workspace, profile_id=historical[purpose])
        # These captures bind the original helper at bc96c28. Only its CLI
        # changed at retirement. All other source members still match live bytes.
        digest = 'sha256:b4a5fe5f4bf7d306ea8faa77b16d8668e0cbbab365205de29cb34aa0cc231aa0'
        approved_inputs = [dict(row, digest=digest) if row['member'] == 'producer/gh_evaluations.py' else row
                           for row in approved_inputs]
    require(bool(profile.get('campaign', {}).get('scheduler')) == ('scheduler_digest' in capture),
            'Missing or unexpected scheduler capture')
    if 'scheduler_digest' in capture: sha(capture['scheduler_digest'])
    require(type(capture['schema_version']) is int and capture['schema_version'] == 1 and capture['skill'] == name
            and capture['contract_digest'] == contract, 'Custom contract identity mismatch')
    require(capture['inputs'] == approved_inputs, 'Approved custom input drift')
    identities = custom_input_identities(workspace, name, capture['inputs'], purpose=capture['purpose'])
    require(all(profile[key] == value for key, value in identities.items()), 'Unregistered grader, fixture or runtime version')
    require(capture['authored_digest'] == profile['dataset_digest'] == custom_authored_digest(workspace, name, profile),
            'Authored dataset drift')
    producer = profiles.by_revision(capture['evaluator_revision'])
    from benchmark_native import NATIVE_OWNERS

    recorded = capture.get('producer')
    recorded_owner = recorded.get('producer_profile') if type(recorded) is dict else None
    released_diagnostic = type(recorded_owner) is str and recorded_owner in NATIVE_OWNERS
    if released_diagnostic:
        from benchmark_native import DIAGNOSTIC_BACKEND, LOOPBACK_VERIFIER, native_versions

        require(name == 'powershell-pester-6' and capture['purpose'] == 'benchmark'
                and capture['producer'] == native_versions(owner=recorded_owner) and capture['attempts'] == reports.MODES['confirmation'],
                'Invalid released diagnostic capture')
        profiles.runtime(capture['producer'], owning=True)
    if profile_family(profile) == 'gh-native-oracle-v1':
        require(profiles.is_candidate(producer), 'Native gh oracle requires a qualified candidate')
    if 'campaign' in profile:
        from evaluation_evidence import task as campaign_task
        from evaluation_runtime import evaluator, read_profile
        require(producer is evaluator(read_profile(ROOT / campaign_task(profile).definition['runtime_profile'])),
                'Campaign requires the selected owning evaluator')
    if producer is profiles.NEXT:
        require((capture['purpose'] in ('benchmark', 'oracle_qualification') or 'campaign' in profile) and capture['agent'] in ('oracle', 'codex'),
                'New candidate is credential-free qualification only')
    if profiles.is_candidate(producer) and not released_diagnostic:
        require(capture['producer'] == profiles.candidate_versions(producer), 'Contradictory custom producer identity')
        profiles.runtime(capture['producer'], owning=True)
    require(type(capture['python_version']) is str and (capture['python_version'] == producer['python'] if profiles.is_candidate(producer) else
            bool(re.fullmatch(r'3\.13\.[0-9]+', capture['python_version']))), 'Unsupported capture Python')
    require(capture['evaluator_version'] == producer['version'] and capture['harbor_version'] == producer['harbor']
            and capture['runtime'] == profile['runtime'], 'Custom runtime identity mismatch')
    validate_custom_purpose(capture['purpose']); validate_source(capture['source'])
    if replay_purpose(capture['purpose']):
        validate_replay_metadata(capture['retrospective'],profile,capture['purpose'],workspace)
    count(capture['attempts'], 100); require(capture['attempts'] > 0, 'Zero planned attempts')
    if capture['purpose'] in ('cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
        require(name == 'powershell-pester-6' and producer is profiles.CANDIDATE and capture['attempts'] == (3 if capture['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe') else 1), 'Pilot runtime or attempts drift')
    require(capture['agent'] == custom_agent(profile, capture['purpose']), 'Unknown custom producer')
    sha(capture['prepared_dataset_digest'])
    execution = capture['execution_policy']
    closed(execution, ('environment', 'concurrency', 'timeout_multiplier', 'stop_on_pass'))
    if 'campaign' in profile:
        require(execution == {'environment': profile['campaign']['environment_mode'], 'concurrency': 1,
                'timeout_multiplier': 1.0, 'stop_on_pass': False} and capture['attempts'] == profile['campaign'].get('trials', 1), 'Campaign execution policy drift')
    else:
        environment = ('aeb-gh-fixture' if name == 'gh' and capture['purpose'] == 'oracle_qualification' else 'docker')
        if released_diagnostic:
            environment = DIAGNOSTIC_BACKEND
        require(execution['environment'] == environment and execution['concurrency'] == (1 if capture['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe') else reports.POLICY['concurrency'])
                and execution['stop_on_pass'] is False and execution['timeout_multiplier'] ==
                (1.0 if capture['purpose'] in ('oracle_qualification', 'cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control') else reports.POLICY['timeout_multiplier']), 'Execution policy drift')
    ids = case_ids(capture['case_ids'])
    mapping = custom_case_mapping(profile, capture['purpose'])
    prepared = custom_prepared_entries(workspace, name, ids, capture['purpose'])
    if (capture['prepared_dataset_digest'] != identity(prepared) and read_prepared_snapshot is not None
            and name == 'gh' and capture['purpose'] == 'benchmark'
            and capture['evaluator_revision'] == profiles.HISTORICAL_REVISION):
        restore_historical_gh_file_order(prepared, read_prepared_snapshot())
    require(capture['prepared_dataset_digest'] == identity(prepared), 'Prepared dataset identity mismatch')
    source_root = workspace / ('.apm/skills' if name == 'powershell-pester-6' or local_podman else '.agents/skills') / name
    if 'skill_source' in profile:
        from evaluation_evidence import selected_source
        source_root = selected_source(workspace, profile)
        require(capture['source']['source_path'] == source_root.relative_to(workspace).as_posix(), 'Campaign source path drift')
    if local_podman:
        configured = next(row['source'] for row in inventory(workspace)['skills']
                          if row['source']['skill_id'] == name)
        require(capture['source'] == configured, 'Podman source identity drift')
    require(capture['source']['skill_id'] == name
            and capture['source']['owner'] == ('local' if name == 'powershell-pester-6' or local_podman else 'upstream')
            and (name != 'gh' or capture['source']['repository'] == 'cli/cli'
                 and capture['source']['revision'] == reports.benchmark_policy('gh')['upstream_revision']
                 and capture['source']['source_path'] == 'skills/gh')
            and skill_content(source_root)['digest'] == capture['source']['content']['digest'],
            'Declared skill content drift')
    require(set(ids) == set(mapping) and bool(ids), 'Unknown custom case')
    if capture['purpose'] == 'oracle_qualification':
        require(set(ids) == set(mapping) and capture['agent'] == 'oracle' and capture['attempts'] == 1,
                'Qualification producer mismatch')
    require(type(capture['tasks']) is list and len(capture['tasks']) == len(ids) * 2, 'Staged task coverage')
    require([(r['arm'], r['case_id']) for r in capture['tasks']] == sorted((r['arm'], r['case_id']) for r in capture['tasks']),
            'Noncanonical staged task identities')
    seen = set()
    for task in capture['tasks']:
        closed(task, ('case_id', 'source_case_id', 'arm', 'task_checksum', 'members'))
        enum(task['arm'], ('with_skill', 'without_skill'))
        require(task['case_id'] in ids and mapping[task['case_id']] == task['source_case_id'], 'Task case mapping drift')
        key = task['arm'], task['case_id']; require(key not in seen, 'Duplicate staged task'); seen.add(key)
        require(type(task['members']) is dict and 0 < len(task['members']) <= MAX_SOURCE_MEMBERS, 'Task member limit')
        for member, digest in task['members'].items(): relative(member); sha(digest)
        require(task['task_checksum'] == custom_task_checksum(task['members']), 'Staged checksum mismatch')
        if 'campaign' in profile:
            from evaluation_evidence import validate_task
            validate_task(profile, task['members'], task['case_id'], task['arm'])
            continue
        if capture['purpose'] == 'cli_pilot_replay':
            from codex_pilot_replay import SUBMISSIONS
            require(task['members'].get('solution/candidate') == 'sha256:' + SUBMISSIONS[task['arm']], 'Replay staged candidate mismatch')
        overlay = workspace / '.github/evals' / name
        grader = read_bytes(overlay / 'evals/grader.py')
        if profile_family(profile) in ('pester-cli-pilot-v1', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
            from codex_pilot_contract import grader_bytes
            if capture['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
                from codex_pilot_effectiveness import grader_bytes
            grader = grader_bytes(workspace)
        if name == 'gh': grader = read_bytes(overlay / 'evals/files/fixture.py').decode().rsplit('\nif __name__ ==', 1)[0].encode() + b'\n' + grader
        if name == 'gh' and profiles.is_candidate(producer):
            from gh_candidate import grader_source
            grader = grader_source(grader, fixture=capture['purpose'] == 'oracle_qualification')
        shared_pester = profile_family(profile) in ('pester-pilot-v3', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-cli-pilot-v1', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6')
        require(task['members'].get('tests/verifier/grader.py' if shared_pester else 'tests/grader.py') == digest_bytes(grader), 'Staged grader drift')
        if profile_family(profile) == 'gh-native-oracle-v1':
            require(task['members'].get('tests/test.sh') == digest_bytes(b'#!/bin/sh\nset -eu\nexec python3 -I /tests/grader.py\n'), 'Unapproved fixture verifier entry')
        if shared_pester:
            expected_entry = json.dumps({'id': task['case_id'], 'grading_mode': 'custom_only'}, indent=2) + '\n'
            require(task['members'].get('tests/entry.json') == digest_bytes(expected_entry.encode())
                    and task['members'].get('tests/test.sh') == digest_bytes(read_bytes(overlay / 'support/test.sh')),
                    'Staged verifier metadata drift')
        entry = next(row for row in prepared if row['id'] == task['case_id'])
        require(task['members'].get('instruction.md') == digest_bytes((entry['prompt'] + '\n').encode()), 'Staged instruction drift')
        prefix = 'environment/skills/' + name + '/'
        actual_skill = {key.removeprefix(prefix): value for key, value in task['members'].items() if key.startswith(prefix)}
        expected_skill = {row['member']: row['digest'] for row in capture['source']['content']['manifest']} if task['arm'] == 'with_skill' else {}
        require(actual_skill == expected_skill, 'Staged target skill drift')
        if name == 'powershell-pester-6':
            if released_diagnostic:
                require(task['members'].get('tests/docker-compose.yaml') == digest_bytes(LOOPBACK_VERIFIER.encode()),
                        'Unapproved released verifier isolation')
            fixture_root = overlay / 'support/cases' / task['source_case_id']
            expected = {p.relative_to(fixture_root).as_posix(): digest_bytes(read_bytes(p))
                        for p in safe_tree(fixture_root) if p.relative_to(fixture_root).parts[0] != 'input'}
            if capture['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
                from codex_pilot_effectiveness import case_files
                expected = {k: digest_bytes(v) for k, v in case_files(workspace, task['source_case_id']).items()}
            actual = {key.removeprefix('tests/case/'): value for key, value in task['members'].items() if key.startswith('tests/case/')}
            expected_input = {'environment/input/' + p.relative_to(fixture_root / 'input').as_posix(): digest_bytes(read_bytes(p))
                              for p in safe_tree(fixture_root / 'input')}
            if task['source_case_id'] != 'pester-005':
                expected_input['environment/input/EXECUTION-PROFILE.md'] = digest_bytes(read_bytes(overlay / 'support/EXECUTION-PROFILE.md'))
                if capture['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
                    from codex_pilot_effectiveness import execution_profile_bytes
                    expected_input['environment/input/EXECUTION-PROFILE.md'] = digest_bytes(execution_profile_bytes(workspace))
            require({key: value for key, value in task['members'].items() if key.startswith('environment/input/')} == expected_input,
                    'Staged agent input drift')
            from codex_pilot_iteration import runner_bytes
            if capture['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control'):
                from codex_pilot_effectiveness import runner_bytes
            expected_runner = runner_bytes(workspace) if capture['purpose'] in ('cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control') else read_bytes(overlay / 'support/Runner.ps1')
            require(actual == expected and task['members'].get('tests/Runner.ps1') == digest_bytes(expected_runner),
                    'Staged fixture drift')
    custom_numeric_excerpts(capture, definitions)
    custom_staged_inputs(capture['tasks'], capture['purpose'])
    return profile, definitions


def custom_measurements(definitions, case, outcome, native, details, references):
    values = []
    applicable = set(case['metrics'])
    require(set(native) <= applicable, 'Unknown or nonapplicable custom metric')
    measured = outcome in CUSTOM_MEASURED
    require(not native if not measured else set(native) == applicable, 'Custom outcome/metric coverage mismatch')
    for key, definition in sorted(definitions.items()):
        applies = key in applicable
        numerator = denominator = value = None
        reason = 'not_applicable' if not applies else outcome if not measured else None
        if applies and measured:
            value = native[key]; number(value)
            if definition['basis'] == 'ratio':
                numerator, denominator = details.get('mutants_detected'), details.get('mutants_executed')
                count(numerator); count(denominator)
                require(denominator == case['denominators'][key] and numerator <= denominator and denominator > 0,
                        'Invalid mutation denominator')
                require(value == numerator / denominator, 'Incorrect custom arithmetic')
            else:
                require(value in (0, 1), 'Nonbinary custom metric')
                numerator, denominator = int(value), 1
        values.append({'metric_id': definition['id'], 'applicability': 'applicable' if applies else 'not_applicable',
                       'status': 'measured' if applies and measured else 'unavailable',
                       'value': value, 'numerator': numerator, 'denominator': denominator,
                       'reason': reason, 'references': references})
    if measured and 'pester_reference_pass' in native:
        require(type(details.get('reference_pass')) is int and details['reference_pass'] in (0, 1)
                and details.get('reference_pass') == native['pester_reference_pass']
                and native['pester_test_quality'] == float(bool(native['pester_reference_pass'])
                    and details['mutants_detected'] == details['mutants_executed'])
                and outcome == ('passed' if native['pester_test_quality'] else 'failed'), 'Pester joint outcome mismatch')
    if measured and 'negative_control_correct' in native:
        require(type(details.get('negative_control_correct')) is int
                and details.get('negative_control_correct') == native['negative_control_correct']
                and outcome == ('passed' if native['negative_control_correct'] else 'failed'), 'Control outcome mismatch')
    if measured and 'podman_postgres_storage' in native:
        require(native['podman_postgres_storage'] == float(outcome == 'passed'), 'Podman storage outcome mismatch')
    if 'gh_gate' in native:
        require(native['gh_gate'] == float(all(value == 1 for key, value in native.items() if key != 'gh_gate')),
                'Gate consistency')
    return values


def validate_custom_execution_config(purpose, config, attempts):
    """Replay uses an oracle agent and retains its distinct producer identity."""
    if replay_purpose(purpose):
        require(config.get('qualification') == {'producer': 'retained_submission_replay', 'inference': False}, 'Retrospective purpose mismatch')
    elif oracle_purpose(purpose):
        require(config.get('qualification') == {'producer': 'oracle', 'inference': False}, 'Oracle purpose mismatch')
    elif purpose in ('cli_pilot_probe', 'skill_effectiveness_probe') or (campaign_purpose(purpose) and purpose.endswith('-probe')):
        require(config.get('qualification') == {'producer': 'cli_probe', 'inference': False}, 'CLI probe purpose mismatch')
    else:
        if campaign_purpose(purpose) and purpose.endswith('-live'):
            require(config.get('qualification') == {'producer':'live', 'inference':True}, 'Live campaign purpose mismatch')
        require(config.get('harbor', {}).get('n_attempts') == attempts
                and config.get('harbor', {}).get('stop_on_pass') is False, 'Custom execution policy mismatch')


def normalize_custom_behavioral(root, name, selected=None, workspace=ROOT, *, native_layout=False):
    """Shared native admission for registered custom-only and default-plus-custom data."""
    directories = {}; states = {}; members = {}; budget = ReadBudget()
    root = safe_path(root, directory=True, directory_identities=directories)
    files = safe_tree(root, directory_identities=directories, directory_states=states, file_states=members,
                      native_layout_skill=name if native_layout else None)
    entries = set(files) | set(directories)
    run = select_run(root, name, selected, entries=entries, directory_identities=directories)
    captured = {}; refs = []
    def read(path):
        require(path in entries, 'Missing captured custom evidence')
        if path not in captured:
            raw = read_bytes(path, budget=budget, directory_identities=directories, directory_states=states, file_states=members)
            captured[path] = (parse_json(raw), digest_bytes(raw))
        return captured[path][0]
    def ref(path, locator=()):
        read(path)
        value = reference_from_digest(root, path, run.name, captured[path][1], locator)
        if value['id'] not in {row['id'] for row in refs}: refs.append(value)
        return value['id']
    capture = read(root / CUSTOM_CAPTURE)
    profile, definitions = validate_custom_capture(capture, name, workspace,
        captured_state=(directories, states, members, budget),
        read_prepared_snapshot=lambda: read(run / 'dataset_snapshot.json'))
    scheduler = None
    if 'scheduler_digest' in capture:
        import campaign_scheduler_evidence as scheduler_evidence
        from evaluation_evidence import task as campaign_task
        scheduler = read(root / scheduler_evidence.MEMBER)
        require(captured[root / scheduler_evidence.MEMBER][1] == capture['scheduler_digest'], 'Scheduler witness digest mismatch')
        require(scheduler['mode'] == profile['campaign']['mode'], 'Scheduler/profile origin mismatch')
        scheduler_evidence.validate(scheduler, campaign_task(profile), staged=capture['tasks'])
        scheduler_ref = ref(root / scheduler_evidence.MEMBER)
    numeric_excerpts = custom_numeric_excerpts(capture, definitions)
    capture_ref = ref(root / CUSTOM_CAPTURE)
    result = read(run / 'result.json'); config = read(run / 'run_config.json')
    require(result.get('skill_name') == name and set(result.get('agents', {})) == {custom_carrier(profile)}
            and result.get('report_status') in ('complete', 'incomplete'), 'Custom native envelope')
    require(result.get('run_config', config) == config and config.get('grading', {}).get('mode') == profile['grading'],
            'Custom grading configuration mismatch')
    require(config.get('judge', {}).get('enabled') is False if profile['grading'] == 'custom_only' else True,
            'Custom-only judge must be explicitly disabled')
    validate_custom_execution_config(capture['purpose'], config, capture['attempts'])
    if 'producer_profile' in capture.get('producer', {}):
        harbor = config['harbor']
        execution = capture['execution_policy']
        require(harbor['environment']['value'] == execution['environment']
                and harbor['n_concurrent'] == execution['concurrency']
                and harbor['timeout_multiplier'] == execution['timeout_multiplier']
                and config['task_source'] == 'native_harbor' and config['skill_workspace']['mode'] == 'isolated',
                'Released diagnostic run configuration differs from its capture')
    ref(run / 'result.json'); config_ref = ref(run / 'run_config.json')
    agent = result['agents'][custom_carrier(profile)]
    if profile['grading'] == 'custom_only':
        require(all(not agent.get(key) for key in ('with_skill', 'without_skill', 'dimensions_with_skill', 'dimensions_without_skill', 'lift')),
                'Custom-only native report contains standard judge aggregates')
    conditions = agent.get('conditions', {})
    require(set(conditions) == {'with_skill', 'without_skill'}, 'Custom arm coverage')
    tasks = {(row['arm'], row['case_id']): row for row in capture['tasks']}
    mapping = custom_case_mapping(profile, capture['purpose'])
    cases = [{'case_id': case, 'source_case_id': mapping[case], **profile['cases'][mapping[case]]} for case in capture['case_ids']]
    # Retain the supported v1 standard path and its arithmetic/gate checks.
    standard = None
    if profile['grading'] == 'default_plus_custom':
        standard = _normalize_behavioral_v1(root, name, selected, workspace, native_layout=native_layout, _numeric_excerpts=numeric_excerpts, _custom_admission=True)
        data = copy.deepcopy(dict(standard))
        require(all(data['source'][key] == capture['source'][key] for key in
                    ('skill_id', 'owner', 'repository', 'revision', 'source_path')), 'Captured source origin contradiction')
        data['source'] = copy.deepcopy(capture['source'])
    else:
        fields = {key: None for key in POLICY_FIELDS}
        fields.update(evaluator_revision=capture['evaluator_revision'], harbor=capture['harbor_version'], python=capture['python_version'],
            grading='custom_only', concurrency=capture['execution_policy']['concurrency'],
            timeout_multiplier=capture['execution_policy']['timeout_multiplier'], baseline=True, stop_on_pass=False,
            environment=capture['execution_policy']['environment'], workspace_mode='isolated', task_source='native_harbor',
            model=config.get('provider', {}).get('model'), provider=config.get('provider', {}).get('name'))
        if profile_family(profile) == 'gh-native-oracle-v1':
            gh_policy = reports.benchmark_policy('gh')
            fields.update({key: gh_policy[key] for key in ('workspace_mode', 'upstream_revision', 'competing_revision',
                'authorization_policy', 'fixture_boundary', 'task_build')})
        if 'campaign' in profile:
            from evaluation_evidence import task_policy_fields
            fields.update(task_policy_fields(profile))
        patch = ('sha256:' + capture['producer']['patch_sha256'] if profiles.candidate_revision(capture['evaluator_revision'])
                 else digest_bytes(read_bytes(workspace / reports.PATCH)))
        policy = make_policy(fields, patch, 'custom-only',
            {'model': None, 'provider': None, 'enabled': False},
            {'mode': 'unknown' if campaign_purpose(capture['purpose']) or capture['purpose'] in ('oracle_qualification', 'cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control') else 'confirmation',
             'maximum': capture['attempts'], 'stop_on_pass': False, 'pass_threshold': None}, 'runtime_recorded')
        data = evidence(name, 'behavioral', capture['case_ids'], capture['source'], policy)
        data['run_id'] = run.name
        data['dataset'].update(owner='overlay', authored_digest=capture['authored_digest'],
            authored_provenance='runtime_recorded', staged_digest=identity(custom_staged_inputs(capture['tasks'], capture['purpose'])),
            staged_algorithm='sha256-staged-task-inputs-v1', staged_provenance='runtime_recorded')
    data['schema_version'] = 2
    data['custom'] = {'profile_id': profile['id'], 'contract_digest': capture['contract_digest'],
        'definitions': [{'native_name': key, **definition} for key, definition in sorted(definitions.items())],
        'cases': cases, 'purpose': capture['purpose'], 'agent': capture['agent'],
        'runtime': capture['runtime'], 'native_metric_set': result.get('metric_set'), 'capture_digest': captured[root / CUSTOM_CAPTURE][1],
        'capture_reference': capture_ref, **{key: profile[key] for key in ('grader_digest', 'fixture_digest', 'runtime_digest')},
        'assurance': copy.deepcopy(CUSTOM_ASSURANCE)}
    if scheduler is not None:
        data['custom']['scheduler'] = {'reference': scheduler_ref, 'witness': copy.deepcopy(scheduler)}
    if replay_purpose(capture['purpose']):
        data['custom']['retrospective'] = copy.deepcopy(capture['retrospective'])
    old = {(obs['arm'], obs['native_trial']): obs for obs in data['observations']}
    original_rewards = {'with_skill': [], 'without_skill': []}
    computed_custom = {}
    agent_versions = set(); observations = []; arms = []; limitations = set(data['availability']['reasons'] if standard else ())
    if standard:
        if data['source']['content']['digest'] is not None: limitations.discard('source_unavailable')
        refs.extend(row for row in standard['references'] if row['id'] not in {ref['id'] for ref in refs})
    for arm in ('with_skill', 'without_skill'):
        arm_dir = run / custom_carrier(profile) / arm.replace('_', '-')
        summary = read(arm_dir / 'summary.json'); summary_ref = ref(arm_dir / 'summary.json')
        native = conditions[arm]
        failure_rows = summary.get('trial_failures', [])
        require(type(failure_rows) is list and len(failure_rows) <= MAX_TRIALS, 'Native failure identity limit')
        failure_names = []
        for failure in failure_rows:
            require(type(failure) is dict, 'Invalid failure identity')
            token(failure.get('trial')); failure_names.append(failure['trial'])
        require(len(set(failure_names)) == len(failure_names), 'Duplicate native failure identity')
        validate_custom_error_ledger(summary, native, arm)
        if native.get('execution_status') == 'succeeded':
            require(native_error_count(native) == 0 and not failure_rows and not summary.get('job_failure'), 'Successful custom arm has failures')
        carrier = agent.get('trial_failures', {})
        if arm in carrier: require(carrier[arm] == failure_rows, 'Native failure carrier contradiction')
        for key in ('execution_status', 'expected_attempts', 'scored_attempts'):
            require(summary.get(key) == native.get(key), 'Custom summary contradiction')
        require(native.get('expected_attempts') == len(cases) * capture['attempts'], 'Custom expected population mismatch')
        lookup = {}
        pass_data = summary.get('pass_at_k') or {}
        require(type(pass_data) is dict, 'Invalid custom native pass data')
        release_partial = (capture['evaluator_version'] in static_evaluator.SOURCE_PINS
                           and 'unresolved_cases' in pass_data)
        if release_partial:
            require(native['execution_status'] != 'succeeded'
                    and native['scored_attempts'] < native['expected_attempts']
                    and pass_data.get('attempts_used') == native['scored_attempts'],
                    'Partial custom execution population mismatch')
            if name == 'gh' and capture['purpose'] == 'oracle_qualification':
                require(capture['attempts'] == 1 and native['scored_attempts'] > 0,
                        'Partial oracle execution population mismatch')
            validate_101_partial_rollups(pass_data, pass_data.get('cases', {}), capture['case_ids'],
                                         capture['attempts'], False, versioned=False)
        elif pass_data:
            validate_summary_rollups(pass_data, pass_data.get('cases', {}), capture['case_ids'], capture['attempts'], False)
        if arm in (agent.get('pass_at_k') or {}):
            require(agent['pass_at_k'][arm] == pass_data, 'Custom native pass carrier contradiction')
        for case_id, row in pass_data.get('cases', {}).items():
            require(case_id in capture['case_ids'], 'Unknown summary case')
            for attempt in row.get('attempts', []):
                require(attempt['trial'] not in lookup, 'Duplicate summary trial')
                lookup[attempt['trial']] = (case_id, attempt)
        found = sorted(path for path in files if path.name == 'result.json' and path.parent.parent == arm_dir / 'trials')
        measured_count = 0; explicit_unscored_names = set()
        for path in found:
            trial = read(path); reward_path = path.with_name('reward.json')
            reward = read(reward_path) if reward_path in entries else None
            trial_name = trial.get('trial_name'); token(trial_name)
            require(path.parent.name == trial_name, 'Native trial name mismatch')
            native_id = trial.get('id'); token(native_id)
            from skillevaluator.tier3.harbor.collector import _entry_id_from_harbor_result, _canonical_case_id, _attempt_ordinal
            if profile_family(profile) in ('pester-pilot-v3', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-cli-pilot-v1', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
                case_id = trial.get('task_name')
                require(type(case_id) is str and case_id in capture['case_ids'], 'Missing native task identity')
            else:
                case_id = _canonical_case_id(_entry_id_from_harbor_result(trial), set(capture['case_ids']))
            require(case_id in capture['case_ids'] and trial.get('task_checksum') == tasks[arm, case_id]['task_checksum'],
                    'Native task identity or checksum mismatch')
            actual_agent = (trial.get('agent_info') or {}).get('name')
            version = (trial.get('agent_info') or {}).get('version')
            if version is None: limitations.add('metadata_missing')
            else:
                token(version); agent_versions.add(version)
                require(len(agent_versions) == 1 and (actual_agent != 'codex' or version == (profile['runtime'].get('codex') if capture['purpose'] in ('cli_pilot', 'cli_pilot_probe', 'skill_effectiveness', 'skill_effectiveness_probe') else profile['runtime']['cli'] if 'campaign' in profile and not oracle_purpose(capture['purpose']) else reports.POLICY['codex'])), 'Agent version drift')
            trial_config = trial.get('config') or {}
            expected_agent = 'codex_pilot_agent:PilotCodex' if capture['purpose'] in ('cli_pilot', 'cli_pilot_probe', 'skill_effectiveness', 'skill_effectiveness_probe') else actual_agent
            if 'campaign' in profile:
                expected_agent = profile['campaign']['agent_import']
            elif 'producer_profile' in capture.get('producer', {}):
                from benchmark_native import CODEX_AGENT

                expected_agent = CODEX_AGENT
            configured_agent = trial_config.get('agent', {})
            require(actual_agent == capture['agent'] and expected_agent in (configured_agent.get('name'), configured_agent.get('import_path'))
                    and trial_config.get('timeout_multiplier') == capture['execution_policy']['timeout_multiplier']
                    and trial_config.get('environment', {}).get('import_path') ==
                    (profile['campaign']['environment_import'] if 'campaign' in profile else
                     ('aeb_gh_fixture.backend:TrustedGhEnvironment' if profile_family(profile) == 'gh-native-oracle-v1' else
                     'codex_pilot_environment:PilotEnvironment' if profile_family(profile) in ('pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6') and capture['purpose'] in ('cli_pilot', 'cli_pilot_probe', 'skill_effectiveness', 'skill_effectiveness_probe') else
                     'skillevaluator.tier3.harbor.secure_docker_environment:SkillEvaluatorSecureDockerEnvironment')),
                    'Native producer or runtime identity mismatch')
            matched = lookup.pop(trial_name, None)
            require(matched is None or matched[0] == case_id, 'Summary case mismatch')
            if matched:
                ordinal = matched[1].get('attempt')
            elif capture['evaluator_revision'] == profiles.HISTORICAL_REVISION:
                ordinal = historical_trial_ordinal(trial_name)
            else:
                ordinal = _attempt_ordinal({'_trial_name': trial_name, 'entry_id': case_id})
            if ordinal is None and (capture['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe') or 'campaign' in profile):
                from skillevaluator.tier3.harbor.collector import _structural_attempt_ordinal
                ordinal = _structural_attempt_ordinal(trial_name, case_id)
            if ordinal is None: limitations.add('metadata_missing')
            exception_type = (trial.get('exception_info') or {}).get('exception_type')
            execution_terminated = (profile.get('termination_evidence') == 'native-deadline-v1'
                                    and exception_type in ('AgentTimeoutError', 'CancelledError', 'KeyboardInterrupt'))
            diagnostic_security = None
            diagnostic_reward = reward is not None and execution_terminated
            diagnostic_failure_path = None
            if (reward is not None and not execution_terminated
                    and reward.get('evaluation_status') == 'failed' and 'trial_id' not in reward):
                diagnostic_failure_path = path.with_name('failure.json')
                require(diagnostic_failure_path in entries and trial_name in failure_names,
                        'Unscored diagnostic lacks native failure identity')
                validate_unscored_diagnostic(reward, read(diagnostic_failure_path), trial, case_id, arm,
                    profiles.runtime(capture['producer']) if 'producer' in capture else None,
                    collector_agent=custom_carrier(profile))
                if capture.get('producer', {}).get('patch_sha256') == profiles.NEXT['patch_sha256']:
                    diagnostic_security = copy.deepcopy(reward['details']['security'])
                explicit_unscored_names.add(trial_name)
                diagnostic_reward = True
                reward = None  # Retained only as referenced diagnostic data; never a grade.
            if execution_terminated:
                # Harbor may verify an interrupted/missing file. Such a sidecar
                # is retained as data, never admitted as this attempt's grade.
                explicit_unscored_names.add(trial_name)
                if reward is not None and reward.get('trial_id') != trial_name:
                    limitations.add('metadata_missing')
                reward = None
            if reward is not None:
                require(reward.get('trial_id') == trial_name and reward.get('entry_id') == case_id
                        and ((profile_family(profile) in ('pester-pilot-v3', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-cli-pilot-v1', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6') and 'has_skill' not in reward)
                             or reward.get('has_skill') is (arm == 'with_skill')), 'Reward identity mismatch')
            raw = ((trial.get('verifier_result') or {}).get('rewards') or {})
            if profile['grading'] == 'custom_only':
                require(not (set(raw) & {'security', 'skill_execution', 'skill_efficiency', 'accuracy', 'goal_accuracy', 'behavior_check'}),
                        'Custom-only trial contains standard judge metrics')
            if matched is not None and matched[1].get('score') is not None:
                require(matched[1]['score'] == raw.get('overall'), 'Custom native attempt score mismatch')
            detail = (reward or {}).get('details' if profile_family(profile) in ('pester-pilot-v3', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-cli-pilot-v1', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6', 'gh-native-oracle-v1', 'podman-storage-v1') else 'custom_details', {}).get('outcome', {})
            outcome = detail.get('classification', 'unknown') if profile['grading'] == 'custom_only' else (
                'failed' if native_trial_failed(trial, reward) else 'passed' if (reward or {}).get('custom_metrics', {}).get('gh_gate') == 1 else 'failed')
            if profile['grading'] == 'default_plus_custom' and native_trial_failed(trial, reward): outcome = 'unknown'
            if execution_terminated:
                outcome = CUSTOM_NATIVE_EXCEPTIONS[exception_type]
            if outcome not in CUSTOM_MEASURED:
                outcome = CUSTOM_NATIVE_EXCEPTIONS.get(exception_type, outcome)
                if 'campaign' in profile:
                    from evaluation_evidence import native_outcome
                    outcome = native_outcome(profile, trial, outcome)
            enum(outcome, CUSTOM_OUTCOMES)
            measured = outcome in CUSTOM_MEASURED
            if measured:
                require(reward is not None and reward.get('evaluation_status', 'complete') == 'complete'
                        and trial.get('exception_info') is None and trial.get('finished_at') is not None
                        and (trial.get('verifier') or {}).get('finished_at') is not None, 'Incomplete custom trial')
                try:
                    start = datetime.fromisoformat(trial['started_at'])
                    finish = datetime.fromisoformat(trial['finished_at'])
                    verified = datetime.fromisoformat(trial['verifier']['finished_at'])
                    require(start.tzinfo is not None and finish.tzinfo is not None and verified.tzinfo is not None
                            and start <= verified <= finish, 'Invalid native completion interval')
                except (KeyError, TypeError, ValueError):
                    raise ValueError('Invalid native completion interval') from None
                measured_count += 1
                original_rewards[arm].append(raw)
                if profile['grading'] == 'custom_only':
                    require(detail.get('code') == 'evaluated' and raw.get('overall') == float(outcome == 'passed')
                            and reward.get('overall') == raw.get('overall'), 'Custom reward/classification mismatch')
                    if 'pester_reference_pass' in (reward.get('custom_metrics') or {}):
                        require(detail.get('pester_version') == profile['runtime']['pester']
                                and detail.get('powershell_version') == profile['runtime']['powershell']
                                and type(detail.get('tests_executed')) is int and detail['tests_executed'] > 0,
                                'Measured runtime mismatch')
            else:
                limitations.add('execution_incomplete')
                if reward is not None:
                    explicit_unscored_names.add(trial_name)
                    require(reward.get('evaluation_status') in ('failed', 'error') and not reward.get('custom_metrics')
                            and not (set(raw) & set(definitions)),
                            'Unscoreable trial acquired measurements')
            values = (reward or {}).get('custom_metrics', {})
            values = restore_captured_numeric_fields(values, numeric_excerpts, arm, native_id, case_id)
            raw_values = {key: raw.get(key, (raw.get('custom_metrics') or {}).get(key)) for key in values}
            raw_values = restore_captured_numeric_fields(raw_values, numeric_excerpts, arm, native_id, case_id)
            require(type(values) is dict, 'Invalid custom metric carrier')
            for key, value in values.items():
                require(key in definitions and raw_values[key] == value,
                        'Native custom value contradiction')
            obs_refs = [ref(path), summary_ref, capture_ref]
            if reward is not None or diagnostic_reward: obs_refs.append(ref(reward_path))
            if diagnostic_failure_path is not None: obs_refs.append(ref(diagnostic_failure_path))
            if diagnostic_security is not None: obs_refs.append(ref(reward_path, ('details', 'security')))
            observation = copy.deepcopy(old.get((arm, trial_name))) if standard else {
                'id': observation_id(run.name, arm, case_id, native_id, trial_name, ordinal),
                'arm': arm, 'case_id': case_id, 'attempt': ordinal, 'native_id': native_id,
                'native_trial': trial_name, 'native_task': trial['task_name'], 'score': None,
                'scores': dict.fromkeys(SCORE_FIELDS), 'rubric_pass': None, 'deterministic_gate': None,
                'deterministic_scores': dict.fromkeys(GATE_FIELDS), 'references': obs_refs}
            require(observation is not None, 'Missing standard observation')
            if diagnostic_security is not None:
                observation['security_evidence'] = diagnostic_security
            if not standard and profiles.candidate_revision(capture['evaluator_revision']):
                observation['raw_scores'] = (dict.fromkeys(SCORE_FIELDS) if diagnostic_security is not None
                                             else {key: raw.get(key) for key in SCORE_FIELDS})
                observation['raw_deterministic_scores'] = dict.fromkeys(GATE_FIELDS)
            observation['custom'] = {'outcome': outcome, 'measurements': custom_measurements(definitions,
                profile['cases'][mapping[case_id]], outcome, {} if execution_terminated else values, detail, obs_refs),
                'usage': custom_usage(trial, redacted_counts=profiles.candidate_revision(capture['evaluator_revision'])), 'references': obs_refs}
            if profile_family(profile) in ('pester-cli-pilot-v1', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
                observation['custom']['admission_reason'] = None if execution_terminated else detail.get('code')
            if profile_family(profile) in ('pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
                from codex_pilot_effectiveness import case_files
                names = sorted(Path(member).stem for member in custom_defect_files(profile, workspace, mapping[case_id]) if member.startswith('mutants/'))
                detections = detail.get('variant_detections')
                measured_reference = outcome in CUSTOM_MEASURED and detail.get('reference_pass') == 1
                if outcome in CUSTOM_MEASURED:
                    require(type(detections) is list and len(detections) == len(names)
                            and all(type(v) is int and v in (0, 1) for v in detections)
                            and sum(detections) == detail['mutants_detected'], 'Contradictory per-defect evidence')
                observation['custom']['defects'] = [{'id': name, 'detected': bool(detections[i]) if measured_reference else None}
                                                    for i, name in enumerate(names)]
                if profile_family(profile) in ('pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
                    kinds = detail.get('variant_failure_kinds')
                    if outcome in CUSTOM_MEASURED:
                        require(type(kinds) is list and len(kinds) == len(names), 'Failure-basis population')
                    for i, row in enumerate(observation['custom']['defects']):
                        row['basis'] = kinds[i] if measured_reference else None
            observations.append(observation)
        require(not lookup or len(found) < summary.get('num_trials', 0), 'Unmatched summary trial')
        # At 0.3.0 num_trials counts scoreable reward rows, not all retained
        # trials. Unscoreable trials are independently named by trial_failures.
        native_count = summary.get('num_trials'); count(native_count)
        native_scored = native.get('scored_attempts'); count(native_scored)
        recorded_count = native_count + len(failure_names)
        require(native_count == native_scored and len(found) <= recorded_count <= native['expected_attempts']
                and measured_count <= native_scored <= recorded_count,
                'Native custom aggregation/coverage mismatch')
        require(explicit_unscored_names <= set(failure_names), 'Unscoreable trial lacks native failure identity')
        if agent.get('num_trials_with' if arm == 'with_skill' else 'num_trials_without') is not None:
            require(agent['num_trials_with' if arm == 'with_skill' else 'num_trials_without'] == native_count, 'Native trial counter contradiction')
        details_complete = len(found) == recorded_count and measured_count == native_scored
        if not details_complete: limitations.add('case_details_missing')
        if measured_count != native['expected_attempts'] or len(found) != native['expected_attempts']:
            limitations.add('coverage_missing')
        if native['execution_status'] != 'succeeded': limitations.add('execution_incomplete')
        if not standard:
            competing = ([source('github-actions-hardening', 'upstream', 'github/awesome-copilot',
                policy['fields']['competing_revision'], 'skills/github-actions-hardening')] if profile_family(profile) == 'gh-native-oracle-v1' else [])
            arms.append({'name': arm, 'condition': condition(arm == 'with_skill', 'runtime_recorded', policy['fields']['workspace_mode'], competing,
                instructions=identity([{key: value for key, value in row.items() if key in ('case_id', 'instruction_digest')}
                    for row in custom_staged_inputs(capture['tasks'], capture['purpose'])]),
                build=profile['runtime_digest'], fixture=profile['fixture_digest'],
                execution={'environment': capture['execution_policy']['environment'], 'base_image_mode': 'recorded_staging', 'task_source': 'native_harbor',
                           'authorization_policy': policy['fields']['authorization_policy'],
                           'fixture_boundary': policy['fields']['fixture_boundary'] if profile_family(profile) == 'gh-native-oracle-v1' else 'separate-verifier-v1'}),
                'coverage': {'expected_cases': len(cases), 'expected_attempts': native['expected_attempts'],
                    'recorded_attempts': recorded_count, 'scored_attempts': native_scored,
                    'unscored_attempts': recorded_count - native_scored,
                    'case_details': 'complete' if details_complete else 'partial' if found else 'unavailable'},
                'execution_status': native['execution_status'], 'execution_error_count': native_error_count(native),
                'rubric': {'passed_cases': None, 'total_cases': None, 'threshold': None}})
        # The release may retain measured custom averages on partial arms.
        native_custom = summary.get('custom_scores', {})
        expected_custom = {}
        for key, definition in definitions.items():
            vals = [m['value'] for obs in observations if obs['arm'] == arm for m in obs['custom']['measurements']
                    if m['metric_id'] == definition['id'] and m['status'] == 'measured']
            if vals: expected_custom[key] = round(sum(vals) / len(vals), 4)
        require(type(native_custom) is dict and set(native_custom) <= set(definitions), 'Unknown native aggregate metric')
        for value in native_custom.values(): number(value)
        computed_custom[arm] = expected_custom if native['execution_status'] == 'succeeded' else {}
        if details_complete:
            if profiles.is_candidate(profiles.by_version(capture['evaluator_version'])):
                from skillevaluator.utils.redaction import is_sensitive_key
                # 0.8 omits sensitive names, rather than retaining a redacted marker.
                # Every restored per-trial value was validated against captured native bytes above.
                visible_scores = expected_custom if release_partial else computed_custom[arm]
                expected_visible = {k: v for k, v in visible_scores.items() if not is_sensitive_key(k)}
                require(native_custom == expected_visible, 'Native custom average contradiction')
            else:
                require(native_custom == computed_custom[arm], 'Native custom average contradiction')
            field = 'custom_' + arm
            if field in agent: require(agent[field] == native_custom, 'Native custom arm carrier contradiction')
    if 'custom_lift' in agent and all(arm['coverage']['case_details'] == 'complete' for arm in (arms or data['arms'])):
        from skillevaluator.tier3.harbor.collector import _compute_custom_lift
        paired_complete = all(conditions[arm]['execution_status'] == 'succeeded' for arm in conditions)
        expected_lift = _compute_custom_lift(computed_custom['with_skill'], computed_custom['without_skill'],
            original_rewards['with_skill'], original_rewards['without_skill'], include_overall=profile['grading'] == 'custom_only') if paired_complete else {}
        if profiles.is_candidate(profiles.by_version(capture['evaluator_version'])):
            from skillevaluator.utils.redaction import is_sensitive_key
            expected_lift = {k: v for k, v in expected_lift.items() if not is_sensitive_key(k)}
        require(agent['custom_lift'] == expected_lift, 'Native custom lift contradiction')
    data['custom']['agent_version'] = next(iter(agent_versions)) if agent_versions else None
    if arms: data['arms'] = arms
    for counter in ('expected_attempts', 'scored_attempts'):
        for carrier in (result, agent):
            if counter in carrier:
                require(carrier[counter] == sum(conditions[arm][counter] for arm in conditions), 'Native aggregate population mismatch')
    data['observations'] = sorted(observations, key=lambda obs: (obs['arm'], obs['case_id'], obs['attempt'] or 0, obs['id']))
    if result.get('report_status') != 'complete' or result.get('diagnostic_only'): limitations.add('execution_incomplete')
    data['availability'] = {'status': 'incomplete' if limitations else 'complete',
                            'reasons': sorted(limitations), 'provenance': 'runtime_recorded'}
    data['references'] = sorted(refs, key=lambda row: row['id'])
    if 'producer_profile' in data['policy'] and not standard:
        for obs in data['observations']:
            obs.setdefault('raw_scores', dict.fromkeys(SCORE_FIELDS))
            obs.setdefault('raw_deterministic_scores', dict.fromkeys(GATE_FIELDS))
    if 'producer_profile' in data['policy'] and standard:
        for obs in data['observations']:
            if obs['raw_deterministic_scores']['evidence'] == 0:
                obs['custom']['outcome'] = 'unknown'
                for m in obs['custom']['measurements']:
                    if m['applicability'] == 'applicable':
                        m.update(status='unavailable', value=None, numerator=None, denominator=None, reason='unknown')
                data['availability']['status'] = 'incomplete'
                data['availability']['reasons'] = sorted(set(data['availability']['reasons']) | {'execution_incomplete'})
    guard = input_guard(directories, states, members, budget); guard()
    validate_evidence(data)
    return _BehavioralEvidence(data, behavioral_claim_identity(data), input_guards=(guard, *record_guards(standard or {})))


def custom_usage(trial, *, redacted_counts=False):
    context = trial.get('agent_result') or {}
    result = {key: context.get(key) for key in ('n_input_tokens', 'n_cache_tokens', 'n_output_tokens')}
    # The frozen 0.8.0 collector redacts these keys even when their value is null.
    # A removed count is unavailable; it cannot be reconstructed as zero.
    if redacted_counts:
        result = {key: None if value == '<redacted>' else value for key, value in result.items()}
    for key in ('agent_execution', 'verifier'):
        phase = trial.get(key) or {}
        start, finish = phase.get('started_at'), phase.get('finished_at')
        value = None
        if start is not None and finish is not None:
            try: value = (datetime.fromisoformat(finish) - datetime.fromisoformat(start)).total_seconds()
            except (ValueError, TypeError): raise ValueError('Invalid native timing') from None
        result[key + '_seconds'] = value
    for key, value in result.items():
        if key.startswith('n_'): optional(value, lambda v: count(v, 10**12))
        else: optional(value, lambda v: number(v, 0, 10**12))
    if result['n_input_tokens'] is not None and result['n_cache_tokens'] is not None:
        require(result['n_cache_tokens'] <= result['n_input_tokens'], 'Contradictory cache-token observation')
    return result


def validate_custom_evidence(data, *, public=False, _observed_at=None):
    if type(data) in (_CapturedRecord, _BehavioralEvidence): data = dict(data)
    closed(data, ('schema_version', 'kind', 'source', 'run_id', 'dataset', 'policy', 'arms', 'metrics',
                  'observations', 'scans', 'findings', 'references', 'availability', 'custom'))
    require(type(data['schema_version']) is int and data['schema_version'] == 2 and data['kind'] == 'behavioral', 'Custom evidence version')
    validate_source(data['source']); token(data['run_id'])
    validate_policy(data['policy'], custom_only=data['policy']['fields']['grading'] == 'custom_only')
    profile, definitions, contract = custom_contract(data['source']['skill_id'], profile_id=data['custom']['profile_id'])
    custom = data['custom']
    closed(custom, ('profile_id', 'contract_digest', 'definitions', 'cases', 'purpose', 'agent', 'runtime',
                   'native_metric_set', 'capture_digest', 'capture_reference', 'agent_version', 'grader_digest', 'fixture_digest', 'runtime_digest', 'assurance') + (('retrospective',) if replay_purpose(custom.get('purpose')) else ()) +
        (('scheduler',) if 'scheduler' in custom else ()))
    require(bool(profile.get('campaign', {}).get('scheduler')) == ('scheduler' in custom), 'Scheduler evidence policy mismatch')
    if 'scheduler' in custom:
        import campaign_scheduler_evidence as scheduler_evidence
        from evaluation_evidence import task as campaign_task
        value = custom['scheduler']; closed(value, ('reference', 'witness'))
        require(any(r['id'] == value['reference'] and r['member'] == scheduler_evidence.MEMBER for r in data['references']),
                'Missing scheduler witness reference')
        require(value['witness']['mode'] == profile['campaign']['mode'], 'Scheduler/profile origin mismatch')
        scheduler_evidence.validate(value['witness'], campaign_task(profile), observations=data['observations'])
    require(custom['profile_id'] == profile['id'] and custom['contract_digest'] == contract
            and custom['definitions'] == [{'native_name': key, **definition} for key, definition in sorted(definitions.items())]
            and custom['runtime'] == profile['runtime']
            and custom['assurance'] == CUSTOM_ASSURANCE, 'Unapproved custom definition or assurance')
    validate_custom_purpose(custom['purpose']); token(custom['agent'])
    pilot_profile = 'campaign' not in profile and profile_family(profile) in ('pester-cli-pilot-v1', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6')
    require(pilot_profile == (custom['purpose'] in ('cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control')), 'Pilot profile/purpose mismatch')
    require('campaign' in profile or (profile_family(profile) in ('pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6')) == (custom['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control')),
            'Effectiveness profile/purpose mismatch')
    if 'campaign' in profile:
        from evaluation_evidence import validate_policy as validate_campaign_policy
        from evaluation_runtime import evaluator, read_profile
        from evaluation_evidence import task as campaign_task
        producer = evaluator(read_profile(ROOT / campaign_task(profile).definition['runtime_profile']))
        require(custom['purpose'] == profile['id'] and data['policy'].get('producer_profile') == producer['id'], 'Campaign purpose/profile mismatch')
        validate_campaign_policy(profile, data['policy']['fields'], data['policy']['attempts']['maximum'], custom['agent_version'])
    if pilot_profile:
        live = custom['purpose'] in ('cli_pilot', 'cli_pilot_probe', 'skill_effectiveness', 'skill_effectiveness_probe')
        fields = data['policy']['fields']
        require(data['policy'].get('producer_profile') == profiles.CANDIDATE['id']
                and data['policy']['attempts']['maximum'] == (3 if custom['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe') else 1)
                and fields['environment'] == 'docker' and fields['concurrency'] == (1 if custom['purpose'] in ('skill_effectiveness', 'skill_effectiveness_probe') else 2) and fields['timeout_multiplier'] == 1.0
                and fields['model'] == (profile['runtime']['model'] if live else 'credential-free-oracle')
                and fields['provider'] == ('openai' if live else 'fixture')
                and (not live or custom['agent_version'] in (None, profile['runtime']['codex'])), 'Pilot public runtime mismatch')
    if campaign_purpose(custom['purpose']) and replay_purpose(custom['purpose']):
        validate_replay_metadata(custom['retrospective'],profile,custom['purpose'])
    if custom['purpose'] == 'cli_pilot_replay':
        from codex_pilot_replay import validate_retrospective
        require(profile_family(profile) in ('pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'), 'Unversioned retrospective profile')
        validate_retrospective(custom['retrospective'])
    optional(custom['agent_version'], token)
    optional(custom['native_metric_set'], lambda v: enum(v, ('custom-only', 'skill-evaluator-default-v2')))
    if profile['grading'] == 'custom_only': require(data['policy']['metric_set'] == 'custom-only', 'Incorrect custom scoring policy')
    require(custom['agent'] == custom_agent(profile, custom['purpose']), 'Custom agent mismatch')
    if profile_family(profile) == 'gh-native-oracle-v1' and 'campaign' not in profile:
        require(custom['purpose'] == 'oracle_qualification' and custom['agent'] == 'oracle'
                and data['policy'].get('producer_profile') in {p['id'] for p in profiles.CANDIDATES}
                and data['policy']['fields']['environment'] == 'aeb-gh-fixture', 'Native gh oracle profile mismatch')
        gh_policy = reports.benchmark_policy('gh')
        require(all(data['policy']['fields'][key] == gh_policy[key] for key in ('workspace_mode', 'upstream_revision',
                'competing_revision', 'authorization_policy', 'fixture_boundary', 'task_build')), 'Native gh staging policy mismatch')
    require(data['policy']['fields']['grading'] == profile['grading'], 'Custom grading policy mismatch')
    sha(custom['capture_digest']); sha(custom['capture_reference'])
    for key in ('grader_digest', 'fixture_digest', 'runtime_digest'):
        require(custom[key] == profile[key], 'Unknown custom measurement identity')
    dataset = data['dataset']
    closed(dataset, ('owner', 'authored_digest', 'staged_digest', 'staged_algorithm', 'authored_provenance',
                     'staged_provenance', 'case_cohort_digest', 'case_ids'))
    require(dataset['owner'] == 'overlay' and dataset['authored_digest'] == profile['dataset_digest'], 'Custom dataset must retain approved overlay identity')
    ids = case_ids(dataset['case_ids'])
    require(dataset['case_cohort_digest'] == identity(sorted(ids)), 'Custom cohort mismatch')
    for key in ('authored_digest', 'staged_digest'): optional(dataset[key], sha)
    for key in ('authored_provenance', 'staged_provenance'): enum(dataset[key], PROVENANCE)
    enum(dataset['staged_algorithm'], ('sha256-staged-task-inputs-v1', 'skill-evaluator-dataset-snapshot/1'))
    mapping = custom_case_mapping(profile, custom['purpose'])
    require(set(ids) == set(mapping) and bool(ids), 'Unapproved public custom cohort')
    require(type(custom['cases']) is list and len(custom['cases']) == len(ids), 'Custom case population limit')
    expected_cases = [{'case_id': case, 'source_case_id': mapping[case], **profile['cases'][mapping[case]]} for case in ids]
    require(custom['cases'] == expected_cases, 'Forged custom applicability')
    availability = data['availability']; closed(availability, ('status', 'reasons', 'provenance'))
    enum(availability['status'], ('complete', 'incomplete', 'unavailable')); enum(availability['provenance'], PROVENANCE)
    require(type(availability['reasons']) is list and availability['reasons'] == sorted(set(availability['reasons']))
            and set(availability['reasons']) <= set(REASONS), 'Custom availability reasons')
    require((availability['status'] == 'complete') == (not availability['reasons']), 'Custom availability contradiction')
    require(type(data['references']) is list and len(data['references']) <= MAX_REFERENCES, 'Custom reference limit')
    refs = {}
    for record in data['references']:
        validate_reference(record); require(record['id'] not in refs, 'Duplicate custom reference'); refs[record['id']] = record
        if record['availability'] != 'available':
            require(availability['status'] == 'incomplete' and ('reference_expired' if record['availability'] == 'expired'
                    else 'reference_unavailable') in availability['reasons'], 'Missing original-support limitation')
    require(custom['capture_reference'] in refs and refs[custom['capture_reference']]['member'] == CUSTOM_CAPTURE
            and refs[custom['capture_reference']]['digest'] == custom['capture_digest'], 'Missing admission reference')
    require(not data['scans'] and not data['findings'], 'Custom report implies static evidence')
    if profile['grading'] == 'default_plus_custom':
        old = copy.deepcopy(data); old['schema_version'] = 1; old.pop('custom')
        for obs in old['observations']: obs.pop('custom')
        validate_evidence(old, public=public, _observed_at=_observed_at)
    else:
        require(not data['metrics'] and data['policy']['judge']['enabled'] is False, 'Invented custom-only judge metrics')
    require(type(data['observations']) is list and len(data['observations']) <= MAX_TRIALS, 'Custom observation limit')
    seen = set(); native_seen = set(); observation_ids = set()
    for obs in data['observations']:
        closed(obs, OBSERVATION_FIELDS + security_observation_fields(obs, data, data['references']) + ('custom',) + (('raw_scores', 'raw_deterministic_scores') if 'producer_profile' in data['policy'] else ()) + (() if public else ('native_id', 'native_trial', 'native_task')))
        if 'producer_profile' in data['policy']:
            closed(obs['raw_scores'], SCORE_FIELDS); closed(obs['raw_deterministic_scores'], GATE_FIELDS)
            for val in (*obs['raw_scores'].values(), *obs['raw_deterministic_scores'].values()): optional(val, number)
        sha(obs['id']); enum(obs['arm'], ('with_skill', 'without_skill'))
        require(obs['case_id'] in ids and obs['id'] not in observation_ids, 'Custom observation identity')
        observation_ids.add(obs['id'])
        optional(obs['attempt'], lambda v: count(v, 100))
        require(obs['attempt'] is None or obs['attempt'] > 0, 'Invalid custom ordinal')
        if obs['attempt'] is None: require('metadata_missing' in availability['reasons'], 'Unknown attempt limitation missing')
        key = obs['arm'], obs['case_id'], obs['attempt'] if obs['attempt'] is not None else obs['id']
        require(key not in seen, 'Duplicate custom attempt'); seen.add(key)
        require(type(obs['references']) is list and 0 < len(obs['references']) <= 10 and set(obs['references']) <= refs.keys(), 'Dangling custom support')
        if not public:
            for key in ('native_id', 'native_trial'): token(obs[key])
            relative(obs['native_task'])
            require((obs['arm'], obs['native_id']) not in native_seen, 'Duplicate native custom ID')
            native_seen.add((obs['arm'], obs['native_id']))
            require(obs['id'] == observation_id(data['run_id'], obs['arm'], obs['case_id'], obs['native_id'], obs['native_trial'], obs['attempt']), 'Custom observation digest mismatch')
            prefix = f"results/{data['source']['skill_id']}/{data['run_id']}/{custom_carrier(profile)}/{obs['arm'].replace('_', '-')}/trials/{obs['native_trial']}/"
            require(any(refs[r]['member'] == prefix + 'result.json' for r in obs['references']), 'Custom native reference origin')
        if profile['grading'] == 'custom_only':
            require(obs['score'] is None and obs['rubric_pass'] is None and obs['deterministic_gate'] is None,
                    'Custom-only result implies default or gh outcomes')
            closed(obs['scores'], SCORE_FIELDS); closed(obs['deterministic_scores'], GATE_FIELDS)
            require(all(v is None for v in (*obs['scores'].values(), *obs['deterministic_scores'].values())), 'Fabricated standard scores')
        prefix = f"results/{data['source']['skill_id']}/{data['run_id']}/{custom_carrier(profile)}/{obs['arm'].replace('_', '-')}/trials/"
        require(any(refs[r]['member'].startswith(prefix) and refs[r]['member'].endswith('/result.json')
                    for r in obs['references']), 'Public custom trial reference origin')
        detail = obs['custom']; closed(detail, ('outcome', 'measurements', 'usage', 'references') + (('defects',) if profile_family(profile) in ('pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6') else ()) + (('admission_reason',) if profile_family(profile) in ('pester-cli-pilot-v1', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6') else ()))
        if profile_family(profile) in ('pester-cli-pilot-v1', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
            reasons = (
                'artifact', 'admission', 'ast_kind', 'variable_policy', 'hashtable_policy', 'expression_policy',
                'command_policy', 'command_parameter', 'module_policy', 'test_name_template', 'evaluated',
                'parse', 'ok', 'runner', 'runtime', 'case_budget', 'classification', 'deadline', 'entry',
                'incomplete', 'nonexecuting', 'output_budget', 'process_budget', 'protocol', 'verifier',
                'worker_permission', 'worker_coreclr', 'worker_memory', 'worker_dependency', 'worker_unclassified',
                'isolation_environment', 'isolation_network', 'isolation_seccomp', 'isolation_resources', 'isolation_mount')
            if profile_family(profile) in ('pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'): reasons += ('unary_policy',)
            if profile_family(profile) in ('pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'): reasons += ('test_failure_kind',)
            optional(detail['admission_reason'], lambda v: enum(v, reasons))
        enum(detail['outcome'], CUSTOM_OUTCOMES)
        require(type(detail['references']) is list and 0 < len(detail['references']) <= 10
                and set(detail['references']) <= refs.keys(), 'Dangling outcome reference')
        if profile_family(profile) in ('pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
            from codex_pilot_effectiveness import case_files
            names = sorted(Path(member).stem for member in custom_defect_files(profile, ROOT, mapping[obs['case_id']]) if member.startswith('mutants/'))
            defects = detail['defects']
            require(type(defects) is list and len(defects) == len(names), 'Defect evidence population')
            for row, name in zip(defects, names):
                closed(row, ('id', 'detected') + (('basis',) if profile_family(profile) in ('pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6') else ()))
                require(row['id'] == name and (row['detected'] is None or type(row['detected']) is bool), 'Defect evidence identity')
            measures = {m['metric_id']: m for m in detail['measurements']}
            reference = measures['powershell-pester-6.reference-pass.v1']
            mutation = measures[definitions['pester_mutation_detection']['id']]
            reference_pass = reference['status'] == 'measured' and reference['value'] == 1
            require(all((row['detected'] is not None) == reference_pass for row in defects), 'Unavailable defect evidence measured')
            if profile_family(profile) in ('pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6'):
                for row in defects:
                    require(row['basis'] in ('assertion', 'mock_parameter_mismatch', None)
                            and ((row['basis'] is not None) == (row['detected'] is True)), 'Contradictory defect failure basis')
            if mutation['status'] == 'measured':
                require(sum(row['detected'] is True for row in defects) == mutation['numerator'], 'Defect total mismatch')
        measurements = detail['measurements']
        require(type(measurements) is list and len(measurements) == len(definitions), 'Custom measurement population')
        by_id = {}; case = profile['cases'][mapping[obs['case_id']]]
        for row in measurements:
            closed(row, ('metric_id', 'applicability', 'status', 'value', 'numerator', 'denominator', 'reason', 'references'))
            require(row['metric_id'] not in by_id, 'Duplicate metric measurement'); by_id[row['metric_id']] = row
            require(type(row['references']) is list and 0 < len(row['references']) <= 10 and set(row['references']) <= refs.keys(), 'Dangling metric reference')
        require(set(by_id) == {d['id'] for d in definitions.values()}, 'Unknown metric namespace')
        for native, definition in definitions.items():
            row = by_id[definition['id']]; applies = native in case['metrics']
            require(row['applicability'] == ('applicable' if applies else 'not_applicable'), 'Incorrect metric applicability')
            measured = applies and detail['outcome'] in CUSTOM_MEASURED
            require(row['status'] == ('measured' if measured else 'unavailable'), 'Unsupported trial acquired metric')
            if not measured:
                require(all(row[k] is None for k in ('value', 'numerator', 'denominator'))
                        and row['reason'] == ('not_applicable' if not applies else detail['outcome']), 'Unavailable measurement became zero')
            else:
                count(row['numerator']); count(row['denominator']); number(row['value'])
                expected_denominator = case['denominators'][native] if definition['basis'] == 'ratio' else 1
                require(row['denominator'] == expected_denominator > 0 and row['numerator'] <= row['denominator']
                        and row['value'] == row['numerator'] / row['denominator'] and row['reason'] is None, 'Custom arithmetic mismatch')
        if detail['outcome'] in CUSTOM_MEASURED:
            vals = {native: by_id[d['id']]['value'] for native, d in definitions.items() if native in case['metrics']}
            if 'pester_test_quality' in vals:
                require(vals['pester_test_quality'] == float(vals['pester_reference_pass'] == 1 and vals['pester_mutation_detection'] == 1)
                        and detail['outcome'] == ('passed' if vals['pester_test_quality'] else 'failed'), 'Pester public joint contradiction')
            if 'negative_control_correct' in vals:
                require(detail['outcome'] == ('passed' if vals['negative_control_correct'] else 'failed'), 'Control public contradiction')
            if 'gh_gate' in vals:
                require(vals['gh_gate'] == float(all(v == 1 for k, v in vals.items() if k != 'gh_gate')), 'Custom gh gate drift')
                if profile['grading'] == 'custom_only':
                    require(detail['outcome'] == ('passed' if vals['gh_gate'] else 'failed'), 'Custom gh outcome drift')
                else:
                    require(vals['gh_gate'] == obs['deterministic_gate']
                            and all(vals['gh_' + key] == obs['deterministic_scores'][key] for key in GATE_FIELDS), 'Custom gh gate drift')
        closed(detail['usage'], ('n_input_tokens', 'n_cache_tokens', 'n_output_tokens', 'agent_execution_seconds', 'verifier_seconds'))
        for key, value in detail['usage'].items():
            if key.startswith('n_'): optional(value, lambda v: count(v, 10**12))
            else: optional(value, lambda v: number(v, 0, 10**12))
        if detail['usage']['n_input_tokens'] is not None and detail['usage']['n_cache_tokens'] is not None:
            require(detail['usage']['n_cache_tokens'] <= detail['usage']['n_input_tokens'], 'Contradictory public cache tokens')
    require(type(data['arms']) is list and sorted(row['name'] for row in data['arms']) == ['with_skill', 'without_skill'], 'Custom paired arms')
    maximum = data['policy']['attempts']['maximum']; require(maximum is not None, 'Unknown planned custom denominator')
    for arm in data['arms']:
        closed(arm, ('name', 'condition', 'coverage', 'execution_status', 'execution_error_count', 'rubric'))
        validate_condition(arm['condition']); require(arm['condition']['target_present'] is (arm['name'] == 'with_skill'), 'Custom target arm mismatch')
        enum(arm['execution_status'], ('succeeded', 'failed', 'incomplete', 'unknown')); count(arm['execution_error_count'])
        coverage = arm['coverage']; closed(coverage, ('expected_cases', 'expected_attempts', 'recorded_attempts', 'scored_attempts', 'unscored_attempts', 'case_details'))
        rows = [obs for obs in data['observations'] if obs['arm'] == arm['name']]
        measured = sum(obs['custom']['outcome'] in CUSTOM_MEASURED for obs in rows)
        if 'producer_profile' in data['policy'] and profile['grading'] == 'default_plus_custom':
            measured = sum(obs['score'] is not None for obs in rows)
        require(coverage['expected_cases'] == len(ids) and coverage['expected_attempts'] == len(ids) * maximum
                and len(rows) <= coverage['recorded_attempts'] <= coverage['expected_attempts']
                and measured <= coverage['scored_attempts'] <= coverage['recorded_attempts']
                and coverage['unscored_attempts'] == coverage['recorded_attempts'] - coverage['scored_attempts'], 'Custom coverage contradiction')
        enum(coverage['case_details'], ('complete', 'partial', 'unavailable'))
        if coverage['case_details'] == 'complete':
            require(len(rows) == coverage['recorded_attempts'] and measured == coverage['scored_attempts'], 'Incomplete custom details')
        else: require('case_details_missing' in availability['reasons'], 'Missing detail limitation')
        require(len(rows) <= coverage['expected_attempts'] and all(obs['attempt'] is None or obs['attempt'] <= maximum for obs in rows), 'Excess custom attempts')
        if measured != coverage['expected_attempts'] or len(rows) != coverage['expected_attempts']:
            require('coverage_missing' in availability['reasons'], 'Partial custom coverage hidden')
        if arm['execution_status'] != 'succeeded' or any(obs['custom']['outcome'] not in CUSTOM_MEASURED for obs in rows):
            require('execution_incomplete' in availability['reasons'], 'Unscoreable outcome hidden')
        if availability['status'] == 'complete':
            require(arm['execution_status'] == 'succeeded' and arm['execution_error_count'] == 0
                    and coverage['case_details'] == 'complete' and measured == coverage['expected_attempts']
                    and all(obs['attempt'] is not None for obs in rows), 'Incomplete custom promotion')
    depth(data, 16 if public else 32)
    if public: require(len(encoded(data)) <= PUBLIC_LIMIT, 'Public custom report size exceeded')
    return data


def normalize_behavioral(root, name, selected=None, workspace=ROOT, *, native_layout=False):
    # Presence does not confer approval: the native admission reader validates
    # capture content, approved definitions and every retained native carrier.
    if (Path(root) / CUSTOM_CAPTURE).exists() or (Path(root) / CUSTOM_CAPTURE).is_symlink():
        return normalize_custom_behavioral(root, name, selected, workspace, native_layout=native_layout)
    return _normalize_behavioral_v1(root, name, selected, workspace, native_layout=native_layout)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    inv = commands.add_parser('inventory'); inv.add_argument('--output', type=Path)
    norm = commands.add_parser('normalize'); norm.add_argument('--kind', required=True, choices=('behavioral', 'static'))
    norm.add_argument('--skill', required=True); norm.add_argument('--input', required=True, type=Path)
    norm.add_argument('--run'); norm.add_argument('--output', type=Path)
    norm.add_argument('--native-layout', action='store_true')
    proj = commands.add_parser('project'); proj.add_argument('--input', required=True, type=Path); proj.add_argument('--output', type=Path)
    args = parser.parse_args(argv)
    input_path = getattr(args, 'input', None)
    if args.command == 'inventory':
        values = {'inventory.json': inventory()}
    elif args.command == 'project':
        directories = {}; states = {}; members = {}
        data = parse_json(read_bytes(args.input, directory_identities=directories, directory_states=states, file_states=members))
        require(type(data) is dict, 'Evidence object required')
        data = _CapturedRecord(data, (input_guard(directories, states, members),))
        values = {'public-report.json': project(data, static_bundle=args.input.parent, behavioral_bundle=args.input.parent)}
        if data['kind'] == 'static' or behavioral_claims_need_witness(data):
            input_path = args.input.parent
    else:
        require(args.kind == 'behavioral' or args.run is None, '--run applies to behavioral evidence')
        require(args.kind == 'behavioral' or not args.native_layout, '--native-layout applies to behavioral evidence')
        if args.kind == 'behavioral':
            options = {'native_layout': True} if args.native_layout else {}
            data = normalize_behavioral(args.input.absolute(), args.skill, args.run, **options)
        else:
            data = normalize_static(args.input.absolute(), args.skill)
        values = {'evidence.json': data, 'public-report.json': project(data)}
    output = write_outputs(values, args.output, input_path=input_path)
    print(output)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, TypeError, AttributeError, IndexError, OSError, OverflowError) as exc:
        # Native exception strings can contain prose or paths. Keep CLI errors bounded.
        error_name = 'ValueError' if isinstance(exc, EvidenceBoundaryError) else type(exc).__name__
        print('Evidence contract rejected (' + error_name + ')', file=sys.stderr)
        sys.exit(1)
