"""Run the production Docker benchmark against an offline loopback provider."""
import argparse
import asyncio
import base64
import json
import idna
import os
from pathlib import Path
import shlex
import shutil
import time
import subprocess

from aeb_gh_fixture.benchmark_codex import BenchmarkCodex
from skillevaluator.tier3.harbor.adapter import stage_native_harbor_tasks
from skillevaluator.tier3.harbor.collector import collect_harbor_results
from skillevaluator.tier3.harbor.report import display_findings_report
from skillevaluator.tier3.harbor.runner import build_harbor_run_command

from benchmark_codex_fixture import TOOL_ROUTE
import gh_evaluations as gh
from skill_reports import POLICY, read_json, require, write_json

CASE = "gh-001"
PROFILE = gh.ROOT / ".github/evals/codex-execution-1710.json"
ENDPOINT = "http://127.0.0.1:8765/v1"
SENTINEL = "pilot-not-a-credential"
CODEX_VENDOR = "/opt/reviewed/node_modules/@openai/codex-linux-x64/vendor/x86_64-unknown-linux-musl/"
TRIAL_EXCEPTIONS = frozenset({
    "AgentSetupTimeoutError", "AgentTimeoutError", "CalledProcessError", "EnvironmentStartTimeoutError",
    "NonZeroAgentExitCodeError", "PermissionError", "RewardFileNotFoundError", "RuntimeError", "TimeoutError",
    "ValueError", "VerifierTimeoutError",
})
VERIFIER_EXCEPTIONS = frozenset({
    "AttributeError", "FileNotFoundError", "ImportError", "JSONDecodeError", "KeyError", "ModuleNotFoundError",
    "PermissionError", "TypeError", "UnicodeDecodeError", "ValueError",
})
VERIFIER_MEMBERS = {
    "entry": "/tests/entry.json",
    "trajectory": "/logs/agent/trajectory.json",
    "grader": "/tests/grader.py",
    "test_script": "/tests/test.sh",
    "reward": "/logs/verifier/reward.json",
}


# Run as the trial user. The host may not receive logs until the trial exits.
INTERRUPT_NOT_READY = 75
INTERRUPT_AGENT = r"""
import json
import os
from pathlib import Path
import signal

try:
    with Path("/logs/agent/codex.txt").open("rb") as trace:
        lines = trace.read(2 * 1024 * 1024).split(b"\n")[:-1]
except FileNotFoundError:
    raise SystemExit(75)
for line in lines:
    if not line.startswith(b"{"):
        continue
    event = json.loads(line)
    if event.get("type") == "item.started" and event.get("item", {}).get("type") == "command_execution":
        break
else:
    raise SystemExit(75)

matches = []
for proc in Path("/proc").glob("[0-9]*"):
    try:
        argv = (proc / "cmdline").read_bytes().split(b"\0")
        if len(argv) <= 2 or argv[0].split(b"/")[-1] != b"codex" or argv[1] != b"exec":
            continue
        # /proc directory ownership reflects dumpability, not process identity.
        uid = next(line.split()[1:3] for line in (proc / "status").read_bytes().splitlines()
                   if line.startswith(b"Uid:"))
        if uid != [str(os.getuid()).encode(), str(os.geteuid()).encode()]:
            continue
        matches.append(int(proc.name))
    except (FileNotFoundError, PermissionError, StopIteration):
        continue
if len(matches) != 1:
    raise RuntimeError(f"Expected one trial Codex exec, found {len(matches)}")
os.kill(matches[0], signal.SIGINT)
"""


class OfflineCodex(BenchmarkCodex):
    """Replace Internet installation only. Harbor owns execution and log conversion."""

    identity_stage = "verify_agent_identity_and_broker"
    profile_path = PROFILE

    @staticmethod
    def record_startup(stage):
        fixture = Path(os.environ["BENCHMARK_CODEX_FIXTURE"])
        write_json(fixture.with_name("startup.json"), {"stage": stage})

    async def verify_trial_user(self, environment):
        result = await self.exec_as_agent(environment, "codex --version && id -u && test -S /run/gh-eval/gh.sock && test ! -r /opt/gh-eval/state/case.json")
        require(result.return_code == 0 and result.stdout.splitlines() == ["codex-cli " + self._version, "1000"],
                "Agent identity, CLI or broker isolation drift")

    async def verify_package(self, environment):
        profile = read_json(self.profile_path)
        expected = {"bin/codex": profile["cli_executable_sha256"], **profile["helper_sha256"]}
        require(self._version == profile["cli"], "Generated dispatch version drift")
        # npm omits the standalone archive's optional exec-server. Exercise the
        # installed package exactly as published, including its native launcher.
        del expected["bin/codex-exec-server"]
        vendor = CODEX_VENDOR
        await self.exec_as_root(environment, "test ! -e " + vendor + "bin/codex-exec-server")
        for name, sha in expected.items():
            result = await self.exec_as_root(environment, "sha256sum " + vendor + name)
            require(result.stdout.split()[0] == sha, "Container release bytes differ")

    def fixture_path(self):
        return Path(os.environ["BENCHMARK_CODEX_FIXTURE"])

    async def install(self, environment):
        self.record_startup("verify_package")
        await self.verify_package(environment)
        self.record_startup(self.identity_stage)
        await self.verify_trial_user(environment)
        self.record_startup("verify_network_isolation")
        container = (await environment._run_docker_compose_command(["ps", "--quiet", "main"])).stdout.strip()
        inspected, = json.loads(subprocess.check_output(["docker", "inspect", container]))
        require(inspected["HostConfig"]["NetworkMode"] == "none", "Fixture requires isolated networking")
        receipt = self.logs_dir.parent / "fixture-container.json"
        pending = receipt.with_suffix(".tmp")
        identity = {"id": container}
        if isinstance(self, OfflinePodmanCodex):
            identity["project"] = inspected["Config"]["Labels"]["com.docker.compose.project"]
        write_json(pending, identity)
        pending.replace(receipt)

        self.record_startup("start_loopback_provider")
        # Every byte supplied to the native agent is public fixture data.
        fixture = read_json(self.fixture_path())
        commands = base64.b64encode(json.dumps(fixture["commands"]).encode()).decode()
        argv = ["python3", "/opt/reviewed/stub.py", "/opt/reviewed/request.json", fixture["scenario"],
                "Zml4dHVyZQ==", commands]
        await self.exec_as_root(environment, shlex.join(argv) + " >/opt/reviewed/provider.log 2>&1 </dev/null &")
        ready = "python3 -c " + shlex.quote("import socket; socket.create_connection(('127.0.0.1',8765),1).close()")
        for _ in range(50):
            if (await environment.exec(ready, user="agent")).return_code == 0:
                break
            await asyncio.sleep(.1)
        else:
            raise ValueError("Loopback responder failed to start")
        self._extra_env.update(OPENAI_API_KEY=SENTINEL, OPENAI_BASE_URL=ENDPOINT)
        self.record_startup("ready")


class OfflinePodmanCodex(OfflineCodex):
    identity_stage = "verify_trial_identity"

    async def verify_package(self, environment):
        from benchmark_podman import CODEX_ROOT, codex_members

        profile = read_json(self.profile_path)
        require(self._version == profile["cli"], "Generated dispatch version drift")
        for name, expected in codex_members(profile).items():
            checked = await self.exec_as_root(environment, shlex.join(["sha256sum", f"{CODEX_ROOT}/{name}"]))
            require(checked.return_code == 0 and checked.stdout.split()[0] == expected, "Podman Codex bytes differ")
        # Exercise the released installer's preinstalled branch in the disconnected image.
        await BenchmarkCodex.install(self, environment)

    async def verify_trial_user(self, environment):
        result = await self.exec_as_agent(environment, "codex --version && id -u && test ! -r /tests/entry.json")
        require(result.return_code == 0 and result.stdout.splitlines() == ["codex-cli " + self._version, "1000"],
                "Agent identity, CLI or verifier isolation drift")


def add_offline_assets(image):
    # The operator-owned loopback responder is inside the same network namespace.
    # Harbor must leave this service on loopback instead of joining the egress sidecar.
    with (image / "docker-compose.yaml").open("x", encoding="utf-8") as override:
        override.write("services:\n  main:\n    network_mode: none\n")
    reviewed = image / "reviewed"
    reviewed.mkdir()
    # Keep packaged executables out of the broker's bounded task tree.
    # Install scripts are disabled and every executable is checked in install().
    vendor = CODEX_VENDOR
    launcher = vendor + "bin/codex"
    package = "@openai/codex@" + POLICY["codex"]
    install = ("RUN npm install --prefix /opt/reviewed --no-audit --no-fund --ignore-scripts "
               "--install-strategy=hoisted --registry=https://registry.npmjs.org/ " + package + "\n"
               + "ENV PATH=" + vendor + "codex-path:$PATH\n")
    shutil.copy2(gh.ROOT / ".github/scripts/benchmark_codex_fixture.py", image / "reviewed/stub.py")
    with (image / "Dockerfile").open("a") as build:
        build.write("\nCOPY reviewed /opt/reviewed\n" + install + "RUN chmod -R a+rX /opt/reviewed /workspace/skills"
                    " && ln -s " + launcher + " /usr/local/bin/codex\n")


def stage(root, present):
    import gh_candidate

    bundle = gh_candidate.stage(gh.ROOT, root / "bundle/gh", [CASE], fixture=True)
    task, = stage_native_harbor_tasks(bundle, root / "tasks", with_skill=present, grading_mode="custom_only",
        workspace_mode="group", workspace_skill_paths=[bundle.parent / gh.COMPETING])
    descriptor = task / "task.toml"
    source = descriptor.read_text()
    require('network_mode = "public"' in source, "Unknown source networking")
    descriptor.write_text(source.replace('network_mode = "public"', 'network_mode = "no-network"'))
    image = task / "environment"
    add_offline_assets(image)
    # The production verifier reads real ATIF and the private broker audit. Copy
    # only the loopback request and the produced edit into this local fixture.
    # The standard verifier image carries idna. Custom-only mode omits its
    # judge dependencies, so stage the same locked pure-Python import.
    shutil.copytree(Path(idna.__file__).parent, task / "tests/idna", ignore=shutil.ignore_patterns("__pycache__"))
    verify = task / "tests/test.sh"
    verify.write_text("#!/bin/sh\nset -eu\npython3 -I /tests/grader.py\n")
    with verify.open("a") as script:
        script.write("\ncp /opt/reviewed/request.json /logs/verifier/provider.json\n"
                     "test ! -e /tmp/codex-secrets\ntest -z \"$(find /home/agent -maxdepth 1 -name '.codex-benchmark.*')\"\n"
                     "cp /workspace/output/result.json /logs/verifier/edited.json\n")
    return task


def record_native_failure(root, trial, stage, exception):
    """Retain fixed member names and exception categories from synthetic trials."""
    from skill_evidence import read_bytes

    observed = {
        name: (trial / member).is_file() and not (trial / member).is_symlink()
        for name, member in {
            "codex_events": "agent/codex.txt",
            "atif": "agent/trajectory.json",
            "test_stdout": "verifier/test-stdout.txt",
            "reward": "verifier/reward.json",
            "custom_reward": "verifier/custom_reward.json",
        }.items()
    }
    verifier = None
    if observed["test_stdout"]:
        try:
            # Never copy the verifier log or include exception messages.
            log = read_bytes(trial / "verifier/test-stdout.txt", limit=128 * 1024).decode(errors="replace")
        except (OSError, ValueError):
            verifier = {"category": "unavailable"}
        else:
            for line in reversed(log.splitlines()):
                error, separator, detail = line.partition(":")
                if separator and error in VERIFIER_EXCEPTIONS:
                    verifier = {"category": error, "member": next(
                        (name for name, member in VERIFIER_MEMBERS.items() if repr(member) in detail), None)}
                    break
    write_json(root / "failure.json", {"startup": stage, "harbor_exception": exception,
                                      "observed": observed, "verifier_exception": verifier})


def run(root, present, *, interrupt=False):
    task = stage(root, present)
    fixture = gh.dataset(selected=[CASE])[0]["contract"]
    output = json.dumps(fixture["expected"])
    if present:
        calls = ["cat /workspace/skills/gh/SKILL.md"]
        calls.extend(shlex.join(["gh", *cmd]) for cmd in fixture["good_commands"])
        calls.append("printf '%s\\n' " + shlex.quote(output) + " > output/result.json")
    else:
        # gh-001 permits one literal shell write. A real patch must be
        # observable, and must fail that existing authorization metric.
        calls = [{"tool": "apply_patch", "expect_failure": False, "input":
            "*** Begin Patch\n*** Add File: output/result.json\n+" + output + "\n*** End Patch"}]
    fixture_file = root / "provider.json"
    # Hold the follow-up response even when Codex yields a running shell
    # command to the model before the tool has finished.
    if interrupt:
        calls = ["printf pilot-command-started; sleep 120"]
    write_json(fixture_file, {"scenario": "native-deadline" if interrupt else "benchmark-priced", "commands": calls})
    jobs = root.parent / "jobs"
    job_name = "gh-interrupted" if interrupt else "gh-codex-" + ("with" if present else "without")
    argv = build_harbor_run_command(dataset_path=task.parent, job_name=job_name, jobs_dir=jobs,
        agent="codex", model=POLICY["model"], env_mode="aeb-gh-fixture", n_concurrent=1)
    env = dict(os.environ, PYTHONPATH=str(gh.ROOT / ".github/scripts"), BENCHMARK_CODEX_FIXTURE=str(fixture_file))
    from aeb_gh_fixture.manifest import write_manifest
    manifest = write_manifest(root / "operator", [task], staged_roots=[root / "tasks", root / "bundle"])
    env["AEB_GH_MANIFEST"] = str(manifest)
    require(argv[argv.index("--env") + 1] == "aeb_gh_fixture.backend:TrustedGhEnvironment",
            "Unexpected benchmark environment")
    require("version=" + json.dumps(POLICY["codex"]) in argv and 'reasoning_effort="high"' in argv,
            "Workflow dispatch pin drift")
    index = argv.index("--agent") + 1
    require(argv[index] == BenchmarkCodex.__module__ + ":BenchmarkCodex", "Unexpected benchmark agent")
    argv[index] = "qualify_benchmark_codex:OfflineCodex"
    write_json(root / "startup.json", {"stage": "staged"})
    with subprocess.Popen(argv, env=env) as job:
        try:
            if interrupt:
                deadline = time.monotonic() + 420
                while time.monotonic() < deadline and job.poll() is None:
                    receipt = next((jobs / job_name).glob("*/fixture-container.json"), None)
                    if receipt:
                        container = read_json(receipt)["id"]
                        signal_result = subprocess.run(
                            ["docker", "exec", "--user", "agent", container, "python3", "-c", INTERRUPT_AGENT],
                            capture_output=True, timeout=15,
                        )
                        if signal_result.returncode == 0:
                            break
                        require(signal_result.returncode == INTERRUPT_NOT_READY, "Could not confirm the native signal")
                    time.sleep(.5)
                else:
                    raise ValueError("No started native command to interrupt")
            require(job.wait(timeout=480) == 0 or interrupt, "Harbor job exited unsuccessfully")
        finally:
            if job.poll() is None:
                job.terminate()
                job.wait(timeout=30)
    results = list((jobs / job_name).glob("*/result.json"))
    require(len(results) == 1, "Expected one Harbor trial result")
    result = read_json(results[0])
    if not interrupt and result.get("exception_info") is not None:
        reported = result["exception_info"].get("exception_type")
        exception = reported if isinstance(reported, str) and reported in TRIAL_EXCEPTIONS else "unclassified"
        last_stage = read_json(root / "startup.json")["stage"]
        record_native_failure(root, results[0].parent, last_stage, exception)
        raise ValueError(f"Native Codex trial failed during or after {last_stage}: {exception}")
    trial = results[0].parent
    container = read_json(trial / "fixture-container.json")["id"]
    require(subprocess.run(["docker", "container", "inspect", container], capture_output=True).returncode != 0,
            "Native trial container survived teardown")
    events = [json.loads(line) for line in (trial / "agent/codex.txt").read_text().splitlines() if line.startswith("{")]
    if interrupt:
        require((result.get("exception_info") or {}).get("exception_type") == "NonZeroAgentExitCodeError"
                and any(e["type"] == "item.started" and e["item"]["type"] == "command_execution" for e in events)
                and not any(e["type"] == "turn.completed" for e in events), "Interrupted trial looked complete")
        usage = result.get("agent_result") or {}
        require(all(usage.get(key) is None for key in ("n_input_tokens", "n_cache_tokens", "n_output_tokens", "cost_usd")),
                "Incomplete usage was presented as a final measurement")
        return {"execution": "interrupted", "exception": result["exception_info"]["exception_type"],
                "usage": None, "cleanup": True}
    native_reward = read_json(trial / "verifier/custom_reward.json")
    require("error" not in native_reward, "Native custom verifier failed: " + str(native_reward.get("error")))
    request = read_json(trial / "verifier/provider.json")
    require(request["requests"] == 2 and all(row["model"] == POLICY["model"] and row["reasoning"]["effort"] == "high"
        and row["path"] == "/v1/responses" and row["authorization_matches_sentinel"]
        and row.get("native_tool_route") == TOOL_ROUTE for row in request["request_observations"]),
        "Unexpected provider identity")
    require(read_json(trial / "verifier/edited.json") == fixture["expected"], "Native patch output changed")
    completed = [e["item"]["type"] for e in events if e["type"] == "item.completed"]
    require(("command_execution" if present else "file_change") in completed, "Native action missing")
    require(result["agent_info"]["version"] == POLICY["codex"], "Reported executable version drift")
    metrics = native_reward["custom_metrics"]
    require(metrics["gh_authorization"] == int(present) and metrics["gh_evidence"] == 1,
            "Verifier could not bind these native operations to the private broker audit: " + str(metrics))
    usage = result["agent_result"]
    require([usage.get(key) for key in ("n_input_tokens", "n_cache_tokens", "n_output_tokens")] == [300, 100, 30],
            "Collector usage drift")
    return {"version": result["agent_info"]["version"], "requests": request["requests"], "model": request["model"],
            "reasoning": request["reasoning"]["effort"], "actions": completed, "cleanup": True,
            "input_tokens": usage["n_input_tokens"], "cache_tokens": usage["n_cache_tokens"],
            "output_tokens": usage["n_output_tokens"], "authorization": metrics["gh_authorization"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    root = parser.parse_args().output.resolve()
    require(not any(os.getenv(k) for k in ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "CODEX_AUTH_JSON_PATH",
        "CODEX_FORCE_AUTH_JSON", "CODEX_API_KEY", "SKILL_EVAL_LLM_API_KEY", "NVIDIA_API_KEY")),
        "Real credentials are prohibited")
    from qualify_benchmark_101 import fixture_owner, verifier_requests

    with fixture_owner() as versions:
        qualify(root, verifier_requests, versions)


def qualify(root, verifier_requests, versions):
    root.mkdir()
    rows = [run(root / arm, arm == "with") for arm in ("with", "without")]
    partial = run(root / "interrupted", True, interrupt=True)
    report = root / "report"
    collected = collect_harbor_results("gh", ["codex"], report, root / "jobs", expected_cases=1,
        expected_case_ids=[CASE], expected_trials=1, n_attempts=1, stop_on_pass=False,
        agent_models={"codex": {"model": POLICY["model"], "source": "cli"}},
        env_mode="aeb-gh-fixture", grading_mode="custom_only")
    approved = collected["agents"]["codex"]["custom_with_skill"]
    require(approved.get("gh_task") == 1 and approved.get("gh_gate") == 1, "Approved gh task failed")
    display_findings_report(collected, "gh", ["codex"], report)
    summary = {"inference": False, "agent": rows, "judges": verifier_requests(), "interruption": partial,
               "with_skill_gate": collected["agents"]["codex"]["custom_with_skill"]["gh_gate"]}
    summary["runtime"] = versions
    write_json(root / "qualification.json", summary)
    print(json.dumps(summary, sort_keys=True), flush=True)
    print("Production dispatch, broker, agent, verifier, collector and report passed", flush=True)


if __name__ == "__main__":
    main()
