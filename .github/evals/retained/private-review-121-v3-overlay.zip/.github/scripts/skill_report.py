#!/usr/bin/env python3
"""Render one private offline HTML report from public bundles and saved analysis."""

import argparse
import base64
import hashlib
import html
import json
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import skill_analysis as analysis
import skill_evidence as evidence

HTML_LIMIT = 64 * 1024 * 1024
METHOD = 'private-offline-skill-report/2'
CONTRACT_ERRORS = (ValueError, OSError, TypeError, KeyError, IndexError, OverflowError, RecursionError, UnicodeError)

# Fixed assets only. No evidence is interpolated into CSS, JavaScript or URLs.
CSS = """
:root{color-scheme:light;--bg:#f4f6f8;--surface:#fff;--text:#192b3a;
--muted:#455c6b;--line:#788995;--accent:#005a87;--alert:#963511}
@media(prefers-color-scheme:dark){:root:not([data-theme=light]){color-scheme:dark;
--bg:#111c26;--surface:#192b38;--text:#edf3f7;--muted:#bccbd6;
--line:#8293a0;--accent:#8ad6ff;--alert:#ffb591}}
:root[data-theme=dark]{color-scheme:dark;--bg:#111c26;--surface:#192b38;
--text:#edf3f7;--muted:#bccbd6;--line:#8293a0;--accent:#8ad6ff;--alert:#ffb591}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);
font:1rem/1.6 system-ui,sans-serif;overflow-wrap:anywhere}
header,main,footer{max-width:76rem;margin:auto;padding:1.5rem}
header{padding-top:1.5rem;padding-bottom:0}h1{font-size:clamp(1.8rem,4vw,2.5rem);line-height:1.15;margin:.4rem 0}
h2{font-size:1.65rem;line-height:1.3}h3{font-size:1.25rem}
p{max-width:78ch;margin:.75rem 0}a{color:var(--accent);text-underline-offset:.18em}
a:focus-visible,summary:focus-visible,select:focus-visible,[tabindex]:focus-visible{
outline:3px solid var(--accent);outline-offset:4px}
.skip{position:absolute;top:-8rem;left:1rem;background:var(--surface);padding:1rem}
.skip:focus{top:1rem}.eyebrow{color:var(--muted);letter-spacing:.1em;font-size:.8rem}
.muted,caption{color:var(--muted)}.notice{border-left:4px solid var(--accent);padding-left:1rem}
.safety{border-left:4px solid var(--alert);padding:.5rem 1rem;background:var(--bg)}
.safety p{margin:.3rem 0}.safety strong{color:var(--alert)}
.lead{font-size:1.1rem}.finding{border-top:1px solid var(--line);padding:.75rem 0}
.finding p{margin:.4rem 0}.assessment{margin:.75rem 0}
.finding h4{margin:.25rem 0 .5rem}
:target{scroll-margin-top:1rem}summary code{font-weight:400}
.overview{background:var(--surface);
border:1px solid var(--line);border-radius:.6rem;padding:1.5rem;margin-bottom:2rem}
section.skill{border-top:2px solid var(--line);padding:1rem 0;margin:1.5rem 0}
.status-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,16rem),1fr));gap:1rem;margin-top:1rem}
.status-grid>div{background:var(--bg);padding:1rem;border-radius:.3rem}
.num{text-align:right;font-variant-numeric:tabular-nums}
h2{margin-top:2rem}h4{font-size:1.05rem}.overview h2{margin-top:0}
.assessment{border:1px solid var(--line);border-radius:.3rem;padding:1rem;min-width:0}
.badge{display:inline-block;border:1px solid currentColor;
border-radius:.25rem;padding:.15rem .5rem;font-size:.85rem}
nav ul{display:flex;flex-wrap:wrap;gap:.5rem 1.5rem;padding:0;list-style:none}
nav a,summary,select{min-height:2rem}nav a{display:inline-block;padding:.3rem 0}
details{border-top:1px solid var(--line);padding:.75rem 0}summary{cursor:pointer;font-weight:600}
pre,code{font-family:ui-monospace,monospace;font-size:.85em}pre{white-space:pre-wrap;
overflow-wrap:anywhere;background:var(--bg);padding:1rem;border-radius:.3rem}
.table-scroll{max-width:100%;overflow-x:auto;margin:1rem 0}
table{border-collapse:collapse;width:100%;font-size:.95rem}caption{text-align:left;margin-bottom:.5rem}
table.wide{min-width:48rem}
th,td{padding:.7rem;text-align:left;vertical-align:top;border-bottom:1px solid var(--line)}
thead th{background:var(--bg)}tbody th{font-weight:600}td p{margin:0}
.priorities{padding-left:1.5rem}.priorities>li{padding:.5rem 0}
.run{border-top:2px solid var(--line);margin-top:1.5rem;padding-top:.5rem}
label{display:inline-block;margin-right:.5rem}select{font:inherit;background:var(--surface);
color:var(--text);border:1px solid var(--line);padding:.4rem}
@media(max-width:40rem){header,main,footer{padding:1rem}section.skill,.overview{padding:1rem}}
@media print{:root,:root[data-theme=dark],:root:not([data-theme=light]){color-scheme:light;
--bg:#f4f6f8;--surface:#fff;--text:#192b3a;--muted:#455c6b;--line:#788995;--accent:#005a87;--alert:#963511}
body{background:white;color:var(--text)}details{break-inside:auto}
details::details-content{display:block;content-visibility:visible}pre{white-space:pre-wrap}
table.wide{min-width:0}th,td{padding:.3rem}
header,main,footer{max-width:none}.theme,.skip{display:none}.table-scroll{overflow:visible}}
""".strip()

JS = """
const control = document.getElementById('theme');
document.getElementById('theme-control').hidden = false;
control.addEventListener('change', () => {
  if (control.value === 'system') document.documentElement.removeAttribute('data-theme');
  else document.documentElement.setAttribute('data-theme', control.value);
});
// Reveal nested evidence before following a link; native fragment navigation
// remains available without JavaScript (Chromium also reveals closed details).
document.addEventListener('click', event => {
  const a = event.target.closest('a[href^="#"]');
  const target = a && document.getElementById(a.hash.slice(1));
  if (!target) return;
  for (let parent = target.parentElement; parent; parent = parent.parentElement) {
    if (parent.tagName === 'DETAILS') parent.open = true;
  }
});
""".strip()

NEXT_STEPS = analysis.NEXT_STEPS
FINDING_LABELS = analysis.FINDING_LABELS
COMPARISON_STATUS = {
    'insufficient_run_evidence': 'Fewer than two measured runs supplied; cross-run comparison is unavailable.',
    'comparison_limit_exceeded': 'More than two measured runs supplied; the analyzer does not select or order a pair.',
    'invocation_comparison_limit_exceeded': 'More than 16 eligible skill pairs supplied; comparisons are suppressed.',
    'compared': 'The analyzer evaluated the two supplied runs for compatibility.',
}
ARM = {'with_skill': 'With skill', 'without_skill': 'Without skill'}
STATUS_LABELS = {
    'pass_substantive_usefulness_demonstrated': 'Substantive usefulness pass',
    'not_quality_qualified': 'Not quality qualified',
}
DISPOSITION_LABELS = {'skill_change': 'Skill change', 'investigate': 'Investigate', 'no_change': 'No change'}
PROPOSAL_LABELS = {
    'modify_skill': 'Modify skill', 'improve_eval': 'Improve evaluation',
    'fix_grader_or_harness': 'Fix grader or harness', 'investigate': 'Investigate', 'no_change': 'No change',
}
ASSESSOR_LABELS = {
    'independent_ai': 'Independent AI assessment (supplied)',
    'human_supplied': 'Human assessment (supplied; unauthenticated)',
    'unknown': 'Assessment (author category unknown)',
}
LIMITATIONS = {
    'results_not_supplied': 'Results were not supplied', 'coverage_missing': 'Numeric coverage is incomplete',
    'execution_incomplete': 'Execution evidence is incomplete', 'case_details_missing': 'Case details are missing',
    'metadata_missing': 'Required identity or attempt metadata is missing', 'source_unavailable': 'Exact source content is unavailable',
    'source_mismatch': 'Source identity does not match', 'reference_unavailable': 'Original support is unavailable',
    'reference_expired': 'Original artifact references have expired', 'scan_incomplete': 'Static scan coverage is incomplete',
}


def safe(value):
    return html.escape(str(value), quote=True)


def text(value):
    if value is None:
        return 'Unknown / not supplied'
    if type(value) is bool:
        return 'Yes' if value else 'No'
    return safe(value)


def code(value):
    return '<code>' + text(value) + '</code>'


def presentation_label(value, labels):
    """Translate recognized codes only; supplied prose is otherwise verbatim."""
    return text(labels.get(value, value))


def count(value, singular, plural=None):
    return text(value) + ' ' + (singular if value == 1 else plural or singular + 's')


def outcome(value):
    # Recorded rubric booleans and gate 0/1 values share presentation only.
    if value is None:
        return 'Unknown'
    return 'Passed' if value == 1 else 'Failed'


def context(skill, cases=()):
    return skill + (' · ' + ('case ' if len(cases) == 1 else 'cases ') + ', '.join(cases) if cases else '')


def short_identity(value):
    """Display alias only; exact identities remain in evidence disclosures."""
    return re.sub(r'sha256:[a-f0-9]{64}', lambda m: m[0][:19] + '…', str(value))


def limitations(availability):
    return '; '.join(safe(LIMITATIONS[r]) + ' (' + code(r) + ')' for r in availability['reasons']) or 'No schema-level limitation recorded'


def anchor(kind, *identities):
    # Scope shared observation/reference IDs by their containing record.
    return kind + '-' + evidence.identity(list(identities)).split(':')[1]


def link(kind, identities, label):
    return f'<a href="#{anchor(kind, *identities)}">{safe(short_identity(label))}</a>'


def disclosure(label, value, *, target=None):
    identity = ' id="' + safe(target) + '"' if target is not None else ''
    return '<details><summary>' + safe(label) + '</summary><pre' + identity + '>' + safe(
        json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)) + '</pre></details>'


def quantity(value):
    if value is None:
        return 'Unavailable'
    # Direction is retained even when four-place display rounds to zero.
    return code(analysis.signed(value)) + ' (' + safe(value['direction']) + ')'


def table(caption, headers, rows):
    cells = []
    for row in rows:
        cells.append('<tr><th scope="row">' + row[0] + '</th>' + ''.join(
            ('<td class="num">' if re.fullmatch(r'-?[0-9]+(?:[.][0-9]+)?', cell) else '<td>') + cell + '</td>' for cell in row[1:]) + '</tr>')
    width_class = ' class="wide"' if len(headers) > 3 else ''
    return '<div class="table-scroll" role="region" aria-label="' + safe(caption) + '" tabindex="0"><table' + width_class + '><caption>' + safe(
        caption) + '</caption><thead><tr>' + ''.join('<th scope="col">' + safe(h) + '</th>' for h in headers
        ) + '</tr></thead><tbody>' + ''.join(cells) + '</tbody></table></div>'


def support_links(finding, records):
    links = [link('record', (rid,), context(finding['skill'] or 'Report scope', finding['case_ids']) +
                  ' · record ' + rid) for rid in finding['record_ids']]
    for rid in finding['record_ids']:
        record = records[rid]
        for obs in record.get('observations', []):
            if obs['id'] in finding['observation_ids']:
                links.append(link('observation', (rid, obs['id']), context(record['source']['skill_id'], [obs['case_id']]) +
                                  ' · ' + ARM[obs['arm']] + ' observation ' + obs['id']))
        for ref in record.get('references', []):
            if ref['id'] in finding['reference_ids']:
                links.append(link('reference', (rid, ref['id']), context(record['source']['skill_id'], finding['case_ids']) +
                                  ' · reference ' + ref['id']))
    return '<ul>' + ''.join('<li>' + item + '</li>' for item in links) + '</ul>' if links else '<p>No record-level support links for this invocation limit.</p>'


def priorities(findings, records):
    if not findings:
        return '<p>No deterministic investigation findings in the supplied evidence. This does not establish production readiness.</p>'
    items = []
    for item in analysis.ordered_findings(findings):
        label = {'mandatory': 'Mandatory outcome to inspect', 'investigate': 'Investigation', 'context': 'Evidence gap'}[item['importance']]
        observed = item['observed']
        facts = []
        if item['case_ids']:
            facts.append(('Case: ' if len(item['case_ids']) == 1 else 'Cases: ') + ', '.join(code(v) for v in item['case_ids']))
        if 'with_minus_without' in observed:
            facts.append('With minus without: ' + quantity(observed['with_minus_without']))
        if 'right_minus_left' in observed:
            facts.append('Right minus left: ' + quantity(observed['right_minus_left']))
        if observed.get('components'):
            facts.append('Failed gate components: ' + ', '.join(code(v) for v in observed['components']))
        if observed.get('scanners'):
            facts.append('Scanners: ' + ', '.join(code(v) for v in observed['scanners']))
        if 'unavailable_references' in observed:
            facts.append('Unavailable original references: ' + text(observed['unavailable_references']))
        items.append(f'<li id="{anchor("finding", item["id"])}"><strong>' + safe(FINDING_LABELS[item['kind']]) + '</strong> <span class="badge">' + label +
            '</span><p>' + safe(item['skill'] or 'Report scope') + ' · ' + '; '.join(facts) + '</p><p>Evidence limit: ' + safe(analysis.finding_qualifier(item)) + '.</p><p>Next: ' + safe(NEXT_STEPS[item['next_step']]) + '</p><details><summary>Finding evidence and uncertainty</summary>' +
            '<p>Scope: ' + (', '.join(code(v) for v in item['case_ids']) or 'Run or configuration scope') + '</p>' +
            disclosure('Exact deterministic finding and next-step code', item) + support_links(item, records) + '</details></li>')
    return '<ol class="priorities">' + ''.join(items) + '</ol>'


coverage_label = analysis.coverage_label


def security_investigations(skills, records):
    """Expose exact component values, without new means or analyst findings.

    Only complete single-attempt comparisons are eligible. Multi-attempt and
    missing-component comparisons remain in the original observation evidence.
    """
    rows = []
    for skill in skills:
        for run in skill['behavioral_results']:
            record = records[run['record_id']]
            if record['policy']['attempts']['maximum'] != 1:
                continue
            indexed = analysis.case_index(record)
            for case in run['case_summary']['cases']:
                if case['with_minus_without'] is None:
                    continue
                arms = indexed[case['case_id']]
                left, right = (arms[a][0] for a in ARM)
                with_score, without_score = left['scores']['security'], right['scores']['security']
                if with_score is not None and without_score is not None and with_score < without_score:
                    rows.append('<li><strong>' + safe(skill['skill']) + ' · Security-component score · case ' +
                        code(case['case_id']) + '</strong>: ' + text(with_score) + ' with skill versus ' +
                        text(without_score) + ' without skill. Inspect the security judgment separately from '
                        'command-wrapper or harness concerns. ' + link('components', (run['record_id'], left['id']),
                        context(skill['skill'], [case['case_id']]) + ' · with-skill security evidence') + ' · ' +
                        link('components', (run['record_id'], right['id']),
                        context(skill['skill'], [case['case_id']]) + ' · without-skill security evidence') + '.</li>')
    return rows


def assessment_summary(supplied):
    score = ('Numeric score not assigned' if supplied['score'] is None else
             'Supplied score: ' + text(supplied['score']) + ' out of ' + text(supplied['maximum']))
    return text(supplied['attribution']) + ': <strong>' + presentation_label(supplied['verdict'], STATUS_LABELS) + '</strong>. ' + score + '.'


def static_quality(skills):
    runs = [run for skill in skills for run in skill['static_results']]
    parts = ['<h3 id="static-quality">Static quality and coverage · native evaluator judgments</h3>',
             '<p>Scanner severity does not establish a confirmed vulnerability, instruction defect or need to change a skill. '
             'Findings remain advisory in quality CI.</p>']
    if not runs or any(analysis.security_coverage_status(run) not in ('passed', 'failed') for run in runs):
        parts.append('<p class="notice"><strong>Security-analysis coverage is incomplete or unavailable.</strong> '
                     'Retained findings still require investigation.</p>')
    parts.extend('<p>' + safe(line) + '</p>' for line in analysis.static_overview(runs))
    if any(not skill['static_results'] for skill in skills):
        parts.append('<p>Static evidence not supplied for: ' + ', '.join(
            link('skill', (skill['skill'],), skill['skill']) for skill in skills if not skill['static_results']) +
            '. Imported skills without an evaluation overlay may be outside the supplied inventory.</p>')
    parts.append('<h4>Significant static flags · applicability unresolved</h4>')
    groups = analysis.static_groups(runs)
    if not groups:
        parts.append('<p>No detailed critical/high flags supplied. Native counts and evidence gaps remain authoritative.</p>')
    else:
        parts.append('<ul class="priorities">')
        for key, items in groups[:analysis.SIGNIFICANT_GROUP_LIMIT]:
            level, scanner, check, _ = key
            names = sorted({run['source']['skill_id'] for run, _ in items})
            run, item = items[0]
            location = (item['member'] + (':' + str(item['line']) if item['line'] is not None else '')) if item['member'] else 'Source location unavailable'
            parts.append('<li><strong>' + safe(level.upper()) + ' · ' + code(scanner) + ' / ' + code(check) +
                '</strong> · ' + count(len(items), 'finding') + '<p>Affected skills: ' + ', '.join(
                    link('skill', (name,), name) for name in names) + '</p><p>' +
                safe(analysis.static_guidance(scanner, check)) + '</p><p>Representative: ' +
                link('static-finding', (run['record_id'], item['reference']),
                     run['source']['skill_id'] + ' · ' + location + ' · structured finding') + ' · ' +
                link('reference', (run['record_id'], item['reference']), 'exact report reference') + '</p></li>')
        parts.append('</ul>')
    omitted = groups[analysis.SIGNIFICANT_GROUP_LIMIT:]
    if omitted:
        parts.append('<p>Additional groups omitted from this preview: ' + '; '.join(
            str(sum(key[0] == level for key, _ in omitted)) + ' ' + level + ' groups / ' +
            str(sum(len(items) for key, items in omitted if key[0] == level)) + ' findings'
            for level in ('critical', 'high')) + '. Use the per-skill static evidence below for every finding.</p>')
    parts.append('<p>Groups count retained finding records, not raw scanner occurrence spans. Every individual finding remains '
                 'in the per-skill evidence. No false-positive classification or historical novelty is inferred.</p>')
    parts.append('<details><summary>Static evidence interpretation and limits</summary><p>SECURITY denotes this pipeline\'s '
        'SkillSpector integration; other validators retain separate attribution. Native required checks describe evaluator policy, '
        'not the CI finding policy or a scanner process outcome. Partial scans may retain valid findings. Zero findings and no '
        'incompleteness reported do not prove exhaustive inspection or behavioral benefit. Detailed SkillSpector coverage reasons '
        'and separate process outcomes are not retained by this native-report path.</p></details>')
    return ''.join(parts)


def static_directory(skill):
    if not skill['static_results']:
        return 'Not supplied; no clean-scan claim'
    rows = []
    for run in skill['static_results']:
        native = next((s for s in run['scans'] if s['scanner'] == 'catalog-total'), None)
        rows.append(link('record', (run['record_id'],), skill['skill'] + ' · static results') +
            ' · native ' + text(native['status'] if native else None) + ' · C/H/M/L ' +
            (' / '.join(text(native['severity_counts'][k]) for k in analysis.SEVERITIES) if native else 'Unknown'))
    return '<br>'.join(rows)


def executive_summary(result, records, *, pages=None):
    skills = result['skills']; findings = result['findings']
    measured = [s for s in skills if any(r['measured'] for r in s['behavioral_results'])]
    parts = ['<p class="lead">Supplied evidence only. ' + count(len(skills), 'skill') + ' represented; <strong>' + text(len(measured)) +
        ' with measured results</strong>. ' +
        text(sum(coverage_label(s) == 'Configured; results not supplied' for s in skills)) +
        ' configured without supplied results; ' + text(sum(coverage_label(s) == 'No configured suite' for s in skills)) +
        ' without a configured behavioral suite.</p>']
    if pages is not None:
        standard = {s['skill'] for s in skills for run in s['behavioral_results']
                    if run['measured'] and records[run['record_id']]['policy']['attempts']['mode'] == 'standard'}
        diagnostic = {s['skill'] for s in skills for run in s['behavioral_results']
                      if run['measured'] and (records[run['record_id']].get('custom', {}).get('purpose') == 'oracle_qualification'
                          or records[run['record_id']]['policy']['attempts']['mode'] == 'confirmation')}
        parts = ['<p class="lead">Retained validated evidence. ' + count(len(skills), 'skill') + ' represented; <strong>' +
                 count(len(standard), 'skill') + ' with detailed standard model-backed evidence</strong>; ' +
                 count(len({row['skill'] for row in pages['history']}), 'skill') + ' in <a href="#history">admitted numeric history</a>; ' +
                 count(len(diagnostic), 'skill') + ' with diagnostic evidence. Oracle qualification tests the harness; '
                 'confirmation runs remain diagnostic. Neither enters qualified performance history.</p>']
    runs = [r for s in skills for r in s['behavioral_results']]
    failed = sum(len(r['gates']['failed']) for r in runs)
    passed = sum(r['gates']['passed_observations'] for r in runs)
    unknown = sum(r['gates']['unknown_observations'] for r in runs)
    missing_coverage = any(not r['measured'] or any(
        arm['execution_status'] != 'succeeded' or arm['coverage']['expected_attempts'] is None
        or arm['coverage']['recorded_attempts'] != arm['coverage']['expected_attempts']
        or arm['coverage']['case_details'] != 'complete' for arm in r['arms'])
        or any(obs['attempt'] is None for obs in records[r['record_id']]['observations'])
        for r in runs) or any(f['kind'] == 'configured_unmeasured' for f in findings)
    incomplete = unknown or not (failed + passed + unknown) or missing_coverage
    parts.append('<div class="safety"><p><strong>' +
        ('Safety evidence is incomplete' if incomplete else 'Recorded mandatory gate outcomes') + '</strong></p><p>' +
        'Mandatory gates · Among recorded observations: ' +
        text(failed) + ' failed · ' + text(passed) + ' passed · ' + text(unknown) +
        ' unknown</p><p>' + ('No recorded gate outcomes supplied. ' if not (failed + passed + unknown) else '') +
        ('Missing execution coverage is excluded from these counts. ' if missing_coverage else '') +
        'Unknown or unmeasured gates are not passing outcomes. ' +
        ('Inspect recorded failures before accepting the result.' if failed else 'Zero recorded failures does not establish safety.') + '</p></div>')
    static_runs = [run for skill in skills for run in skill['static_results']]
    static_status = analysis.static_count_label(static_runs)
    parts.append('<div class="status-grid"><div><strong>Static findings · advisory</strong><p>' + safe(static_status) +
        '</p></div><div><strong>Investigation records</strong><p>' + count(len(findings), 'record') +
        '; ' + text(sum(f['importance'] == 'mandatory' for f in findings)) + ' mandatory outcomes to inspect</p></div></div>')
    if not static_runs or any(analysis.security_coverage_status(run) not in ('passed', 'failed') for run in static_runs):
        parts.append('<p class="notice">Security-analysis coverage is incomplete or unavailable.</p>')
    parts.append('<nav aria-label="Report sections"><ul><li><a href="#important-findings">Review first</a></li>'
        '<li><a href="#coverage">Skills and coverage</a></li><li><a href="#provenance">Source details</a></li></ul></nav>')
    return ''.join(parts)


def review_first(result, records, attached):
    skills = result['skills']; findings = analysis.ordered_findings(result['findings'])
    parts = ['<section aria-labelledby="important-findings"><h2 id="important-findings">Review first</h2>',
        '<p>Native required-check failures describe evaluator policy; they are not CI blockers. '
        'Grader judgments do not verify execution. A grader failure is not automatically an instruction defect.</p>',
        '<h3>Deterministic investigations</h3><p>' + count(len(findings), 'investigation record') +
        '; showing ' + text(min(len(findings), analysis.FINDING_PREVIEW_LIMIT)) + '. ' +
        '<a href="#all-findings">Complete list and evidence</a>.</p><ol class="priorities">']
    for item in findings[:analysis.FINDING_PREVIEW_LIMIT]:
        parts.append('<li><strong>' + safe(FINDING_LABELS[item['kind']]) + '</strong><p>' +
            safe(analysis.finding_observation(item)) + '.</p><p>Evidence limit: ' +
            safe(analysis.finding_qualifier(item)) + '.</p><p>Next: ' + safe(NEXT_STEPS[item['next_step']]) + ' ' +
            link('finding', (item['id'],), context(item['skill'] or 'Report scope', item['case_ids']) + ' · finding evidence') + '.</p></li>')
    parts.append('</ol><p>' + text(max(0, len(findings) - analysis.FINDING_PREVIEW_LIMIT)) +
        ' additional investigation records in the complete list.</p>')
    if not findings:
        parts.append('<p>No deterministic investigation findings in the supplied evidence. This does not establish readiness.</p>')
    parts.append(static_quality(skills))
    components = security_investigations(skills, records)
    if components:
        parts.append('<details><summary>Security-component observations · descriptive comparisons</summary><ul>' +
                     ''.join(components) + '</ul></details>')
    parts.append('<details id="all-findings"><summary>All deterministic investigations · ' +
        count(len(findings), 'record') + '</summary>' + priorities(findings, records) + '</details>')
    parts.append('<details><summary>Evidence gaps and comparison limits</summary><p>Missing measurements, unknown gates, '
        'omitted runs, original support availability, actual runtime behavior, production effectiveness and portability '
        'limit interpretation. Differences are descriptive; causality, statistical significance, cross-suite ranking '
        'and time trends are not established. Static scans and configuration do not measure behavioral benefit.</p></details>'
    )
    if attached:
        parts.append('<h3 id="analyst-actions">Analyst conclusions and recommended actions · model interpretation</h3>'
        '<p>Analyst qualification: <strong>' + presentation_label('not_quality_qualified', STATUS_LABELS) + '</strong>. Automated publication is ineligible. '
        'Authenticated human approval is not established. Supplied assessments are separate opinions about analyst usefulness, '
        'not skill performance or permission to act.</p>')
    for item in attached.values():
        judgment = item['report']['judgment']
        parts.append('<div class="finding"><h4>' + safe(item['skill']) + ' · ' +
            'Analyst interpretation · ' + presentation_label(judgment['assessment']['disposition'], DISPOSITION_LABELS) + '</h4><p>' +
            link('interpretation', (item['record_id'],), item['skill'] + ' · analyst conclusions, proposed actions and citations') + '</p>')
        for recommendation in judgment['recommendations']:
            parts.append('<p><strong>Proposed action · ' + presentation_label(recommendation['category'], PROPOSAL_LABELS) + ':</strong> ' +
                text(recommendation['scope']) + '</p>')
        for supplied in item['assessments']:
            parts.append('<p><strong>' + safe(ASSESSOR_LABELS[supplied['author_kind']]) + ':</strong> ' + assessment_summary(supplied) + ' ' +
                link('assessment', (item['record_id'], supplied['id']), item['skill'] + ' · ' + supplied['attribution'] +
                     ' · assessment reasoning and limitations') + '</p>')
        parts.append('</div>')
    if not attached:
        parts.append('<p>No analyst reports or independent assessments supplied. Use the deterministic next steps.</p>')
    parts.append('</section><section aria-labelledby="coverage"><h2 id="coverage">Skills and coverage</h2>')
    parts.append('<p>Evaluation groups (arms) compare recorded outputs with and without skill. Coverage is not a quality rating.</p>')
    parts.append(table('Coverage in supplied evidence', ('Skill', 'Behavioral evidence', 'Configured coverage', 'Static evidence'),
        [[link('skill', (s['skill'],), s['skill']), safe(coverage_label(s)),
          '; '.join(count(c['suite']['case_count'], 'configured case') + ' per arm' for c in s['configurations'] if c['suite']) or
          ('No behavioral suite configured' if s['configurations'] else 'Configuration not supplied'),
          static_directory(s)] for s in skills]))
    if not skills:
        parts.append('<p>The supplied inventory is empty. No skills or measurements are inferred.</p>')
    parts.append('</section>')
    return ''.join(parts)


def record_support(rid, record):
    parts = [disclosure('Source identity and content manifest', record['source']),
             disclosure('Record scope and availability', {k: record[k] for k in ('kind', 'run_id', 'availability')}),
             disclosure('Dataset identity', record['dataset']), disclosure('Policy identity', record['policy'])]
    if record['kind'] == 'behavioral':
        parts.append(disclosure('Arm conditions and coverage', record['arms']))
    if any('security_evidence' in obs for obs in record['observations']):
        parts.append('<p>Quality is unavailable for these verifier diagnostics. Finding provenance and detector flags are recorded below; '
                     'access success, authorization, skill causation and a clean security conclusion remain unverified.</p>')
    observations = []
    for obs in record['observations']:
        if 'security_evidence' in obs:
            parts.append(disclosure('Retained verifier security evidence · quality unavailable', {
                'observation_id': obs['id'], 'case_id': obs['case_id'], 'arm': obs['arm'],
                **obs['security_evidence']}))
        refs = '<br>'.join(link('reference', (rid, ref), context(record['source']['skill_id'], [obs['case_id']]) +
                               ' · reference ' + ref) for ref in obs['references'])
        observations.append([f'<span id="{anchor("observation", rid, obs["id"])}">' + code(short_identity(obs['id'])) + '</span>',
            safe(ARM[obs['arm']]), code(obs['case_id']), text(obs['attempt']), text(obs['score']), outcome(obs['rubric_pass']),
            outcome(obs['deterministic_gate']), disclosure('Exact observation outcomes', {
                'rubric_pass': obs['rubric_pass'], 'deterministic_gate': obs['deterministic_gate']}) +
            disclosure('Native component scores and gate details', {
                'observation_id': obs['id'], 'scores': obs['scores'], 'deterministic_scores': obs['deterministic_scores'],
                **({k: obs[k] for k in ('raw_scores', 'raw_deterministic_scores')} if 'raw_scores' in obs else {}),
                **({'custom': obs['custom']} if 'custom' in obs else {})},
                target=anchor('components', rid, obs['id'])) + refs])
    if observations:
        parts.append(table('Observation identities and recorded outcomes',
            ('Observation', 'Arm', 'Case', 'Attempt', 'Overall score', 'Rubric pass', 'Mandatory gate', 'Components and references'), observations))
    parts.append('<p>Reference availability is recorded public availability, not verification of local possession. '
                 'Members and locators are inert identifiers; this report never retrieves or opens them.</p>')
    references = []
    for ref in record['references']:
        references.append([f'<span id="{anchor("reference", rid, ref["id"])}">' + code(short_identity(ref['id'])) + '</span>',
            text(ref['availability']), code(ref['member']), disclosure('Artifact, digest, locator and provenance', ref)])
    parts.append(table('Original support references', ('Reference identity', 'Availability', 'Original member', 'Provenance'), references)
                 if references else '<p>No original support references supplied.</p>')
    return '<details><summary>Source, policy, observations and original support</summary>' + ''.join(parts) + '</details>'


def custom_measurements(run, record):
    result = run['custom']; rid = run['record_id']
    parts = ['<h4>Skill-specific deterministic measurements</h4>',
        '<p>Reported custom measurements; paired population ' + ('complete' if result['complete_paired_population'] else 'incomplete') + '.</p>',
        '<details><summary>Reported evidence and authentication limits</summary><p><strong>Structurally validated reported evidence.</strong> Native consistency was reported at admission; '
        'this consumer does not recheck native directories. Producer identity and execution are not independently authenticated. '
        'Hashes identify content; they do not prove who produced it or that execution occurred.</p></details>',
        '<p>Purpose: ' + text(result['purpose']) + '; recorded agent: ' + code(result['agent']) + '; version ' + code(record['custom']['agent_version']) + '. ' +
        ('Retrospective grading is not a new model attempt or a completed comparison.' if evidence.campaign_purpose(result['purpose']) and evidence.replay_purpose(result['purpose']) else 'Oracle fixture qualification is not model-backed skill-effectiveness evidence.' if evidence.campaign_purpose(result['purpose']) and not result['purpose'].endswith('-live') or result['purpose'] in ('oracle_qualification', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness_control', 'skill_effectiveness_probe') else
         'Within-run differences describe supplied measurements; they do not establish causality.') + '</p>']
    if evidence.campaign_purpose(result['purpose']) and result['purpose'].endswith('-live'):
        parts.append('<p>Six planned attempts, three per arm, on one output-informed case. Prospectively frozen follow-up; not an untouched held-out benchmark. Primary outcome: reference-correct work detecting all seeded defects. Skill access is recorded separately in the attempt ledger and does not demonstrate benefit. A tie, absent-arm advantage or inconclusive result is legitimate.</p>')
    if evidence.campaign_purpose(result['purpose']):
        parts.append('<details><summary>Campaign runtime and variant mapping</summary>' + disclosure('Registered runtime identity', record['custom']['runtime']) + '</details>')
    parts.append('<details><summary>Task definitions and applicability</summary>' + table('Tasks and applicability', ('Case', 'Task', 'Source case', 'Applicable native metrics'),
        [[code(case['case_id']), text(case['title']), code(case['source_case_id']), ', '.join(code(k) for k in case['metrics'])]
         for case in record['custom']['cases']]) + '</details>')
    if any(definition['role'] == 'mandatory_with_skill_gate' for definition in record['custom']['definitions']):
        parts.append('<p>Pass/fail below summarizes the registered gate conjunction. Task correctness is separate. '
                     'Baseline gate zeros are comparison evidence, not mandatory with-skill failures.</p>')
    kinds = (*evidence.CUSTOM_OUTCOMES, 'missing')
    parts.append(table('Reported custom-grader classifications · failures and unavailability stay distinct', ('Outcome', 'With skill', 'Without skill'),
        [[safe(kind), *[text(result['outcomes'][arm][kind]) for arm in ARM]] for kind in kinds]))
    for metric in result['metrics']:
        definition = metric['definition']
        parts += ['<h4>' + text(definition['title']) + '</h4>',
            table('Measured values · ' + definition['id'], ('Metric', 'With skill mean', 'Without skill mean', 'With minus without'),
                [[text(definition['title']), quantity(metric['arm_means']['with_skill']), quantity(metric['arm_means']['without_skill']),
                  quantity(metric['with_minus_without'])]]),
            '<p>' + text(metric['unavailable_reason'] or metric['interpretation']) + '. '
            'Activation/routing and gate outcomes are not interchangeable with task correctness.</p>',
            '<details><summary>Metric definition, applicability and scoring basis</summary><p>' + text(definition['definition']) + '</p>',
            '<p>Metric ' + code(definition['id']) + '; competency ' + code(definition['competency']) + '; unit ' + code(definition['unit']) +
            '. Aggregation: equal weight per applicable trial, preserving each trial\'s numerator and denominator.</p>',
            table('Applicability and complete-population comparison · ' + definition['id'],
                ('Coverage', 'With skill', 'Without skill'),
                [[safe(label), *[text(metric['coverage'][arm][key]) for arm in ARM]] for key, label in
                 (('expected_applicable', 'Expected applicable'), ('measured', 'Measured'),
                  ('unavailable_or_missing', 'Unavailable / missing'), ('recorded_nonapplicable', 'Recorded nonapplicable'))]),
            '</details>']
    rows = []
    for obs in record['observations']:
        for measurement in obs['custom']['measurements']:
            rows.append([code(obs['case_id']), safe(ARM[obs['arm']]), text(obs['attempt']),
                text(obs['custom']['outcome']), code(measurement['metric_id']), text(measurement['applicability']),
                text(measurement['value']) if measurement['status'] == 'measured' else 'Unavailable',
                text(measurement['numerator']) + ' / ' + text(measurement['denominator']),
                text(measurement['reason']), link('observation', (rid, obs['id']), 'Trial and evidence')])
    parts.append('<details><summary>All custom measurements and scoring bases</summary>' + table('Recorded custom measurements',
        ('Case', 'Arm', 'Attempt', 'Grader outcome', 'Metric', 'Applicability', 'Value', 'Numerator / denominator', 'Limitation', 'Evidence'), rows) + '</details>')
    if evidence.campaign_purpose(record['custom']['purpose']) and any('admission_reason' in o['custom'] for o in record['observations']) or record['custom']['profile_id'] in ('pester-cli-pilot-v1', 'pester-cli-pilot-external-v2', 'pester-cli-pilot-external-v3', 'pester-cli-pilot-external-v4', 'pester-cli-pilot-retained-v2', 'pester-cli-pilot-retained-v3', 'pester-cli-pilot-retained-v4', 'pester-cli-pilot-retained-v5', 'pester-cli-pilot-retained-v6', 'pester-cli-pilot-retained-v7', 'pester-cli-pilot-retained-v8', 'pester-cli-pilot-retained-v9', 'pester-cli-pilot-retained-v22', 'pester-cli-pilot-retained-v23', 'pester-cli-pilot-retained-v24', 'pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6', 'pester-effectiveness-v7', 'pester-effectiveness-v8', 'pester-effectiveness-v9', 'pester-effectiveness-v10', 'pester-effectiveness-v10-sol62', 'pester-effectiveness-v41', 'pester-effectiveness-v42', 'pester-effectiveness-v43', 'pester-effectiveness-v44', 'pester-effectiveness-v45', 'pester-effectiveness-v46', 'pester-effectiveness-v47', 'pester-effectiveness-v48', 'pester-effectiveness-v49', 'pester-effectiveness-v50', 'pester-effectiveness-v51'):
        parts.append(table('Pilot admission diagnostics', ('Case', 'Arm', 'Outcome', 'Admission reason'),
            [[code(obs['case_id']), safe(ARM[obs['arm']]), text(obs['custom']['outcome']),
              code(obs['custom'].get('admission_reason'))] for obs in record['observations']]))
    if evidence.campaign_purpose(record['custom']['purpose']) and any('defects' in o['custom'] for o in record['observations']) or record['custom']['profile_id'] in ('pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6', 'pester-effectiveness-v7', 'pester-effectiveness-v8', 'pester-effectiveness-v9', 'pester-effectiveness-v10', 'pester-effectiveness-v10-sol62', 'pester-effectiveness-v41', 'pester-effectiveness-v42', 'pester-effectiveness-v43', 'pester-effectiveness-v44', 'pester-effectiveness-v45', 'pester-effectiveness-v46', 'pester-effectiveness-v47', 'pester-effectiveness-v48', 'pester-effectiveness-v49', 'pester-effectiveness-v50', 'pester-effectiveness-v51'):
        parts.append(table('Seeded contract defects by case and arm', ('Case', 'Arm', 'Attempt', 'Defect', 'Result', 'Failure basis', 'Evidence'),
            [[code(obs['case_id']), safe(ARM[obs['arm']]), text(obs['attempt']), code(defect['id']),
              'Unavailable' if defect['detected'] is None else 'Detected' if defect['detected'] else 'Missed', text(defect.get('basis')),
              link('observation', (rid, obs['id']), 'Trial and evidence')]
             for obs in record['observations'] for defect in obs['custom']['defects']]))
    parts.append('<details><summary>Native token and phase-runtime observations</summary><p>Missing values stay unknown. '
        'Input tokens include cache tokens; phase durations are derived only from recorded start/finish times. '
        'These observations do not establish total model/judge usage.</p>' + table('Per-trial reported usage',
        ('Case / arm', 'Input tokens', 'Cache tokens', 'Output tokens', 'Agent seconds', 'Verifier seconds'),
        [[code(obs['case_id']) + ' / ' + safe(ARM[obs['arm']]), *[text(obs['custom']['usage'][key]) for key in ('n_input_tokens', 'n_cache_tokens', 'n_output_tokens', 'agent_execution_seconds', 'verifier_seconds')]]
         for obs in record['observations']]) + '</details>')
    parts.append('<p>Custom cross-run numeric comparisons and custom-metric history publication are disabled. '
                 'Incomplete required populations retain trial measurements but no aggregate comparison.</p>')
    return ''.join(parts)



def retrospective_outcomes(record, records):
    meta = record['custom']['retrospective']
    original = records[meta['original_record_id']]
    rows = []
    for arm in meta['submission_digests']:
        before = next(o for o in original['observations'] if o['arm'] == arm)
        after = next((o for o in record['observations'] if o['arm'] == arm), None)
        measurements = {m['metric_id']: m for m in after['custom']['measurements']} if after else {}
        reference = measurements.get('powershell-pester-6.reference-pass.v1', {})
        mutation = measurements.get('powershell-pester-6.mutation-detection.v2', measurements.get('powershell-pester-6.mutation-detection.v1', {}))
        rows.append([safe(ARM[arm]), code(meta['submission_digests'][arm]),
            text(before['custom']['outcome']) + ' / ' + code(before['custom']['admission_reason']),
            'Unmeasured', text(after['custom']['outcome']) if after else 'Missing',
            text(reference['value']) if reference.get('status') == 'measured' else 'Unavailable',
            text(mutation['numerator']) + ' / ' + text(mutation['denominator']) if mutation.get('status') == 'measured' else 'Unavailable'])
    return ('<p class="safety"><strong>Retrospective correction after inspection of the outputs; not prospectively frozen validation.</strong> '
        'The exact original submissions were replayed without model inference or judges. '
        'Original unscoreable outcomes and unmeasured correctness/mutation values remain unchanged. '
        + ('Reference, all five mutants, grading and isolation were preserved. The corrected adapter has a distinct identity. '
         'Only the current arm was enrolled. The paired collector retains an unavailable absent-arm carrier; no absent replay was requested or executed. '
         if evidence.campaign_purpose(record['custom']['purpose']) else 'Reference, mutants, scoring and isolation were preserved. The new evaluator has a distinct version. ')
        + 'This is not evidence of general skill effectiveness.</p>' +
        '<p>Original live run ' + text(meta['source_run']) + '; artifact ' + text(meta['source_artifact']) +
        '; source revision ' + code(meta['source_revision']) + '; archive ' + code(meta['source_archive_sha256']) + '.</p>' +
        table('Original and retrospective outcomes · unchanged submissions',
            ('Arm', 'Submission SHA-256', 'Original outcome', 'Original quality', 'Retrospective outcome', 'Reference pass', 'Mutants detected / executed'), rows))


def behavioral(run, records):
    rid = run['record_id']; record = records[rid]
    parts = [f'<article class="run" id="{anchor("record", rid)}"><h3>Behavioral run: ' + text(run['run_id']) + '</h3>',
        '<p>Evidence: <strong>' + text(run['availability']['status']) + '</strong>. Measurement: <strong>' +
        ('Recorded' if run['measured'] else 'Unmeasured') + '</strong>.</p>',
        '<p>Limitations: ' + limitations(run['availability']) + '</p>',
        '<details><summary>Run identity and evaluated source</summary>' + disclosure('Exact record identity', rid) + '<p>Evaluated source: ' + text(run['source']['owner']) + ' · ' + code(run['source']['repository']) +
        ' · revision ' + code(run['source']['revision']) + '.</p></details>']
    if analysis.pilot_record(record):
        label = 'Prospective exploratory cohort' if record['custom']['purpose'] == 'skill_effectiveness' else 'Credential-free cohort scheduler fixtures' if record['custom']['purpose'] == 'skill_effectiveness_probe' else 'Prospective grading qualification (oracle fixtures, no inference)' if record['custom']['purpose'] == 'skill_effectiveness_control' else 'Retrospective unchanged-submission replay' if evidence.replay_purpose(record['custom']['purpose']) else 'Live CLI compatibility pilot' if record['custom']['purpose'] == 'cli_pilot' else 'Credential-free real CLI isolation qualification' if record['custom']['purpose'] == 'cli_pilot_probe' else 'Native pilot grading controls'
        parts.append('<p class="safety"><strong>' + label + '; excluded from production history.</strong> '
            'Producer: ' + code(record['policy']['producer_profile']) + '. '
            'Custom task and mutation measurements are separate from uncollected judge-dependent scores. ' +
            ('Deterministic fixtures do not establish skill benefit.</p>' if record['custom']['purpose'] in ('skill_effectiveness_control', 'skill_effectiveness_probe') else 'This exploratory population does not establish general skill effectiveness.</p>'))
        if evidence.replay_purpose(record['custom']['purpose']):
            parts.append(retrospective_outcomes(record, records))
    elif 'benchmark' in record:
        parts.append('<p class="safety"><strong>Versioned offline behavioral qualification; excluded from production history.</strong> '
            'Released native collection and interpretation are exercised with fixture tasks and simulated judgments. '
            'This is not measured skill benefit or live-provider qualification.</p>')
    elif 'producer_profile' in record['policy']:
        parts.append('<p class="safety"><strong>Synthetic candidate qualification; excluded from production history.</strong> '
            'Producer: ' + code(record['policy']['producer_profile']) + '; scoring policy: ' + code(record['policy']['scoring_policy']) + '. '
            'No agent or model judge was run. Judge-dependent quality and composite scores are unavailable. '
            'Raw fixed judge values below test transport only. Changed weighting is not skill improvement. '
            'Task correctness, authorization, activation and the historical combined gate have separate meanings.</p>')
        parts.append(table('Raw upstream standard values · synthetic transport only', ('Arm', 'Case', 'Raw values', 'Interpreted quality'),
            [[safe(ARM[o['arm']]), code(o['case_id']), code(o['raw_scores']), 'Unavailable; no judge executed'] for o in record['observations']]))
    if 'benchmark' in record:
        contract = record['benchmark']
        parts.append('<h4>Versioned behavioral evidence</h4><p>Policy ' + code(contract['profile']) +
            '; judgments: ' + text(contract['judgments']) + '. Credential-free fixture observations; '
            'excluded from production history. Native task failure, unavailable judgment and runtime failure remain separate.</p>')
        if 'judge_accounting' in contract:
            parts.append('<p>Judge HTTP invocations and provider usage are separate from agent usage. '
                         'Incomplete usage is unknown; request initiation does not establish receipt or billing. '
                         'Token subsets are included within their parent counts. Costs require separately identified prices.</p>')
            parts.append(disclosure('Judge request and usage accounting', contract['judge_accounting']))
        parts.append(table('Released outcomes · simulated judgments', ('Arm', 'Case', 'Outcome', 'Overall', 'Correct answer', 'Security clean', 'Support'),
            [[safe(ARM[o['arm']]), code(o['case_id']), text(row['outcome']), text(row['quality']['overall']),
              text(row['quality']['correct_answer']), text(row['quality']['security_clean']),
              disclosure('Metric values, dimensions and applicability', row)]
             for row in contract['observations'] for o in record['observations'] if o['id'] == row['observation_id']]))
        parts.append(table('Dimension populations · absent evidence remains absent',
            ('Arm', 'Dimension', 'Native arm score', 'Observed', 'N/A', 'Unavailable', 'Absent', 'Expected'),
            [[safe(ARM[arm]), text(name), text(contract['native_dimensions'][arm].get(name)), *[text(counts[k]) for k in ('observed','not_applicable','unavailable','absent','expected')]]
             for arm, dimensions in contract['populations'].items() for name, counts in dimensions.items()]))
    custom_only = record.get('custom', {}).get('profile_id') is not None and record['policy']['fields']['grading'] == 'custom_only'
    if 'custom' in run: parts.append(custom_measurements(run, record))
    if run['native_metrics']:
        parts.append(table('Evaluator-reported metrics · original score units', ('Metric', 'Original value', 'Scope'),
            [[safe(m['name']), text(m['value']), 'With minus without' if m['name'] == 'Skill Lift' else 'With-skill dimension']
             for m in run['native_metrics']]))
    else:
        parts.append('<p>Standard judge metrics were not collected in custom-only mode.</p>' if custom_only else
                     '<p>Native metrics unavailable; no performance value is inferred.</p>')
    scheduler = record.get('custom', {}).get('scheduler')
    if scheduler:
        from campaign_scheduler_evidence import arm_label
        parts.append('<p>Scheduler execution comes from the captured durable schedule. Native collection status remains unchanged; '
                     'an empty arm can have failed collection while remaining unlaunched. A launch attempt does not establish CLI execution. '
                     'Native observations, grades and recorded counts are unchanged.</p>')
    parts.append(table('Measured coverage by arm — unknown counts are not zero',
        ('Arm',) + (('Scheduler execution', 'Native collection') if scheduler else ('Execution',)) +
        ('Cases expected', 'Attempts expected', 'Recorded', 'Scored', 'Unscored') + (() if custom_only else ('Rubric cases passed / total',)),
        [[safe(ARM[a['name']])] + ([text(arm_label(scheduler['witness'], a['name']))] if scheduler else []) +
         [text(a['execution_status']), text(a['coverage']['expected_cases']),
          text(a['coverage']['expected_attempts']), text(a['coverage']['recorded_attempts']),
          text(a['coverage']['scored_attempts']), text(a['coverage']['unscored_attempts'])] +
          ([] if custom_only else [text(a['rubric']['passed_cases']) + ' / ' + text(a['rubric']['total_cases'])]) for a in run['arms']]))
    summary = run['case_summary']; gates = run['gates']
    if custom_only:
        measured = sum(obs['custom']['outcome'] in evidence.CUSTOM_MEASURED for obs in record['observations'])
        parts.append('<p>' + text(measured) + ' trials with evaluated custom outcomes; ' +
            text(len(record['observations']) - measured) + ' retained trials without scoreable custom outcomes. '
            'Standard rubric dimensions were not collected. Applicable populations and comparison limits appear per metric above.</p>')
    else:
        parts.append('<p>' + count(summary['matched_cases'], 'matched case') + ' out of ' + text(summary['cohort_cases']) +
            '; ' + count(summary['scored_observations'], 'scored observation') + '. Mandatory gates: ' +
            text(len(gates['failed'])) + ' failed, ' + text(gates['passed_observations']) + ' passed, ' +
            text(gates['unknown_observations']) + ' unknown. Unknown gates do not count as passing.</p>')
    rows = []
    for case in summary['cases']:
        obs_links = '<br>'.join(link('observation', (rid, oid), context(record['source']['skill_id'], [case['case_id']]) +
                                   ' · ' + ARM[arm] + ' observation ' + oid)
            for arm, ids in case['observation_ids'].items() for oid in ids)
        rows.append([code(case['case_id']), quantity(case['arm_means']['with_skill']),
            quantity(case['arm_means']['without_skill']), quantity(case['with_minus_without']),
            ', '.join(code(v) for v in case['unavailable_reasons']) or 'Complete planned scores',
            disclosure('Exact derived quantities and support identities', case) + obs_links])
    if not custom_only: parts.append('<details><summary>All case scores and comparison coverage</summary><p>Descriptive arm means across complete planned attempts; '
        'with minus without. Attempts are not statistically paired. Missing or adaptive attempts suppress means. '
        'These case means do not reconstruct native Skill Lift.</p>' + table('Within-run case comparison',
        ('Case', 'With skill mean', 'Without skill mean', 'With minus without', 'Coverage limitations', 'Evidence'), rows) + '</details>')
    parts.extend([record_support(rid, record), '</article>'])
    return ''.join(parts)


def static_result(run, records):
    rid = run['record_id']
    parts = [f'<article class="run" id="{anchor("record", rid)}"><h3>Static checks</h3><p>Evidence ' +
        text(run['availability']['status']) + '. Static checks are not behavioral performance.</p>' + disclosure('Exact record identity', rid),
        '<p>Limitations: ' + limitations(run['availability']) + '</p>']
    policy = records[rid]['policy']
    producer = policy.get('producer_profile') or policy.get('published_id')
    if producer:
        parts.append('<p>Producer: ' + code(producer) + '.</p>')
    runtime = run.get('scanner_runtime')
    if runtime:
        parts.append('<p>Recorded scanner versions: ' + safe(', '.join(
            name + ' ' + version for name, version in sorted(runtime['versions'].items()))) +
            '.</p>' + disclosure('Scanner source and lock identities', runtime))
    else:
        parts.append('<p>Scanner versions unavailable in this historical record.</p>')
    for caveat in run.get('coverage_caveats', []):
        parts.append('<p>SkillSpector reports ' + code(caveat['producer_status']) +
                     ' with is_complete=true and ' + text(caveat['count']) +
                     ' missing-reference caveats (reference_missing). Repository coverage remains incomplete; '
                     'validated findings are retained. ' +
                     link('reference', (rid, caveat['reference']), 'Native caveat evidence') + '</p>')
    parts.append('<p>Required by native evaluator is its risk policy, not the CI finding policy or a scanner process outcome. '
                 'Incomplete tool markers have unknown counts and are not additional findings.</p>')
    parts.append('<details><summary>All scanner outcomes and native counts</summary>' + table('Scanner outcomes — counts can include findings without public detail',
        ('Validator / tool marker', 'Native state', 'Required by native evaluator', 'Native passed', 'Critical / high / medium / low'),
        [[code(s['scanner']), text(s['status']), text(s.get('blocking', True)), text(s['passed']),
          ' / '.join(text(s['severity_counts'][k]) for k in ('critical', 'high', 'medium', 'low'))] for s in run['scans']]) + '</details>')
    parts.append('<details><summary>Structured static findings</summary>' + table('Public static finding details',
        ('Scanner / check', 'Severity', 'Member / line', 'Original reference'),
        [[f'<span id="{anchor("static-finding", rid, f["reference"])}">' + code(f['scanner']) + ' / ' + code(f['check']) + '</span>',
          text(f['severity']), code(f['member']) + ' / ' + text(f['line']),
          link('reference', (rid, f['reference']), records[rid]['source']['skill_id'] + ' · ' + f['scanner'] +
               ' reference ' + f['reference'])] for f in sorted(run['detailed_findings'], key=lambda f:
                   ((*analysis.SEVERITIES, 'info').index(f['severity']), f['scanner'], f['check'] or '', f['reference']))]) + '</details>')
    for scanner in sorted({f['scanner'] for f in run['detailed_findings']}):
        parts.append('<p>' + code(scanner) + ': ' + safe(analysis.static_guidance(scanner, None)) + '</p>')
    if any((f['scanner'], f['check']) == ('SCHEMA', 'author_missing') for f in run['detailed_findings']):
        parts.append('<p>' + safe(analysis.static_guidance('SCHEMA', 'author_missing')) + '</p>')
    parts.extend([record_support(rid, records[rid]), '</article>'])
    return ''.join(parts)


def comparisons(skill):
    parts = ['<h3>Cross-run comparisons</h3><p>' + safe(COMPARISON_STATUS[skill['comparison_status']]) + '</p>',
        '<p>Left and right follow semantic record identity order, not time. No chronology or trend is established. '
        'Direct compatibility means recorded conditions match; it does not establish causality, significance or repeatability.</p>']
    for pair in skill['comparisons']:
        parts.append('<details><summary>Comparison: ' + safe(pair['classification']) + '</summary><p>Comparison identity ' + code(pair['id']) +
            '</p><p>Left: ' + link('record', (pair['left_record_id'],), skill['skill'] + ' · left record ' + pair['left_record_id']) + '<br>Right: ' +
            link('record', (pair['right_record_id'],), skill['skill'] + ' · right record ' + pair['right_record_id']) + '</p>')
        parts.append('<p>Compatibility reasons: ' + (', '.join(code(r) for r in pair['reasons']) or 'No recorded mismatch') + '</p>')
        parts.append(table('Cross-run native metrics', ('Metric', 'Left', 'Right', 'Right minus left'),
            [[safe(m['name']), text(m['left']), text(m['right']), quantity(m['right_minus_left'])] for m in pair['native_metrics']]))
        parts.append(table('Cross-run cases — only analyzer-supported deltas',
            ('Case / arm', 'Left mean', 'Right mean', 'Right minus left'),
            [[code(c['case_id']) + ' / ' + safe(ARM[a]), quantity(c['left_arm_means'][a]), quantity(c['right_arm_means'][a]),
              quantity(c['right_minus_left'][a])] for c in pair['cases'] for a in ARM]))
        parts.append(disclosure('Exact comparison quantities and observation identities', pair) + '</details>')
    return ''.join(parts)


def asset_hash(value):
    return base64.b64encode(hashlib.sha256(value.encode('utf-8')).digest()).decode('ascii')


def interpretation(item):
    """Only independently validated attachments reach this inert presentation."""
    report = item['report']; judgment = report['judgment']; assessment = judgment['assessment']
    parts = [f'<article class="run" id="{anchor("interpretation", item["record_id"])}"><h3>Model interpretation · analyst report</h3>'
        '<p class="notice"><strong>Model-generated judgment requiring human review.</strong> '
        'Valid citations do not prove a conclusion or instruction defect. '
        'Actions and validation plans are proposals.</p><p>Bound record: ' +
        link('record', (item['record_id'],), item['skill'] + ' · record ' + item['record_id']) + '</p><p>Analyst interpretation: <strong>' +
        presentation_label(assessment['disposition'], DISPOSITION_LABELS) + '</strong> · ' + count(len(judgment['recommendations']), 'recommendation') +
        '. Source owner: ' + text(report['provenance']['source_owner']) + '.</p>']
    parts.append('<p class="lead"><strong>Analyst conclusion:</strong> ' + text(assessment['interpretation']) + '</p>')
    for key, label in (('tested_benefit', 'Tested benefit · analyst interpretation'),
                       ('tested_harm', 'Tested harm · analyst interpretation'), ('uncertainty', 'Uncertainty')):
        parts.append('<p><strong>' + label + ':</strong> ' + text(assessment[key]) + '</p>')
    parts.append('<details><summary>Analyst reasoning, sufficiency and citations</summary>' + disclosure('Original analyst assessment', assessment) +
        disclosure('Native suggestions and analyst dispositions', judgment['native_suggestions']) +
        disclosure('Unverified external assertions', judgment['unverified_external_assertions']) + '</details>')
    if not judgment['recommendations']:
        parts.append('<p>No recommendations supplied. Approval is not established.</p>')
    for index, recommendation in enumerate(judgment['recommendations'], 1):
        parts.append('<div class="finding"><h4>Recommendation ' + str(index) + ' · proposal: ' + presentation_label(recommendation['category'], PROPOSAL_LABELS) +
            ' · ' + text(recommendation['priority']) + '</h4><p>' + text(recommendation['scope']) +
            '</p><details><summary>Rationale, risks and proposed validation</summary>')
        for key in ('justification', 'expected_benefit'):
            parts.append('<p><strong>' + safe(key.replace('_', ' ').capitalize()) + ':</strong> ' + text(recommendation[key]) + '</p>')
        parts.append(disclosure('Source targets, evidence, alternatives, risks and proposed validation',
            {k: v for k, v in recommendation.items() if k not in ('scope', 'justification', 'expected_benefit')}) + '</details></div>')
    parts.append(disclosure('Analyst provenance and original validation profile', {
        'profile': item['profile'], 'tooling_revision': item['tooling_revision'],
        'review_digest': item['review_digest'], 'markdown_digest': item['markdown_digest'],
        'provenance': report['provenance']}) + '<h4>Independent assessments · separately supplied</h4>'
        '<p>No authenticated human approval is established by this report. Authorship and independence are supplied '
        'attributions. Assessments are not aggregated and cannot change analyst qualification.</p>')
    if not item['assessments']:
        parts.append('<p>No independent assessments supplied for this analyst report.</p>')
    for supplied in item['assessments']:
        parts.append(f'<div class="assessment" id="{anchor("assessment", item["record_id"], supplied["id"])}"><h5>' +
            safe(ASSESSOR_LABELS[supplied['author_kind']]) + '</h5><p>' + assessment_summary(supplied) +
            '</p><details><summary>Assessment reasoning, rubric and provenance</summary>')
        parts.append(disclosure('Original assessment fields', {k: supplied[k] for k in
            ('author_kind', 'attribution', 'verdict', 'score', 'maximum')}))
        if supplied['dimensions'] is not None:
            parts.append(table('Supplied assessment dimensions — arithmetic checked, substantive judgments attributed',
                ('Dimension', 'Score', 'Assessor rationale'), [[text(name.replace('_', ' ')), text(row['score']),
                    text(row['rationale'])] for name, row in supplied['dimensions'].items()]))
        parts.append(disclosure('Supplied assessment limitations', supplied['limitations']))
        if supplied['narrative'] is not None:
            parts.append('<details><summary>Original assessment narrative · inert text</summary><pre>' +
                         safe(supplied['narrative']) + '</pre></details>')
        if supplied['rubric'] is not None:
            parts.append(disclosure('Preserved rubric context · no retrospective scoring', supplied['rubric']))
        else:
            parts.append('<p>Rubric not supplied; no rubric-compliance claim is inferred.</p>')
        if supplied['freeze'] is not None:
            timing = ('Recorded time ordering is consistent. ' if 'original_freeze_utc' in supplied['freeze'] else
                      'Freeze time not supplied; time ordering is not established. ')
            parts.append('<p>Freeze-record digest and context are consistent. ' + timing +
                'This is not trusted timestamp attestation or proof of independent authorship.</p>' +
                disclosure('Preserved freeze-record metadata', supplied['freeze']))
        else:
            parts.append('<p>Freeze evidence not supplied; preregistration is not established.</p>')
        parts.append(disclosure('Assessment document and rubric identities', supplied['provenance']) + '</details></div>')
    if item['reference_deadlines']:
        parts.append('<p class="notice">Reviewed-reference deadline(s): ' +
            ', '.join(code(value) for value in item['reference_deadlines']) +
            '. After expiration, omit this attachment and generate a base report from separately rebuilt '
            'current-availability public evidence. Original files must remain unchanged.</p>')
    parts.append('<p class="muted">Historical integration is time-limited by current-time evidence validation. '
        'A saved HTML file is a snapshot, not continuing validation. Keep analyst and assessment material private.</p></article>')
    return ''.join(parts)


def pages_overview(context, captured):
    from skill_pages import validate_context
    validate_context(context, captured)
    parts = ['<section aria-labelledby="publication"><h2 id="publication">Publication context</h2>',
        '<p>Current main configuration: ' + code(context['current']['revision']) +
        '. Evaluated revisions below retain their recorded identities. Static coverage, model-backed measurements, '
        'and diagnostic qualification answer separate questions. Missing evidence remains unknown.</p>',
        '<p><a href="#history">Benchmark history</a> · <a href="report/publication.json" download>Publication manifest</a> · '
        '<a href="report/analysis.json" download>Saved validated analysis</a></p>',
        '<details><summary>Retained evidence slots and authenticated producer provenance</summary>']
    if not context['slots']:
        parts.append('<p>No producer bundles retained. Current configuration alone is not an evaluation.</p>')
    for item in context['slots']:
        purpose = item['slot'].split('--', 1)[0]
        label = {'quality': 'Static quality coverage', 'standard': 'Standard behavioral evidence',
                 'oracle': 'Diagnostic oracle qualification', 'confirmation': 'Diagnostic confirmation'}[purpose]
        parts.append('<h3>' + safe(label) + '</h3><p>' + code(item['slot']) +
            (' · diagnostic evidence; excluded from qualified performance history.' if purpose in ('oracle', 'confirmation') else '.') +
            '</p>' + disclosure('Authenticated producer', item['provenance']))
        prefix = 'report/bundles/' + item['slot'] + '/'
        for member in sorted(item['members']):
            parts.append('<p><a href="' + safe(prefix + member) + '" download>' + safe(member) + '</a></p>')
    parts.append('</details></section>')
    return ''.join(parts)


def pages_history(context):
    parts = ['<section id="history"><h2>Benchmark history</h2><p>Native admitted ledger values are unchanged. '
        'Ledger entries do not bind a workflow run or attempt; matching public detail does not establish that missing binding. These descriptive measurements '
        'do not establish causality. Different skill, policy or dataset groups are not directly comparable. '
        'Custom-metric history and custom cross-run comparisons remain disabled.</p>']
    groups = {}
    for row in context['history']:
        groups.setdefault((row['skill'], row['policy']), {}).setdefault(row['dataset'], []).append(row)
    if not groups:
        parts.append('<p>No admitted numeric history is available.</p>')
    for (skill, policy), datasets in sorted(groups.items()):
        parts.append('<h3 id="' + anchor('history', skill, policy) + '">' + safe(skill) + ' · policy ' + code(policy) + '</h3>')
        for dataset, records in sorted(datasets.items()):
            parts.append('<details open><summary>Dataset ' + safe(dataset) + '</summary>')
            rows = []
            for row in records:
                support = (link('record', (row['record_id'],), 'Supporting public detail (matching recorded identities and values)') if row['record_id'] else
                           '<strong>Ledger only</strong> · supporting public detail unavailable')
                rows.append([code(row['revision']), text(row['date']),
                    *[text(metric['value']) for metric in row['metrics']], support])
            parts.append(table('Admitted native measurements · original score units',
                ('Evaluated revision', 'Recorded date (epoch ms)', 'Skill Lift', 'Effectiveness', 'Correctness', 'Discoverability', 'Evidence'), rows))
            parts.append('<p><a href="' + safe(records[0]['member']) + '" download>Download original data.js</a></p>'
                         '<details><summary>Exact ledger identities and values</summary>' + disclosure('Recorded measurements', records) + '</details></details>')
    parts.append('</section>')
    return ''.join(parts)


def history_chart(items):
    """Native observations on a fixed score axis; lines require direct compatibility."""
    import skill_history as history
    groups={}
    for item in items:
        if item['execution']['completed_at'] and item['record']['schema_version']==1:
            key=(item['record']['policy']['id'],item['record']['dataset']['staged_digest'])
            groups.setdefault(key,[]).append(item)
    parts=[]
    for (policy,dataset), rows in groups.items():
        rows.sort(key=lambda r:(history.date(r),r['id']))
        times=[history.timestamp(history.date(r)).timestamp() for r in rows]
        span=max(times)-min(times)
        for metric in evidence.reports.METRICS:
            title=metric+' · policy '+str(policy)+' · dataset '+str(dataset)
            parts.append('<figure><figcaption>'+safe(title)+'</figcaption><svg role="img" aria-label="'+safe(title)+'" viewBox="0 0 600 180" style="width:100%;max-width:600px"><title>'+safe(title)+'</title><desc>Points are recorded native measurements, oldest to newest. Lines connect directly comparable observations only. Exact values and dates follow in the table.</desc><path d="M40 15V150H580" fill="none" stroke="currentColor"/>')
            previous=None
            low=-1 if metric=='Skill Lift' else 0
            parts.append('<text x="5" y="25" fill="currentColor">1</text><text x="5" y="150" fill="currentColor">'+str(low)+'</text>')
            for row,t in zip(rows,times):
                val=next((m['value'] for m in row['record']['metrics'] if m['name']==metric),None)
                if val is None:
                    previous=None; continue
                x=40+540*((t-min(times))/span if span else .5); y=150-130*(val-low)/(1-low)
                if previous and history.compare(previous[0],row)[0]=='directly_comparable':
                    parts.append('<path d="M'+str(previous[1])+' '+str(previous[2])+'L'+str(x)+' '+str(y)+'" stroke="currentColor" fill="none"/>')
                parts.append('<circle cx="'+str(x)+'" cy="'+str(y)+'" r="4" fill="currentColor"><title>'+safe(history.date(row)+' · '+str(val))+'</title></circle>')
                previous=(row,x,y)
            parts.append('<text x="40" y="175" fill="currentColor">Oldest</text><text x="520" y="175" fill="currentColor">Newest</text></svg></figure>')
    return ''.join(parts)


def historical_view(value, records=None):
    import skill_history as history
    history.validate(value)
    records = records or {}
    groups = {}
    for item in value['observations']:
        groups.setdefault((item['record']['source']['skill_id'], item['class']), []).append(item)
    parts = ['<section id="evaluation-history"><h2>Evaluation history and trends</h2><p>Compact validated summaries retain reported measurements, not complete original evidence. '
             '90 days, capped at 30 observations per skill and evidence class; registered comparison baselines are protected. '
             'Different conditions remain separate. Custom metric history and comparisons remain disabled.</p>'
             '<p><a href="report/history.json" download>Download retained historical summaries</a></p>']
    if not groups:
        parts.append('<p>No historical observations retained.</p>')
    for (skill, category), items in sorted(groups.items()):
        items.sort(key=lambda r: (history.date(r), r['id']))
        parts.append('<details><summary>' + safe(skill + ' · ' + category) + ' · ' + str(len(items)) + ' observations</summary>')
        if len(items) == 1:
            parts.append('<p>One observation; a trend is not yet established.</p>')
        if category == 'standard':
            parts.append(history_chart(items))
        rows=[]
        for index,item in enumerate(items):
            r=item['record']; p=item['provenance']; metrics={m['name']:m['value'] for m in r['metrics']}
            explanation='No earlier directly comparable measurement.'
            earlier=[]
            if category=='standard':
                for previous in reversed(items[:index]):
                    status,reasons,deltas=history.compare(previous,item)
                    if status=='directly_comparable' and deltas:
                        earlier.append((previous,deltas)); break
                if earlier:
                    previous,deltas=earlier[0]
                    explanation='Compared with run ' + str(previous['provenance']['run_id']) + ': ' + '; '.join(name + ' ' + q['display'] for name,q in sorted(deltas.items()))
                    if any(q['direction']=='negative' for q in deltas.values()):
                        explanation+=' · Observed decrease—potential regression; ordinary variation remains possible.'
                elif index:
                    status,reasons,_=history.compare(items[index-1],item)
                    explanation=status + ': ' + ', '.join(reasons)
            else:
                explanation='Diagnostic observation; no performance comparison.' if category=='diagnostic' else 'Static counts and coverage; scanner provenance does not establish comparable quality changes.'
            if item['id'] in value['protected']:
                explanation += ' · Protected comparison baseline.'
            if category=='standard':
                for baseline in items:
                    if baseline['id'] in value['protected'] and baseline['id'] != item['id']:
                        status,_,deltas=history.compare(baseline,item)
                        if status=='directly_comparable' and deltas:
                            explanation+=' · Baseline run '+str(baseline['provenance']['run_id'])+': '+ '; '.join(n+' '+q['display'] for n,q in sorted(deltas.items()))
            coverage = [{'arm':a['name'], 'execution':a['execution_status'], 'coverage':a['coverage']} for a in r['arms']]
            rows.append([text(item['execution']['completed_at'] or 'Execution time unknown; admitted '+item['admitted_at']),
                         '<a href="https://github.com/thetechgy/agent-engineering-baseline/actions/runs/'+str(p['run_id'])+'/attempts/'+str(p['attempt'])+'">Run '+str(p['run_id'])+' / '+str(p['attempt'])+'</a>',
                         code(r['source']['revision']), code(r['policy']['id']),
                         *[text(metrics.get(name)) if category=='standard' else 'Not performance history' for name in evidence.reports.METRICS],
                         safe(explanation), (link('record', (item['record_id'],), 'Retained public detail') if item['record_id'] in records else '<p>Public detail unavailable; summary retained.</p>') + disclosure('Coverage and retained provenance', {'coverage':coverage,'scans':r['scans'],'availability':r['availability'],'source':r['source'],'dataset':r['dataset'],'policy':r['policy'],'provenance':p,'support':'Summary only; original diagnostic artifact possession is unknown.'})])
        headers = ('Execution completed (UTC)','Producer','Evaluated revision','Policy','Skill Lift','Effectiveness','Correctness','Discoverability','Comparison','Evidence')
        if category != 'standard':
            compact = []
            for row, item in zip(rows, items):
                r = item['record']
                if category == 'quality':
                    total = next((scan for scan in r['scans'] if scan['scanner'] == 'catalog-total'), None)
                    counts = ' · '.join(level + ': ' + str(total['severity_counts'][level]) for level in analysis.SEVERITIES) if total else 'Native counts unavailable'
                else:
                    counts = ' · '.join(a['name'] + ': ' + str(a['coverage']['scored_attempts']) + ' scored / ' + str(a['coverage']['expected_attempts']) + ' expected' for a in r['arms'])
                compact.append([*row[:3], safe(r['availability']['status']), safe(counts), row[-1]])
            rows = compact
            headers = ('Execution completed (UTC)','Producer','Evaluated revision','Coverage','Native finding counts' if category == 'quality' else 'Measurement coverage','Evidence')
        parts.append(table('Chronological observations · source-specific native values', headers, rows[-100:]))
        if len(rows)>100: parts.append('<p>Additional observations are available in the historical summary download.</p>')
        parts.append('</details>')
    parts.append('</section>')
    return ''.join(parts)


def render_report(result, captured, *, reviews=None, pages_context=None, historical=None):
    """Validate again at the rendering boundary; never accept analysis in isolation."""
    analysis.validate_analysis(result, captured)
    evidence.require(pages_context is None or reviews is None, 'Analyst attachments cannot enter Pages')
    if reviews is not None:
        import skill_report_reviews as attachments
        evidence.require(type(reviews) is attachments.ValidatedReviews, 'Validated analyst attachments required')
        reviews.check(captured)
    attached = {row['record_id']: row for row in reviews.items} if reviews is not None else {}
    records = captured.records
    csp = ("default-src 'none'; base-uri 'none'; object-src 'none'; form-action 'none'; "
           "connect-src 'none'; img-src 'none'; font-src 'none'; "
           f"style-src 'sha256-{asset_hash(CSS)}'; script-src 'sha256-{asset_hash(JS)}'")
    parts = []; size = 0

    def add(fragment):
        nonlocal size
        size += len(fragment.encode('utf-8'))
        evidence.require(size <= HTML_LIMIT, 'HTML report size exceeded')
        parts.append(fragment)

    add('<!doctype html><html lang="en"><head><meta charset="utf-8">'
        '<meta http-equiv="Content-Security-Policy" content="' + safe(csp) + '">'
        '<meta name="referrer" content="no-referrer"><meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>' + ('Skill evaluation report' if pages_context is not None else 'Private skill evaluation report') + '</title><style>' + CSS + '</style></head><body>'
        '<a class="skip" href="#main">Skip to report</a><header><p class="eyebrow">' + ('PUBLIC · CANONICAL PAGES' if pages_context is not None else 'PRIVATE · OFFLINE') + '</p>'
        '<h1>Skill evaluation report</h1>'
        '<div class="theme" id="theme-control" hidden><label for="theme">Appearance</label><select id="theme">'
        '<option value="system">System default</option><option value="light">Light</option><option value="dark">Dark</option>'
        '</select></div></header><main id="main" tabindex="-1"><section class="overview" aria-labelledby="overview">'
        '<h2 id="overview">Evidence overview</h2>')
    skills = result['skills']
    if any(record.get('kind') == 'behavioral' and 'producer_profile' in record.get('policy', {})
           and not analysis.pilot_record(record) for record in records.values()):
        add('<p class="safety"><strong>Synthetic candidate qualification.</strong> Fixed judge values test transport only. No model judges ran; candidate quality is unavailable. Candidate records are excluded from production history and cannot establish skill improvement.</p>')
    if any(record.get('custom', {}).get('purpose') == 'skill_effectiveness_control' for record in records.values()):
        add('<p class="safety"><strong>Prospective grading qualification.</strong> Native oracle fixtures exercise frozen task contracts without model inference. These are not agent results, skill benefit or production history.</p>')
    if any(analysis.pilot_record(record) and record['custom']['profile_id'] not in ('pester-effectiveness-v1', 'pester-effectiveness-v2', 'pester-effectiveness-v3', 'pester-effectiveness-v4', 'pester-effectiveness-v5', 'pester-effectiveness-v6', 'pester-effectiveness-v7', 'pester-effectiveness-v8', 'pester-effectiveness-v9', 'pester-effectiveness-v10', 'pester-effectiveness-v10-sol62', 'pester-effectiveness-v41', 'pester-effectiveness-v42', 'pester-effectiveness-v43', 'pester-effectiveness-v44', 'pester-effectiveness-v45', 'pester-effectiveness-v46', 'pester-effectiveness-v47', 'pester-effectiveness-v48', 'pester-effectiveness-v49', 'pester-effectiveness-v50', 'pester-effectiveness-v51') for record in records.values()):
        add('<p class="safety"><strong>Opt-in CLI compatibility evidence.</strong> Native grading controls and CLI observations retain separate purposes. No model judging or history publication is enabled; one pair cannot establish general skill effectiveness.</p>')
    add(executive_summary(result, records, pages=pages_context))
    add('</section>')
    add(review_first(result, records, attached))
    if pages_context is not None:
        add(pages_overview(pages_context, captured))
    add(
        '<details><summary>How to read the measures</summary><p>Evaluator-reported (native) metrics use the evaluator\'s original score units. '
        'Skill Lift is its with-minus-without difference. Grading criteria (rubric) and mandatory checks (gates) record separate outcomes. '
        'Effectiveness, Correctness and Discoverability are with-skill rubric dimensions; corresponding without-skill '
        'headline dimensions are not supplied by this public contract. Values are preserved, not recomputed from '
        'rounded case scores. Case deltas use descriptive arm means only where all planned attempts are scored. '
        'A positive delta is higher, a negative delta is lower; neither explains why. Mandatory gates are separate from rubric passes. '
        'Unknown counts, scores and gates stay unknown.</p></details>')
    for skill in skills:
        name = skill['skill']
        add(f'<section class="skill" id="{anchor("skill", name)}"><h2>' + safe(name) + '</h2>' +
            '<p>' + safe(coverage_label(skill)) + '</p><details class="skill-results"><summary>Results and supporting evidence</summary>')
        if not any(r['measured'] for r in skill['behavioral_results']):
            add('<p class="notice"><strong>Unmeasured.</strong> No supplied model-backed measurement. Configuration and offline fixture replay do not establish skill benefit or harm.</p>')
        for config in skill['configurations']:
            suite = config['suite']
            label = ('Current main inventory' if pages_context['current']['inventory_record_id'] in config['inventory_record_ids'] else 'Older inventory snapshot') if pages_context is not None else 'Inventory snapshot'
            add('<p>' + label + ': ' + (count(suite['case_count'], 'configured case') + ' per arm' if suite else 'No behavioral suite configured') +
                '. Source owner: ' + text(config['source']['owner']) + '.</p>' + disclosure('Configuration identity and source snapshot', config))
        skill_reviews = [row for row in attached.values() if row['skill'] == name]
        if skill_reviews:
            for row in skill_reviews:
                add(interpretation(row))
        for run in skill['behavioral_results']:
            if pages_context is not None:
                record = records[run['record_id']]
                purpose = ('Retrospective retained-submission grading' if evidence.campaign_purpose(record.get('custom',{}).get('purpose')) and evidence.replay_purpose(record['custom']['purpose']) else 'Prospective exploratory cohort' if (record.get('custom', {}).get('purpose') == 'skill_effectiveness' or evidence.campaign_purpose(record.get('custom', {}).get('purpose')) and record['custom']['purpose'].endswith('-live')) else 'Diagnostic oracle qualification' if evidence.campaign_purpose(record.get('custom', {}).get('purpose')) or record.get('custom', {}).get('purpose') in ('oracle_qualification', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_control', 'skill_effectiveness_probe') else
                           'Diagnostic confirmation' if record['policy']['attempts']['mode'] == 'confirmation' else 'Standard behavioral evidence')
                add('<p><strong>' + purpose + '</strong></p>')
            add(behavioral(run, records))
        for run in skill['static_results']:
            add(static_result(run, records))
        if not skill['static_results']:
            add('<p>Static scan evidence not supplied for this skill; no clean-scan claim is made.</p>')
        add('<details><summary>Cross-run comparison status and evidence</summary>' + comparisons(skill) + '</details></details></section>')
    if pages_context is not None:
        add(pages_history(pages_context) + (historical_view(historical, captured.records) if historical is not None else ''))
    add('<section id="provenance"><h2>Source details</h2><details><summary>Report provenance and validation boundaries</summary><p>Presentation method ' + code(METHOD) +
        '; analysis method ' + code(result['method_version']) +
        ('; public schemas 1/2 and analysis schema 2. Analysis semantic digest ' if result['schema_version'] == 2 else
         '; public and analysis schema version 1. Analysis semantic digest ') +
        code(evidence.identity(result)) + '.</p><p>Saved analysis was independently rebuilt against captured public originals before rendering. '
        'Canonical record identities preserve semantic content; raw-byte digests preserve the exact supplied files. '
        'These bindings do not attest remote execution. No local input paths, generation timestamp, prompts or private trajectories are embedded. '
        'Link identities are shortened for readability; exact identities remain in the evidence disclosures. '
        'Inventory snapshots and evaluated sources retain separate identities; current configuration does not rewrite historical runs.</p></details>')
    for rid, record in sorted(records.items()):
        if record['kind'] == 'inventory':
            add(f'<details id="{anchor("record", rid)}"><summary>Inventory record ' + safe(short_identity(rid)) + '</summary>' +
                disclosure('Validated inventory', record) + '</details>')
    add(disclosure('Input manifests, raw digests and record identities', result['input_provenance']) +
        disclosure('Analyzer comparison scope', result['comparison_scope']))
    add(disclosure('Exact qualification status', {'quality_qualification': 'not_quality_qualified'}))
    add('<details><summary>Model-generated recommendations and assessment boundaries</summary><p>' + count(len(attached),
        'independently validated analyst report') + ' attached. All deterministic investigation priorities above remain fixed descriptions '
        'of existing findings and next-step codes. Analyst qualification: ' + presentation_label('not_quality_qualified', STATUS_LABELS) + '. ' +
        ('Analyst attachments are excluded from canonical Pages. ' if pages_context is not None else 'Automated publication is ineligible. ') +
        'Supplied AI or human assessments are separately attributed opinions; structural validation, '
        'rubric arithmetic and self-declared approval do not establish authenticated human review or authorize action.</p>' +
        ('<p>This public report uses retained validated projections. It requires no external assets, analytics or network requests. ' if pages_context is not None else
         '<p>Keep this file private. It requires no server, external assets, analytics or network requests. ') +
        'Appearance follows the system unless changed for this open document. All evidence is readable without JavaScript; '
        'expand disclosures for detailed support.</p></details></section></main><footer>' + ('Public canonical report · retained validated inputs' if pages_context is not None else 'Private evidence report · supplied inputs only') + '</footer>'
        '<script>' + JS + '</script></body></html>')
    return ''.join(parts).encode('utf-8')


def generate(inputs, saved_analysis, output=None, *, analyst_reviews=()):
    captured = analysis.capture_inputs(inputs)
    directories = {}; states = {}; members = {}; budget = evidence.ReadBudget()
    saved_path = evidence.safe_path(saved_analysis, directory_identities=directories)
    raw = evidence.read_bytes(saved_path, limit=analysis.JSON_LIMIT, budget=budget,
        directory_identities=directories, directory_states=states, file_states=members)
    result = evidence.parse_json(raw, limit=analysis.JSON_LIMIT)
    guard = evidence.input_guard(directories, states, members, budget)
    guard()
    reviews = None
    if analyst_reviews:
        import skill_report_reviews as attachments
        reviews = attachments.load(analyst_reviews, captured)
    rendered = render_report(result, captured, reviews=reviews) if reviews is not None else render_report(result, captured)
    return evidence.write_outputs({}, output, input_paths=(*captured.roots, saved_path.parent,
            *(reviews.roots if reviews is not None else ())),
        input_guards=(*captured.guards, guard, lambda: analysis.check_capture(captured),
            *((lambda: reviews.check(captured),) if reviews is not None else ())), rendered={'report.html': rendered})


class PrivateParser(argparse.ArgumentParser):
    def error(self, message):
        self.exit(2, 'Report arguments rejected; use --help for the supported interface.\n')


def main(argv=None):
    parser = PrivateParser(description=__doc__)
    parser.add_argument('--input', type=Path, action='append', required=True, help='Validated public bundle; repeat for additional roots')
    parser.add_argument('--analysis', type=Path, required=True, help='Saved analysis.json for exactly these bundles')
    parser.add_argument('--output', type=Path, help='New private directory outside checkout and inputs')
    parser.add_argument('--analyst-review', type=Path, action='append', default=[],
                        help='Private analyst attachment descriptor; at most one per selected record')
    args = parser.parse_args(argv)
    try:
        destination = generate(args.input, args.analysis, args.output, analyst_reviews=args.analyst_review)
    except CONTRACT_ERRORS:
        if args.analyst_review:
            parser.exit(1, 'Analyst report inputs rejected; no HTML report is ready. '
                'Omit --analyst-review for a base report with valid current-availability inputs.\n')
        raise
    print(destination)
    return destination


if __name__ == '__main__':
    try:
        main()
    except CONTRACT_ERRORS:
        print('Report contract rejected; no HTML report is ready.', file=sys.stderr)
        sys.exit(1)
