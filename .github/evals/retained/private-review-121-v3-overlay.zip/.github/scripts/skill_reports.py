#!/usr/bin/env python3
"""CI report checks and data-only benchmark-action handoff; no evaluation/scoring."""

import argparse
import hashlib
import html
import json
import math
import os
from pathlib import Path
import re
import shutil
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))


POLICY = {
    "evaluator_revision": "ac0a04905100acdafc6c95829311a9739c340ff6",
    "harbor": "0.13.2",
    "docker_compose": "5.8.0",
    "codex": "0.171.0",
    "python": "3.13",
    "model": "gpt-6.2-sol",
    "provider": "openai",
    "environment": "docker",
    "grading": "default",
    "concurrency": 2,
    "timeout_multiplier": 2.0,
    "standard_attempts": 1,
    "baseline": True,
    "stop_on_pass": False,
}
METRICS = {
    "Skill Lift": ("lift", "overall", "delta"),
    "Effectiveness": ("dimensions_with_skill", "effectiveness", "score"),
    "Correctness": ("dimensions_with_skill", "correctness", "score"),
    "Discoverability": ("dimensions_with_skill", "discoverability", "score"),
}
MODES = {"standard": POLICY["standard_attempts"], "confirmation": 3}
PATCH = ".github/patches/skillevaluator-v0.3.0-pin-codex.patch"
RETAINED_GH_REVISION = "63837fb778d6a39f02be0ce76ff89f2bc8d74bdc"
GH_TASK_BUILD = {
    "base_image": "python:3.12-slim-trixie@sha256:b18b261e1b4974b4f321451ad5251ded85abb22c2b8b262da527dda1d031ab30",
    "apt_snapshot": "20261103T000000Z",
    "apt_packages": {
        "git": "1:2.47.3-0+deb13u1",
        "jq": "1.7.1-6+deb13u4",
        "nodejs": "20.19.2+dfsg-1+deb13u3",
        "npm": "9.2.0~ds1-3",
        "ca-certificates": "20250419+deb13u1",
    },
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path, limit=8 * 1024 * 1024):
    require(path.is_file() and not path.is_symlink(), f"Missing or linked JSON report: {path.name}")
    require(path.stat().st_size <= limit, f"Oversized JSON report: {path.name}")
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def summary(lines):
    text = "\n".join(lines) + "\n"
    print(text)
    if destination := os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(destination, "a", encoding="utf-8") as stream:
            stream.write(text)


def outputs(**values):
    with open(os.environ["GITHUB_OUTPUT"], "a", encoding="utf-8") as stream:
        for key, value in values.items():
            require("\n" not in str(value) and "\r" not in str(value), "Unsafe job output")
            stream.write(f"{key}={value}\n")


def regular_tree(root, *, excluded_dirs=(), excluded_links=()):
    """Inspect every entry without following links or hiding traversal errors."""
    require(root.resolve() == root.absolute() and stat.S_ISDIR(root.lstat().st_mode),
            "Expected a real directory with no linked path components")
    pending = [root]
    files = []
    while pending:
        with os.scandir(pending.pop()) as entries:
            for entry in entries:
                relative = Path(entry.path).relative_to(root)
                metadata = entry.stat(follow_symlinks=False)
                mode = metadata.st_mode
                link_or_reparse = stat.S_ISLNK(mode) or bool(
                    getattr(metadata, "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
                )
                if entry.name in excluded_dirs:
                    require(stat.S_ISDIR(mode) and not link_or_reparse,
                            f"Linked or invalid excluded runtime directory: {relative}")
                    continue  # Never inspect or publish excluded runtime directories.
                if relative in excluded_links:
                    require(link_or_reparse, f"Expected linked input: {relative}")
                    continue  # Recognized generated link; never inspect its target.
                require(not link_or_reparse and (stat.S_ISDIR(mode) or stat.S_ISREG(mode)),
                        f"Linked or special input: {relative}")
                if stat.S_ISDIR(mode):
                    pending.append(Path(entry.path))
                else:
                    files.append(Path(entry.path))
    return files


def catalog_preflight(workspace):
    regular_tree(workspace / ".apm/skills")
    names = sorted(path.parent.name for path in (workspace / ".apm/skills").glob("*/SKILL.md"))
    require(bool(names), "No local skills found")
    for name in names:
        local_skill(workspace, name)
    return names


def local_skill(workspace, name, *, dataset=False):
    require(bool(re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", name)) and len(name) <= 64,
            "skill must be a local skill name, not a path")
    path = workspace / ".apm/skills" / name
    require(path.exists(), "Selected local skill does not exist")
    regular_tree(path)
    require((path / "SKILL.md").is_file() and not (path / "SKILL.md").is_symlink(),
            "Selected local skill has no authored SKILL.md")
    if dataset:
        source = path / "evals/evals.json"
        require(source.is_file() and source.resolve() == source.absolute(),
                "Selected skill requires authored evals/evals.json")
    return path


def benchmark_skill(workspace, name, root=None):
    """Resolve the existing upstream overlay and the bounded local pilot overlay."""
    if name == 'powershell-pester-6':
        import pester_evaluations as pester
        local_skill(workspace, name)
        pester.dataset(workspace)
        if root is not None and (root / 'bundle' / name).exists():
            staged = root / 'bundle' / name
            regular_tree(staged)
            for relative, digest in pester.manifest(workspace / '.apm/skills' / name).items():
                require(hashlib.sha256((staged / relative).read_bytes()).hexdigest() == digest,
                        'Staged local skill drift')
            return staged
        return workspace / pester.OVERLAY
    if name != "gh":
        return local_skill(workspace, name, dataset=True)
    import gh_evaluations as gh
    gh.dataset(workspace)
    regular_tree(workspace / gh.DEPLOYED)
    if root is not None:
        gh.verify_skill(workspace)
        gh.verify_competing(workspace)
    if root is not None and (root / "bundle/gh").exists():
        staged = root / "bundle/gh"
        regular_tree(staged)
        for member in gh.SKILL_FILES:
            require((staged / member).read_bytes() == (workspace / gh.DEPLOYED / member).read_bytes(),
                    "Staged upstream skill drift")
        return staged
    return workspace / gh.OVERLAY


def benchmark_options(name):
    """Execution routing only; this does not define scores or publication schemas."""
    return {
        'gh': {'grading_mode': 'default_plus_custom', 'workspace_mode': 'group', 'diagnostic_only': False},
        'powershell-pester-6': {'grading_mode': 'custom_only', 'workspace_mode': 'isolated', 'diagnostic_only': True},
    }.get(name, {'grading_mode': 'default', 'workspace_mode': 'isolated', 'diagnostic_only': False})


def prepare_benchmark(workspace, root, name):
    source = benchmark_skill(workspace, name)
    root = root.absolute()
    require(root.resolve() == root and not root.is_relative_to(workspace), 'Unsafe preparation root')
    if name == 'gh':
        import gh_evaluations as gh
        source = gh.stage(workspace, root / 'bundle' / name)
    elif name == 'powershell-pester-6':
        import pester_evaluations as pester
        source = pester.stage(workspace, root / 'bundle' / name)
    return source


def benchmark_policy(name, *, gh_revision=RETAINED_GH_REVISION):
    if benchmark_options(name)['diagnostic_only']:
        return {**POLICY, 'grading': 'custom_only', 'workspace_mode': 'isolated', 'diagnostic_only': True}
    if name != "gh":
        return POLICY
    from gh_evaluations import UPSTREAM

    require(gh_revision in (RETAINED_GH_REVISION, UPSTREAM), "Unreviewed upstream attribution")
    return {**POLICY, "grading": "default_plus_custom", "upstream_revision": gh_revision,
            "deterministic_gate": 3, "workspace_mode": "group",
            "fixture_boundary": "root-broker-unprivileged-agent-v1", "authorization_policy": "per-case-allowlist-v1",
            "task_source": "native_harbor", "task_build": GH_TASK_BUILD,
            "competing_revision": "1683f50e94c9fd489191f73d7c8f7e2bd871bd0c"}


RELEASED_STATIC_VERSIONS = ('0.9.0', '1.0.1', '1.2.1')


def released_static_results(payload):
    """Validate a released static contract in its exact owning runtime."""
    import importlib.metadata
    require(payload.get('version') in RELEASED_STATIC_VERSIONS
            and importlib.metadata.version('skillevaluator') == payload['version'],
            'Static report requires its owning runtime')
    from skillevaluator.reporting.retained import retained_results
    return retained_results(payload, allowed_tiers={1})


def catalog_report(workspace, root):
    """Only ordinary, fully reported native findings may be advisory."""
    names = catalog_preflight(workspace)
    data = read_json(root / "reports/catalog-summary.json")
    entries = data["skills"]
    require(sorted(item["name"] for item in entries) == names, "Incomplete catalog report")
    require(type(data["total"]) is int and data["total"] == len(names), "Incorrect catalog cardinality")
    exit_code = int((root / "catalog.exit").read_text())
    errors = []
    lines = ["## Native collection and dataset contracts", ""]
    datasets = 0
    if exit_code not in (0, 1):
        errors.append(f"Catalog exited with infrastructure status {exit_code}")
    for item in entries:
        name = item["name"]
        status = "invalid report"
        try:
            require(type(item.get("passed")) is bool, "Missing native pass/fail status")
            require(item.get("reason", "") == ("" if item["passed"] else "validation failed"),
                    "Catalog recorded a configuration/runtime failure")
            filename = item["json_report"]
            require(bool(re.fullmatch(r"skillevaluator-output-[0-9]{14}\.json", filename)),
                    "Unexpected per-skill report filename")
            report = read_json(root / "reports" / name / filename)
            status = report["overall_status"]
            require(status in ("passed", "failed", "incomplete"), "Unknown native report status")
            require(type(report["overall_passed"]) is bool and report["overall_passed"] == item["passed"],
                    "Inconsistent catalog/per-skill result")
            require(report["skills"][0]["name"] == name and len(report["skills"]) == 1,
                    "Report skill identity mismatch")
            require(type(report["total_validators"]) is int
                    and report["total_validators"] == len(report["results"]) > 0, "Missing validator evidence")
            require(all(row.get("status") in ("passed", "failed", "incomplete", "skipped")
                        for row in report["results"]), "Unknown validator status")
            require(isinstance(report["incomplete_scans"], list), "Missing evidence status")
            require(all(isinstance(name, str) and name for name in report["incomplete_scans"]),
                    "Invalid incomplete scanner names")
            if report.get("version") in RELEASED_STATIC_VERSIONS:
                released_static_results(report)
            else:
                expected_status = "incomplete" if report["incomplete_scans"] else (
                    "passed" if report["overall_passed"] else "failed")
                require(status == expected_status, "Inconsistent native status/pass/evidence")
            counts = [report["severity_counts"][severity] for severity in ("critical", "high", "medium", "low")]
            require(all(type(count) is int and count >= 0 for count in counts), "Invalid finding counts")
            for suffix in (".md", ".html"):
                sibling = root / "reports" / name / Path(filename).with_suffix(suffix)
                require(sibling.is_file() and not sibling.is_symlink() and sibling.stat().st_size > 0,
                        "Missing human-readable report")
        except (ValueError, KeyError, TypeError, IndexError, OSError):
            errors.append(f"{name}: Native report missing or invalid; inspect native JSON, Markdown and HTML evidence.")
        dataset = workspace / ".apm/skills" / name / "evals/evals.json"
        if dataset.exists() or dataset.is_symlink():
            datasets += 1
            try:
                benchmark_skill(workspace, name)
                require(int((root / "datasets" / f"{name}.exit").read_text()) == 0,
                        "Strict eval dataset validation failed")
                checks = read_json(root / "datasets" / f"{name}.json")
                require(isinstance(checks, list) and checks and all(row["status"] == "ok" for row in checks),
                        "Invalid strict-validation report")
            except (ValueError, KeyError, TypeError, OSError):
                errors.append(f"{name}: Strict eval dataset validation failed; inspect dataset reports and collection steps.")
    require(type(data["failed"]) is int and data["failed"] == sum(not item["passed"] for item in entries),
            "Incorrect failure count")
    if (exit_code == 0) != (data["failed"] == 0):
        errors.append("Catalog exit status disagrees with its reports")
    if errors:
        lines += ["**Infrastructure / contract checks failed. Findings remain unresolved.**", ""] + [f"- {error}" for error in errors]
    else:
        lines += [f"Collection status: native catalog exit/report checks and {datasets} strict dataset " + ('contract' if datasets == 1 else 'contracts') +
                  f" passed for {len(names)} local skills.",
                  "Findings are advisory; public projection and upload are reported separately."]
    lines += ["", "The skill-quality artifact retains native JSON, Markdown, HTML and dataset evidence. A richer summary cannot override infrastructure failures."]
    summary(lines)
    require(not errors, "Skill evaluation infrastructure or dataset contract failed")


def metric_rows(agent):
    rows = []
    for name, path in METRICS.items():
        value = agent
        for field in path:
            value = value[field]
        require(type(value) in (int, float) and math.isfinite(value), f"Invalid {name} value")
        require((-1 if name == "Skill Lift" else 0) <= value <= 1, f"Out-of-range {name}")
        rows.append({"name": name, "unit": "score", "value": value})
    return rows


def usage_observations(run):
    """Allowlisted native observations; partial subtotals never imply billed totals."""
    fields = ("n_input_tokens", "n_cache_tokens", "n_output_tokens", "cost_usd")
    arms = {}
    for arm in ("with-skill", "without-skill"):
        records = {}
        conflicts = set()
        unreadable = 0
        for path in sorted((run / "codex" / arm / "trials").glob("*/result.json")):
            try:
                require(path.resolve().is_relative_to(run), "Escaping trial report")
                data = read_json(path)
                trial = data["id"]
                require(type(trial) is str and trial, "Missing trial identity")
                context = data.get("agent_result") or {}
                require(isinstance(context, dict), "Invalid optional agent usage")
                selected = {field: context.get(field) for field in fields}
                if trial in records and records[trial] != selected:
                    conflicts.add(trial)
                records[trial] = selected
            except (ValueError, KeyError, TypeError, OSError):
                unreadable += 1
        observations = {}
        for field in fields:
            values = [record[field] for trial, record in records.items() if trial not in conflicts
                      if type(record.get(field)) in (int, float)
                      and math.isfinite(record[field]) and record[field] >= 0
                      and (field == 'cost_usd' or type(record[field]) is int)
                      and (field != 'n_cache_tokens' or type(record.get('n_input_tokens')) is int
                           and record[field] <= record['n_input_tokens'])]
            total = sum(values) if values else None
            require(total is None or math.isfinite(total), 'Invalid usage subtotal')
            observations[field] = {'subtotal': total, 'reporting_trials': len(values)}
        arms[arm] = {'recorded_trials': len(records), 'conflicting_trials': len(conflicts),
                     'unreadable_records': unreadable, 'fields': observations}
    return {'arms': arms, 'cost_basis': 'native_estimate', 'actual_billed_cost_usd': None,
            'judge_usage': None, 'preflight_usage': None, 'cache_included_in_input': True}


def usage_summary(run):
    lines = ["", "### Native agent usage", "",
             "Reported subtotals only; cache tokens are included in input tokens. Missing values remain unknown.",
             "Cost may be estimated by Harbor and excludes usage not reported here, including judging/preflight.", "",
             "| Arm | Field | Reported subtotal | Trials reporting / recorded |", "| --- | --- | --- | --- |"]
    for arm, data in usage_observations(run)['arms'].items():
        for field, observed in data['fields'].items():
            total = observed['subtotal']
            text = 'unknown' if total is None else f'{total:.6f}' if field == 'cost_usd' else str(total)
            lines.append(f"| {arm} | {field} | {text} | {observed['reporting_trials']} / {data['recorded_trials']} |")
    return lines


def operation_receipt(workspace, root, name, mode, outcome, destination):
    """Operational accounting only; this function never admits evaluation evidence."""
    import time
    receipt = {'schema_version': 1, 'kind': 'benchmark_operation', 'skill': name, 'mode': mode,
               'run_id': int(os.environ['GITHUB_RUN_ID']), 'attempt': int(os.environ['GITHUB_RUN_ATTEMPT']),
               'revision': os.environ['GITHUB_SHA'], 'request_id': os.environ.get('REQUEST_ID', ''),
               'inference_step_outcome': outcome, 'observed_epoch': int(time.time()),
               'inference_step_seconds': None, 'usage': None, 'usage_status': 'unavailable',
               'history_admission': 'not_established_by_operational_receipt'}
    started, finished = os.environ.get('INFERENCE_STARTED', ''), os.environ.get('INFERENCE_FINISHED', '')
    if started.isdecimal() and finished.isdecimal() and 0 <= int(finished) - int(started) <= 10800:
        receipt['inference_step_seconds'] = int(finished) - int(started)
    try:
        from skillevaluator.evaluation import EvaluationService
        run = EvaluationService().discover_latest_results(benchmark_skill(workspace, name, root), root / 'results')
        require(run is not None and run.resolve().is_relative_to(root.resolve()), 'Native usage unavailable')
        receipt['usage'] = usage_observations(run)
        receipt['usage_status'] = 'reported_subtotals'
    except (ValueError, KeyError, TypeError, OSError):
        pass
    write_json(destination, receipt)


def validate_benchmark_versions(versions):
    require(versions["python"].startswith("3.13.") and versions["skillevaluator"] == "0.3.0"
            and versions["harbor"] == POLICY["harbor"]
            and versions.get("docker_compose") == POLICY["docker_compose"],
            "Installed evaluator/runtime version mismatch")


def recover_benchmark(workspace, root, name, mode, outcome, *, evidence_profile=None, environment="docker"):
    """Collect retained trials with the pinned native collector; never certify a run."""
    from skillevaluator.tier3.case_ids import validate_case_ids
    from skillevaluator.tier3.dataset_utils import load_dataset_entries
    from skillevaluator.tier3.harbor.collector import collect_harbor_results
    from skillevaluator.tier3.results_location import run_directory_sort_key

    recovery_model = POLICY["model"]
    profile_metadata = None
    retained_provenance = {}
    primary_outcome = outcome
    if evidence_profile is not None:
        import benchmark_evidence
        import evaluator_profiles
        p = benchmark_evidence.profile(evidence_profile)
        evaluator_profiles.runtime(read_json(root / 'versions.json'), owning=True)
        require(evaluator_profiles.runtime(read_json(root / 'versions.json'))['id'] == p['producer'],
                'Recovery producer mismatch')
        original = read_json(root / 'provenance.json')
        profile_metadata = original['benchmark']
        recovery_model = original['policy']['model']
        require(original.get('schema_version') == 1 and original.get('skill') == name
                and original.get('mode') == mode, 'Recovery evidence identity mismatch')
        retained_provenance = {key:original[key] for key in
            ('skill', 'mode', 'revision', 'policy', 'patch_sha256', 'dataset_digest') if key in original}
        primary_outcome = original.get('evaluation_outcome', outcome)
        require(primary_outcome in {'success','failure','cancelled','skipped'}, 'Invalid primary outcome')
        require(benchmark_evidence.metadata(profile_metadata) is p, 'Recovery policy mismatch')
    skill = benchmark_skill(workspace, name, root)
    require(outcome in {"success", "failure", "cancelled", "skipped"}, "Invalid evaluation outcome")
    root = root.absolute()
    require(root.resolve() == root and not root.is_relative_to(workspace),
            "Recovery must use a real directory outside the checkout")
    root.mkdir(parents=True, exist_ok=True)
    regular_tree(root, excluded_dirs={"_harbor-jobs", "_harbor-tasks"},
                 excluded_links={Path("results") / name / "latest"})
    if outcome == "success":
        return  # Successful native collection/reporting remains authoritative.

    # This existing allowlisted metadata file also covers interruptions before a run exists.
    write_json(root / "provenance.json", {
        **retained_provenance,
        "schema_version": 1, "status": "incomplete", "evaluation_outcome": primary_outcome,
        "diagnostic_only": True,
        **({"benchmark": profile_metadata} if profile_metadata is not None else {}),
    })
    summary([f"## {name}: incomplete benchmark", "",
             f"Evaluation outcome: {outcome}. Recovered diagnostics cannot enter benchmark history."])
    results = root / "results" / name
    if not results.is_dir():
        return
    entries = load_dataset_entries(skill / "evals/evals.json")
    case_ids = validate_case_ids(entry.get("id") for entry in entries)
    cases = len(case_ids)
    for run in sorted(results.iterdir()):
        if run.name == "latest":
            continue
        require(run.is_dir() and not run.is_symlink(), "Unexpected native run entry")
        jobs = run / "_harbor-jobs"
        result = run / "result.json"
        if result.exists():
            require(result.is_file() and not result.is_symlink(),
                    f"Missing or linked JSON report: {result.name}")
            if run_directory_sort_key(run, require_completed_result=True) is not None:
                continue  # Preserve complete reports already produced by native collection.
        if not jobs.exists():
            continue  # No retained diagnostics are available for native collection.
        require(jobs.is_dir() and not jobs.is_symlink(), "Linked or invalid retained jobs directory")
        if environment != "docker" and result.exists() and not any(jobs.iterdir()):
            # The launcher already recorded the preflight failure. With no jobs
            # to collect, preserve its cause and mark the run unrecoverable.
            write_json(result, {**read_json(result), "report_status": "incomplete", "diagnostic_only": True})
            continue
        collected = collect_harbor_results(
            skill_name=name, agents=["codex"], output_dir=run, jobs_dir=jobs,
            n_attempts=MODES[mode], stop_on_pass=False, expected_cases=cases,
            expected_case_ids=case_ids,
            expected_trials=cases * MODES[mode], env_mode=environment,
            agent_models={"codex": {"model": recovery_model, "source": "cli"}},
            **({"grading_mode": benchmark_options(name)["grading_mode"], "recover_interrupted": True}
               if environment != "docker" else {}),
        )
        # Native diagnostics may include completed trials but are never a completed evaluation.
        write_json(run / "result.json", {**collected, "skill_name": name,
                   "report_status": "incomplete", "diagnostic_only": True})


def benchmark_report(workspace, root, name, mode, destination):
    # These native APIs validate run identity/completeness; never imported by the publisher.
    from skillevaluator.evaluation import EvaluationService
    from skillevaluator.source_identity import evaluated_source_revision

    capture_benchmark_custom(workspace, root, name)
    if benchmark_options(name)['diagnostic_only']:
        return diagnostic_benchmark_report(workspace, root, name, mode)

    if (root / "provenance.json").exists():
        require(read_json(root / "provenance.json").get("status") != "incomplete",
                "Incomplete benchmark recovery cannot produce history metrics")
    skill = benchmark_skill(workspace, name, root)
    service = EvaluationService()
    run = service.discover_latest_results(skill, root / "results")
    require(run is not None and run.is_relative_to((root / "results").resolve()),
            "No complete external native result; inspect raw artifacts")
    result = read_json(run / "result.json")
    require(service.failure_reason(result) is None and result["report_status"] == "complete",
            "Incomplete or failed native benchmark")
    require((run / "report.html").is_file() and not (run / "report.html").is_symlink(),
            "Missing native HTML benchmark report")
    validate_benchmark_versions(read_json(root / "versions.json"))
    require(result["skill_name"] == name, "Result skill mismatch")
    config = result["run_config"]
    agent = result["agents"]["codex"]
    require(set(result["agents"]) == {"codex"} and agent["model"] == POLICY["model"], "Agent model mismatch")
    require(config["provider"] == {"name": "openai", "model": POLICY["model"]}, "Provider/model mismatch")
    require(config["judge"]["model"] == POLICY["model"] and config["judge"]["provider"] == "openai"
            and config["judge"]["override_applied"] is True, "Judge model mismatch")
    harbor = config["harbor"]
    require(harbor["environment"]["value"] == "docker" and harbor["n_attempts"] == MODES[mode]
            and harbor["n_concurrent"] == 2 and harbor["stop_on_pass"] is False, "Attempt/runtime policy mismatch")
    require(harbor["timeout_multiplier"] == POLICY["timeout_multiplier"], "Timeout policy mismatch")
    require(config["grading"]["mode"] == benchmark_policy(name)["grading"], "Grading policy mismatch")
    revision = os.environ["GITHUB_SHA"]
    require(evaluated_source_revision(config["evaluated_source"]) == revision, "Evaluated source mismatch")
    cases = result["dataset_summary"]["total_tasks"]
    require(type(cases) is int and cases > 0, "Missing dataset cardinality")
    for arm in ("with_skill", "without_skill"):
        condition = agent["conditions"][arm]
        require(condition["execution_status"] == "succeeded" and not condition["execution_errors"]
                and condition["scored_attempts"] == condition["expected_attempts"] == cases * MODES[mode],
                "Incomplete with-skill/baseline coverage")
    policy = benchmark_policy(name)
    if name == "gh":
        import gh_evaluations as gh
        gh.verify_skill(workspace)
        policy = benchmark_policy(name, gh_revision=gh.UPSTREAM)
        expected_ids = [entry["id"] for entry in gh.dataset(workspace)]
        require(cases == len(expected_ids), "Diagnostic subset cannot publish benchmark history")
        if (root / "selection.json").exists():
            selection = read_json(root / "selection.json")
            require(selection["case_ids"] == expected_ids and (mode != "standard" or not selection["diagnostic_only"]),
                    "Diagnostic selection cannot publish benchmark history")
        numeric_excerpts = None
        if (root / 'custom-metric-capture.json').exists():
            import skill_evidence as evidence
            admitted = evidence.normalize_behavioral(root, name, run.name, workspace, native_layout=True)
            capture = evidence.read_json(root / evidence.CUSTOM_CAPTURE)
            numeric_excerpts = evidence.custom_numeric_excerpts(capture, evidence.custom_contract(name, workspace)[1])
            for guard in evidence.record_guards(admitted): guard()
        deterministic = (gh.deterministic_gate(run, expected_ids, MODES[mode]) if numeric_excerpts is None else
                         gh.deterministic_gate(run, expected_ids, MODES[mode], numeric_excerpts=numeric_excerpts))
        write_json(root / "deterministic.json", {"trials": deterministic})
    rows = metric_rows(agent)
    provenance = {
        "schema_version": 1, "skill": name, "mode": mode, "revision": revision,
        "policy": policy, "patch_sha256": hashlib.sha256((workspace / PATCH).read_bytes()).hexdigest(),
        "dataset_digest": result["dataset_digest"], "metrics": rows,
    }
    # Reuse the exact same allowlist contract on both sides of the artifact boundary.
    validate_metrics(provenance, workspace, name, revision, mode=mode)
    write_json(root / "provenance.json", provenance)
    lines = [f"## {name}: {mode} benchmark", "", f"{cases * MODES[mode] * 2} task trials; both arms complete.", "",
             "| Metric | Score |", "| --- | --- |"]
    lines += [f"| {row['name']} | {row['value']:.4f} |" for row in rows]
    lines += ["", f"Dataset: `{provenance['dataset_digest']}`", f"Source: `{revision}`",
              "", "Confirmation runs are diagnostic; only successful standard runs dispatched on main publish history."]
    lines += usage_summary(run)
    if name == "gh":
        lines += ["", "Mandatory deterministic with-skill gate: passed for every trial. "
                  "Baseline failures remain comparison evidence; separate scores are in deterministic.json."]
    summary(lines)
    if mode == "standard":
        write_json(destination / "metrics.json", provenance)


def diagnostic_benchmark_report(workspace, root, name, mode):
    """Validate native custom-only completion without standard-score projection."""
    from skillevaluator.evaluation import EvaluationService
    from skillevaluator.source_identity import evaluated_source_revision

    require(mode == 'confirmation', 'Diagnostic-only suite cannot enter standard history')
    if (root / 'provenance.json').exists():
        require(read_json(root / 'provenance.json').get('status') != 'incomplete',
                'Interrupted diagnostic recovery cannot certify a complete comparison')
    skill = benchmark_skill(workspace, name, root)
    service = EvaluationService()
    run = service.discover_latest_results(skill, root / 'results')
    require(run is not None and run.is_relative_to((root / 'results').resolve()),
            'No complete diagnostic comparison; retained trials are inconclusive')
    result = read_json(run / 'result.json')
    require(service.failure_reason(result) is None and result['report_status'] == 'complete',
            'Diagnostic comparison is incomplete or unscoreable')
    released = (root / 'native-preparation.json').exists()
    environment = 'docker'
    if released:
        from benchmark_native import DIAGNOSTIC_BACKEND, validate_preparation

        validate_preparation(workspace, root, name, mode, os.environ['GITHUB_SHA'])
        environment = DIAGNOSTIC_BACKEND
    else:
        validate_benchmark_versions(read_json(root / 'versions.json'))
    require(result['skill_name'] == name and set(result['agents']) == {'codex'}, 'Diagnostic identity mismatch')
    config = result['run_config']
    require(config['grading']['mode'] == 'custom_only' and config['judge']['enabled'] is False,
            'Diagnostic grading mismatch')
    require(config['provider'] == {'name': 'openai', 'model': POLICY['model']}
            and result['agents']['codex']['model'] == POLICY['model'], 'Diagnostic model mismatch')
    require(evaluated_source_revision(config['evaluated_source']) == os.environ['GITHUB_SHA'],
            'Diagnostic source mismatch')
    harbor = config['harbor']
    require(harbor['environment']['value'] == environment and harbor['n_attempts'] == MODES[mode]
            and harbor['n_concurrent'] == POLICY['concurrency'] and harbor['stop_on_pass'] is False
            and harbor['timeout_multiplier'] == POLICY['timeout_multiplier'], 'Diagnostic execution policy mismatch')
    cases = len(read_json(skill / 'evals/evals.json')['evals'])
    expected_ids = {entry['id'] for entry in read_json(skill / 'evals/evals.json')['evals']}
    require(result['dataset_summary']['total_tasks'] == cases, 'Diagnostic case coverage mismatch')
    for arm in ('with_skill', 'without_skill'):
        condition = result['agents']['codex']['conditions'][arm]
        require(condition['execution_status'] == 'succeeded' and not condition['execution_errors']
                and condition['scored_attempts'] == condition['expected_attempts'] == cases * MODES[mode],
                'Unscoreable trial makes the complete pilot comparison inconclusive')
        counts = {case: 0 for case in expected_ids}
        rewards = list((run / 'codex' / arm.replace('_', '-') / 'trials').glob('*/reward.json'))
        require(len(rewards) == cases * MODES[mode], 'Diagnostic retained trial cardinality mismatch')
        for path in rewards:
            reward = read_json(path)
            require(reward.get('entry_id') in counts and ('has_skill' not in reward or reward['has_skill'] is (arm == 'with_skill')),
                    'Diagnostic retained trial identity mismatch')
            outcome = reward.get('details', {}).get('outcome', {})
            require(outcome.get('classification') in ('passed', 'failed')
                    and reward.get('evaluation_status') == 'complete',
                    'Unscoreable or unclassified trial makes the comparison inconclusive')
            counts[reward['entry_id']] += 1
        require(all(count == MODES[mode] for count in counts.values()), 'Diagnostic retained case coverage mismatch')
    # Completion uses the same captured native identities as public admission.
    import skill_evidence as evidence
    evidence.normalize_behavioral(root, name, workspace=workspace, native_layout=True)
    write_json(root / 'provenance.json', {'schema_version': 1, 'status': 'complete',
               'diagnostic_only': True, 'skill': name, 'mode': mode})
    summary([f'## {name}: native diagnostic comparison', '',
             'Native execution is complete. No standard judge metrics were scored. '
             'Custom outcomes remain diagnostic. Public reporting is supported but projection and upload success are reported separately; history remains ineligible.'])


def validate_metrics(data, workspace, name, revision, *, mode="standard"):
    require(not benchmark_options(name)['diagnostic_only'], 'Diagnostic-only suite cannot publish history')
    require(set(data) == {"schema_version", "skill", "mode", "revision", "policy", "patch_sha256",
                          "dataset_digest", "metrics"}, "Unexpected history artifact fields")
    require(data["schema_version"] == 1 and data["skill"] == name and data["mode"] == mode,
            "History identity/mode mismatch")
    benchmark_skill(workspace, name)
    require(bool(re.fullmatch(r"[0-9a-f]{40}", revision)) and data["revision"] == revision, "Revision mismatch")
    policy = data["policy"]
    require(type(policy) is dict and policy == benchmark_policy(name, gh_revision=policy.get("upstream_revision")),
            "Benchmark policy mismatch")
    require(data["patch_sha256"] == hashlib.sha256((workspace / PATCH).read_bytes()).hexdigest(), "Patch mismatch")
    require(bool(re.fullmatch(r"sha256:[0-9a-f]{64}", data["dataset_digest"])), "Invalid dataset digest")
    validate_history_metric_rows(data["metrics"])


def validate_history_metric_rows(rows):
    require(isinstance(rows, list) and len(rows) == len(METRICS), "Wrong metric count")
    for row, name in zip(rows, METRICS):
        require(set(row) == {"name", "unit", "value"} and row["name"] == name and row["unit"] == "score",
                "Unexpected metric fields")
        value = row["value"]
        require(type(value) in (int, float) and math.isfinite(value)
                and (-1 if name == "Skill Lift" else 0) <= value <= 1, "Invalid numeric metric")


def validate_released_metrics(data, workspace, name, revision, *, mode, historical=False):
    """Validate the released score projection on the lean publication host."""
    from benchmark_native import NATIVE_PRODUCER, native_owner, released_policy, score_series

    required = {"schema_version", "skill", "mode", "revision", "series", "policy", "patch_sha256",
                "dataset_digest", "metrics"}
    require(type(data) is dict and set(data) == required, "Unexpected released history artifact fields")
    require(type(data["schema_version"]) is int and data["schema_version"] == 1
            and data["skill"] == name and data["mode"] == mode and mode in MODES,
            "Released history identity or mode differs")
    benchmark_skill(workspace, name)
    require(bool(re.fullmatch(r"[0-9a-f]{40}", revision)) and data["revision"] == revision,
            "Released history revision differs")
    policy = data['policy']
    require(type(policy) is dict and type(data['patch_sha256']) is str, "Invalid released history producer")
    owner = native_owner(policy.get('evaluator_revision'), 'sha256:' + data['patch_sha256'],
                         producer=policy.get('producer_profile'))
    gh_revision = policy.get("upstream_revision") if historical else None
    require(owner is not None and (historical or owner == NATIVE_PRODUCER)
            and policy == released_policy(name, owner=owner, gh_revision=gh_revision),
            "Released history producer or policy differs")
    require(data["series"] == score_series(name, mode, owner=owner, gh_revision=gh_revision),
            "Released history series differs")
    require(isinstance(data["dataset_digest"], str) and re.fullmatch(r"sha256:[0-9a-f]{64}", data["dataset_digest"]),
            "Invalid released history dataset digest")
    validate_history_metric_rows(data["metrics"])


def publish_metrics(workspace, root, name, *, released=False):
    require(not benchmark_options(name)['diagnostic_only'], 'Diagnostic-only suite cannot publish history')
    require(os.environ.get("GITHUB_EVENT_NAME") == "workflow_dispatch"
            and os.environ.get("GITHUB_REF") == "refs/heads/main"
            and os.environ.get("BENCHMARK_MODE") == "standard", "History requires a main standard dispatch")
    if released:
        data = read_json(root / "released-scores.json", limit=16384)
        validate_released_metrics(data, workspace, name, os.environ["GITHUB_SHA"], mode="standard")
        policy_id = data["series"]
    else:
        data = read_json(root / "metrics.json", limit=16384)
        validate_metrics(data, workspace, name, os.environ["GITHUB_SHA"])
        policy_id = hashlib.sha256(json.dumps([data["policy"], data["patch_sha256"]], sort_keys=True).encode()).hexdigest()[:16]
    rows = [{**row, "extra": f"Dataset {data['dataset_digest']}; policy {policy_id}"} for row in data["metrics"]]
    write_json(root / "benchmark.json", rows)
    outputs(history_dir=f"benchmarks/{name}/{policy_id}")


def capture_benchmark_custom(workspace, root, name):
    """Hash retained native staging through the common admission contract."""
    if name not in ('gh', 'powershell-pester-6') or (root / 'custom-metric-capture.json').exists():
        return
    import skill_evidence as evidence
    results = root / 'results' / name
    if not results.exists(): return
    entries = list(results.iterdir())
    runs = [path for path in entries if path.name != 'latest' and path.is_dir() and not path.is_symlink()]
    if len(runs) != 1: return  # Public selection remains explicit for ambiguous runs.
    run = runs[0]
    producer = (read_json(root / 'versions.json') if benchmark_options(name)['diagnostic_only']
                and (root / 'native-preparation.json').exists() else None)
    config_path = run / 'run_config.json'
    recovery_path = root / 'provenance.json'
    if (producer is not None and not config_path.exists() and not config_path.is_symlink()
            and recovery_path.is_file() and read_json(recovery_path).get('status') == 'incomplete'):
        # A force-stopped runner may never write its final configuration.
        # Keep the native diagnostics without manufacturing a capture.
        return
    tasks = run / '_harbor-tasks/codex'
    if not tasks.exists(): return
    from benchmark_native import NATIVE_PRODUCER
    purpose = ('benchmark-1720' if name == 'powershell-pester-6' and producer is not None
               and producer.get('producer_profile') == NATIVE_PRODUCER else 'benchmark')
    rows = []
    for arm, directory in (('with_skill', 'with'), ('without_skill', 'without')):
        task_root = evidence.safe_path(tasks / directory, directory=True)
        candidates = [path for path in task_root.iterdir() if path.is_dir()]
        rows.extend(evidence.capture_custom_tasks(workspace, name, candidates, arm, purpose=purpose))
    config = read_json(config_path)
    prepared_ids = {row['id'] for row in read_json(benchmark_skill(workspace, name, root) / 'evals/evals.json')['evals']}
    if prepared_ids != set(evidence.custom_contract(name, workspace, purpose=purpose)[0]['cases']): return
    capture = evidence.custom_capture(workspace, name, benchmark_skill(workspace, name, root), rows,
        purpose=purpose, attempts=config['harbor']['n_attempts'], agent='codex', producer_versions=producer,
        execution_policy={'environment': config['harbor']['environment']['value'],
            'concurrency': config['harbor']['n_concurrent'], 'timeout_multiplier': config['harbor']['timeout_multiplier'],
            'stop_on_pass': config['harbor']['stop_on_pass']},
        numeric_excerpts=evidence.capture_custom_numeric_fields(workspace, name, run / '_harbor-jobs', root, rows))
    write_json(root / evidence.CUSTOM_CAPTURE, capture)


def preserve_custom_capture_hashes(original, redacted, workspace, skill):
    """Restore typed staging digests, never secret-looking keys or free text."""
    import skill_evidence as evidence
    evidence.validate_custom_capture(original, skill, workspace)
    for source, target in zip(original['tasks'], redacted['tasks']):
        require((source['case_id'], source['arm']) == (target['case_id'], target['arm']), 'Capture identity changed during redaction')
        for member, value in source['members'].items():
            evidence.sha(value)
            # Upstream treats some support-file names as secret-bearing keys.
            # Its validated SHA256 is publication-safe; a dropped key stays dropped.
            if target['members'].get(member) == '<redacted>':
                target['members'][member] = value
    return redacted


def preserve_registered_case_keys(original, redacted, case_ids):
    """Case identifiers name reviewed tasks; redact each row's contents normally."""
    from skillevaluator.utils.redaction import redact_sensitive_data
    if isinstance(original, dict) and isinstance(redacted, dict):
        for key, value in original.items():
            target = redacted.get(key)
            if key == 'cases' and isinstance(value, dict) and set(value) <= case_ids and isinstance(target, dict):
                for case, row in value.items():
                    if target.get(case) == '<redacted>' and isinstance(row, dict):
                        target[case] = redact_sensitive_data(row)
            else:
                preserve_registered_case_keys(value, target, case_ids)
    elif isinstance(original, list) and isinstance(redacted, list):
        for source, target in zip(original, redacted):
            preserve_registered_case_keys(source, target, case_ids)
    return redacted


def benchmark_artifacts(workspace, root, name, destination):
    """Stage only native report contracts, using upstream credential redaction."""
    from skillevaluator.utils.redaction import redact_sensitive_data, redact_sensitive_text

    benchmark_skill(workspace, name)
    root = root.absolute()
    destination = destination.absolute()
    for path in (root, destination):
        require(path.resolve() == path and not path.is_relative_to(workspace),
                "Benchmark artifacts must use real paths outside the checkout")
    require(not destination.is_relative_to(root) and not root.is_relative_to(destination),
            "Artifact staging must be separate from raw results")
    preparation = root / "native-preparation.json"
    released = preparation.exists()
    released_diagnostic = released and benchmark_options(name)['diagnostic_only']
    if released:
        from benchmark_native import native_versions

        require(read_json(root / "versions.json") == native_versions() and read_json(preparation)["skill"] == name
                and (released_diagnostic or not (root / "custom-metric-capture.json").exists()),
                "Released benchmark artifact producer differs")
    if not released or released_diagnostic:
        capture_benchmark_custom(workspace, root, name)
    files = regular_tree(
        root,
        excluded_dirs={"_harbor-jobs", "_harbor-tasks"},
        excluded_links={Path("results") / name / "latest"},
    )
    carrier = 'codex'
    if (root / 'custom-metric-capture.json').exists():
        import skill_evidence as evidence
        candidate_capture = read_json(root / 'custom-metric-capture.json')
        if evidence.campaign_purpose(candidate_capture.get('purpose')):
            campaign_profile, _ = evidence.validate_custom_capture(candidate_capture, name, workspace)
            carrier = evidence.custom_carrier(campaign_profile)
            evidence.token(carrier)
    registered_cases = set()
    if released and name == "gh":
        from gh_evaluations import dataset

        registered_cases = {row["id"] for row in dataset(workspace)}
    elif name == 'gh' and (root / 'custom-metric-capture.json').exists():
        capture = read_json(root / 'custom-metric-capture.json')
        if (capture.get('purpose') == 'oracle_qualification' or str(capture.get('purpose','')).startswith('campaign-')) and capture.get('producer', {}).get('skillevaluator') in ('0.8.0', '0.9.0'):
            import skill_evidence as evidence
            evidence.validate_custom_capture(capture, name, workspace)
            registered_cases = set(capture['case_ids'])
    metadata = {"versions.json", "dataset-validation.json", "provenance.json",
                "docker-version.json", "docker-images.jsonl", "custom-metric-capture.json", "campaign-scheduler.json"}
    if released:
        metadata.add(preparation.name)
    if name == "gh":
        metadata.update({"deterministic.json", "selection.json"})
    # Preserve the historical layout; registered campaigns declare their carrier.
    root_reports = {"result.json", "run_config.json", "dataset_snapshot.json", "report.html",
                    "attempt_policy.json", "comparison.json"}
    agent_reports = {"lift.json", "custom_lift.json", "pass_at_k_lift.json",
                     "security_attribution.json", "findings.json"}
    trial_reports = {"result.json", "config.json", "exception.txt", "trial.log", "trajectory.json",
                     "codex.txt", "reward.json", "failure.json", "artifact_manifest.json", "judge_accounting.json"}

    def allowed(relative):
        parts = relative.parts
        if any(part.startswith(".") for part in parts):
            return False
        if len(parts) == 1:
            return parts[0] in metadata
        if len(parts) == 2 and parts[0] == "dependencies":
            return parts[1] in {"evaluator.json", "semgrep.json", "skillspector.json"}
        if len(parts) < 4 or parts[:2] != ("results", name):
            return False
        # Native external layout: results/<skill>/<run>/<carrier>/<arm>/trials/<trial>/...
        tail = parts[3:]
        if len(tail) == 1:
            return tail[0] in root_reports
        if tail[0] != carrier:
            return False
        if len(tail) == 2:
            return tail[1] in agent_reports
        if tail[1] not in {"with-skill", "without-skill"}:
            return False
        return (len(tail) == 3 and tail[2] == "summary.json") or (
            len(tail) == 5 and tail[2] == "trials" and tail[4] in trial_reports)

    destination.mkdir(parents=True, exist_ok=False)
    copied = 0
    for source in sorted(files):
        relative = source.relative_to(root)
        if not allowed(relative):
            continue
        # Recheck the final input immediately before reading; raw results stay untouched.
        require(not source.is_symlink() and source.resolve() == source, "Linked publication input")
        if source.suffix == ".json":
            value = read_json(source, limit=64 * 1024 * 1024)
            if benchmark_options(name)['diagnostic_only']:
                require('PESTER_VERIFIER_ONLY_' not in json.dumps(value), 'Protected verifier input in diagnostic artifact')
            original = value
            value = redact_sensitive_data(value)
            capture = (relative.as_posix() == 'custom-metric-capture.json'
                       and (released_diagnostic or (
                           original.get('producer', {}).get('skillevaluator') in ('0.8.0', '0.9.0')
                           and ((name == 'gh' and original.get('purpose') == 'oracle_qualification')
                                or (name in ('gh', 'podman') and str(original.get('purpose', '')).startswith('campaign-'))))))
            if capture:
                value = preserve_custom_capture_hashes(original, value, workspace, name)
            if registered_cases:
                value = preserve_registered_case_keys(original, value, registered_cases)
            if name == "gh":
                from gh_evaluations import redact_publication
                value = redact_publication(value)
            if capture:
                import skill_evidence as evidence
                evidence.validate_custom_capture(value, name, workspace)
            write_json(destination / relative, value)
        else:
            if name == "gh":
                require(source.stat().st_size <= 64 * 1024 * 1024, "Oversized gh diagnostic")
            text = source.read_text(encoding="utf-8")
            if benchmark_options(name)['diagnostic_only']:
                require('PESTER_VERIFIER_ONLY_' not in text, 'Protected verifier input in diagnostic artifact')
            text = redact_sensitive_text(text)
            if name == "gh":
                from gh_evaluations import redact_publication
                text = redact_publication(text)
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(text, encoding="utf-8")
        copied += 1
    require(copied > 0, "No publishable benchmark reports")
    summary([f"Staged {copied} allowlisted files with upstream redaction; raw runtime directories are excluded."])


def public_strings(value):
    """Detect credential patterns without changing authenticated claims or keys."""
    from skillevaluator.utils.redaction import redact_sensitive_text

    if isinstance(value, str):
        require(redact_sensitive_text(value) == value, "Credential pattern in public value")
    elif isinstance(value, dict):
        for item in value.values():
            public_strings(item)
    elif isinstance(value, list):
        for item in value:
            public_strings(item)


def stage_public(workspace, root, destination, records):
    """Reserve a private bundle; expose readiness only after exact-set validation."""
    import skill_evidence as evidence

    destination = Path(destination).absolute()
    root = Path(root).absolute()
    # The secure writer checks parents, ownership, freshness and input boundaries.
    evidence.write_outputs({}, destination, workspace, root)
    owned = destination.lstat()
    expected = set()
    guards = []
    try:
        for relative, value in records:
            evidence.relative(relative)
            require(relative not in expected, "Duplicate public member")
            member = Path(relative)
            if member.name == "inventory.json":
                require(relative == "inventory/inventory.json", "Unexpected inventory member")
            else:
                name = value["source"]["skill_id"]
                tail = "static" if value["kind"] == "static" else "behavioral/" + value["run_id"]
                require(relative == f"skills/{name}/{tail}/public-report.json", "Unexpected public member")
            parent = destination
            for part in member.parent.parent.parts:
                parent /= part
                if not parent.exists():
                    evidence.write_outputs({}, parent, workspace, root)
                evidence.safe_path(parent, directory=True)
            # Validate immediately before staging, even though projection validated too.
            if member.name == "inventory.json":
                evidence.validate_inventory(value)
            else:
                evidence.validate_public(value)
            public_strings(value)
            evidence.write_outputs({member.name: value}, destination / member.parent, workspace, root)
            guards.extend(evidence.record_guards(value))
            expected.add(relative)
        actual = {path.relative_to(destination).as_posix() for path in evidence.safe_tree(destination)}
        require(actual == expected and bool(expected), "Public bundle file set mismatch")
        # Recheck every captured input after the last report has been written.
        for guard in dict.fromkeys(guards):
            guard()
    except BaseException:
        current = destination.lstat()
        if (current.st_dev, current.st_ino) == (owned.st_dev, owned.st_ino):
            # CPython's descriptor-based rmtree never follows replacement symlinks.
            require(shutil.rmtree.avoids_symlink_attacks, "Secure staging cleanup unsupported")
            shutil.rmtree(destination)
        raise
    return len(expected)


def public_quality(workspace, root, destination):
    import skill_evidence as evidence
    import skill_analysis as analysis

    inv = evidence.inventory(workspace)
    names = sorted(row["source"]["skill_id"] for row in inv["skills"]
                   if row["source"]["owner"] == "local")
    # Capture catalog membership using the same bounded no-follow reader.
    directories = {}; states = {}; members = {}
    catalog = evidence.parse_json(evidence.read_bytes(Path(root) / "reports/catalog-summary.json",
        directory_identities=directories, directory_states=states, file_states=members))
    catalog_guard = evidence.input_guard(directories, states, members)
    require(type(catalog) is dict and type(catalog.get("skills")) is list,
            "Invalid public quality catalog")
    actual = [row["name"] for row in catalog["skills"]]
    if sorted(actual) != names:
        summary(["Public quality unavailable: catalog does not exactly cover discovered local skills."])
        raise ValueError("Public quality catalog membership mismatch")

    runs = []
    summary_bytes = 0

    def records():
        nonlocal summary_bytes
        yield "inventory/inventory.json", inv
        for name in names:
            data = evidence.normalize_static(Path(root), name, workspace)
            public = evidence.project(data)
            run = analysis.static_record(evidence.identity(public), public)
            summary_bytes += len(evidence.encoded(run))
            require(summary_bytes <= analysis.JSON_LIMIT, 'Quality summary input limit')
            runs.append(run)
            yield f"skills/{name}/static/public-report.json", public
        for guard in evidence.record_guards(inv):
            guard()
        catalog_guard()

    count = stage_public(workspace, root, destination, records())
    lines = ["## Skill quality · validated evidence (findings advisory)", "",
             "Infrastructure status is reported separately; this summary does not override a failed job or contract check.",
             f"{len(names)} local skills assessed. Static assessment excludes imported/deployed copies and evaluation overlays.",
             "Behavioral evaluations were not executed by this job; configured suites are not measured results.", "",
             *analysis.render_static_summary(runs, heading="Review first"), "",
             "### Skills and coverage", "", "| Skill | Native evaluator status | Failed / incomplete / skipped checks | Critical / High / Medium / Low | Behavioral suite |",
             "| --- | --- | --- | --- | --- |"]
    configured = {row['source']['skill_id']: row['suite'] is not None for row in inv['skills']}
    for run in runs:
        total = next(s for s in run['scans'] if s['scanner'] == 'catalog-total')
        flags = '; '.join(f"{s['scanner']} {s['status']}" for s in run['scans']
                          if s['scanner'] != 'catalog-total' and s['status'] != 'passed') or 'None recorded'
        counts = ' / '.join(str(total['severity_counts'][level]) for level in analysis.SEVERITIES)
        name = run['source']['skill_id']
        lines.append(f"| {name} | {total['status']} | {flags} | {counts} | " +
                     ('Configured; not executed here' if configured[name] else 'Not configured') + ' |')
    lines += ["", "Incomplete tool markers are coverage evidence, not additional findings. "
              "Detailed findings and reference IDs are in skill-public-quality; full native reports are in skill-quality."]
    repo = os.environ.get('GITHUB_REPOSITORY', '')
    run_id = os.environ.get('GITHUB_RUN_ID', '')
    if (re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*/[A-Za-z0-9][A-Za-z0-9_.-]*', repo)
            and re.fullmatch(r'[0-9]{1,20}', run_id)):
        public_strings(repo)
        lines += [f"[Run artifacts](https://github.com/{repo}/actions/runs/{run_id}#artifacts)"]
    require(len('\n'.join(lines).encode('utf-8')) <= analysis.MARKDOWN_LIMIT, 'Quality summary size exceeded')
    summary(lines)
    summary([f"Public quality ready: {count - 1} validated skill reports and inventory."])


def public_benchmark(workspace, root, name, mode, destination, selected=None):
    import skill_evidence as evidence

    evidence.skill_id(name)
    require(mode in MODES, "Unsupported public benchmark mode")
    inv = evidence.inventory(workspace)
    require(any(row["source"]["skill_id"] == name and row["suite"] is not None for row in inv["skills"]),
            "Selected public benchmark has no configured suite")
    data = evidence.normalize_behavioral(Path(root), name, selected, workspace, native_layout=True)
    attempts = data["policy"]["attempts"]
    qualification = evidence.campaign_purpose(data.get('custom', {}).get('purpose')) or data.get('custom', {}).get('purpose') in ('oracle_qualification', 'cli_pilot', 'cli_pilot_control', 'cli_pilot_probe', 'cli_pilot_replay', 'skill_effectiveness', 'skill_effectiveness_probe', 'skill_effectiveness_control')
    require(qualification or attempts["mode"] in (mode, "unknown") and attempts["maximum"] in (None, MODES[mode]),
            "Public benchmark mode mismatch")
    if evidence.released_policy_identity(data['policy'], custom_only=benchmark_options(name)['diagnostic_only'], static=False):
        from benchmark_native import score_record

        scores = score_record(workspace, Path(root), name, mode, os.environ["GITHUB_SHA"], selected=data["run_id"])
        require(scores["series"] == data["policy"]["published_id"] and scores["metrics"] == data["metrics"]
                and scores["dataset_digest"] == data["dataset"]["staged_digest"],
                "Released public report differs from its validated scores")
        evidence.require_released_report_population(data)
    public = evidence.project(data)
    count = stage_public(workspace, root, destination, [
        ("inventory/inventory.json", inv),
        (f"skills/{name}/behavioral/{public['run_id']}/public-report.json", public),
    ])
    summary([f"Public benchmark ready: {count - 1} validated report; evidence {public['availability']['status']}."])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("preflight")
    operation = commands.add_parser('operation')
    operation.add_argument('root', type=Path)
    operation.add_argument('skill')
    operation.add_argument('mode', choices=MODES)
    operation.add_argument('outcome', choices=('success', 'failure', 'cancelled', 'skipped'))
    operation.add_argument('destination', type=Path)
    select = commands.add_parser("select")
    select.add_argument("skill")
    select.add_argument("mode", choices=MODES)
    prepare = commands.add_parser('prepare')
    prepare.add_argument('root', type=Path)
    prepare.add_argument('skill')
    catalog = commands.add_parser("catalog")
    catalog.add_argument("root", type=Path)
    benchmark = commands.add_parser("benchmark")
    benchmark.add_argument("root", type=Path)
    benchmark.add_argument("skill")
    benchmark.add_argument("mode", choices=MODES)
    benchmark.add_argument("destination", type=Path)
    recover = commands.add_parser("recover")
    recover.add_argument("root", type=Path)
    recover.add_argument("skill")
    recover.add_argument("mode", choices=MODES)
    recover.add_argument("outcome", choices=("success", "failure", "cancelled", "skipped"))
    publish = commands.add_parser("publish")
    publish.add_argument("root", type=Path)
    publish.add_argument("skill")
    publish.add_argument("--released", action="store_true")
    artifacts = commands.add_parser("artifacts")
    artifacts.add_argument("root", type=Path)
    artifacts.add_argument("skill")
    artifacts.add_argument("destination", type=Path)
    quality = commands.add_parser("public-quality")
    quality.add_argument("root", type=Path)
    quality.add_argument("destination", type=Path)
    public = commands.add_parser("public-benchmark")
    public.add_argument("root", type=Path)
    public.add_argument("skill")
    public.add_argument("mode", choices=MODES)
    public.add_argument("destination", type=Path)
    public.add_argument("--run")
    qualified = commands.add_parser('benchmark-evidence')
    qualified.add_argument('root', type=Path)
    qualified.add_argument('skill')
    qualified.add_argument('mode', choices=MODES)
    qualified.add_argument('destination', type=Path)
    qualified.add_argument('--run')
    recover.add_argument('--evidence-profile', choices=('behavioral-090-offline-v1',))
    args = parser.parse_args()
    workspace = Path(os.environ["GITHUB_WORKSPACE"]).resolve()
    if args.command in {"public-quality", "public-benchmark"}:
        try:
            if args.command == "public-quality":
                public_quality(workspace, args.root, args.destination)
            else:
                public_benchmark(workspace, args.root, args.skill, args.mode, args.destination, args.run)
        except (ValueError, KeyError, TypeError, AttributeError, IndexError, OSError, OverflowError, UnicodeError, RecursionError):
            # Native exceptions may contain credentials or arbitrary prose. Never echo them.
            summary(["Public evidence unavailable: input or publication contract rejected; no bundle is ready."])
            return 1
    elif args.command == 'operation':
        operation_receipt(workspace, args.root, args.skill, args.mode, args.outcome, args.destination)
    elif args.command == "preflight":
        catalog_preflight(workspace)
    elif args.command == "select":
        benchmark_skill(workspace, args.skill)
        options = benchmark_options(args.skill)
        require(not options['diagnostic_only'] or args.mode == 'confirmation',
                'Diagnostic-only suite requires confirmation mode; history is unavailable')
        outputs(skill=args.skill, model=POLICY["model"], attempts=MODES[args.mode],
                history_eligible=str(not options['diagnostic_only']).lower(),
                public_supported='true', public_source_kind='retained' if options['grading_mode'] == 'custom_only' else 'original')
    elif args.command == 'prepare':
        skill = prepare_benchmark(workspace, args.root, args.skill)
        options = benchmark_options(args.skill)
        outputs(skill_dir=str(skill), grading_mode=options['grading_mode'], workspace_mode=options['workspace_mode'])
    elif args.command == "catalog":
        try:
            catalog_report(workspace, args.root)
        except (ValueError, KeyError, TypeError, AttributeError, IndexError, OSError, OverflowError, UnicodeError, RecursionError):
            summary(["Native infrastructure contracts failed: catalog, exit, native report or dataset evidence is missing or invalid. "
                     "Inspect collection steps and the skill-quality artifact. Findings are unresolved; a richer summary cannot override this failure."])
            return 1
    elif args.command == 'benchmark-evidence':
        import benchmark_evidence
        benchmark_evidence.report(workspace, args.root, args.skill, args.mode, args.destination, args.run)
    elif args.command == "benchmark":
        benchmark_report(workspace, args.root, args.skill, args.mode, args.destination)
    elif args.command == "recover":
        recover_benchmark(workspace, args.root, args.skill, args.mode, args.outcome,
                          **({'evidence_profile': args.evidence_profile} if args.evidence_profile else {}))
    elif args.command == "artifacts":
        benchmark_artifacts(workspace, args.root, args.skill, args.destination)
    else:
        publish_metrics(workspace, args.root, args.skill, released=args.released)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
        summary(["## Skill evaluation infrastructure failure", "", html.escape(str(error))])
        sys.exit(1)
