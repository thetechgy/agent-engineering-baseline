"""Credential-free qualification through native Harbor scheduling and collection."""

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

import skill_evidence as evidence
import pester_evaluations as pilot
import skill_reports as reports
from skillevaluator.tier3.harbor.adapter import stage_native_harbor_tasks
from skillevaluator.tier3.harbor.collector import collect_harbor_results
from skillevaluator.tier3.harbor.runner import build_harbor_run_command
from skillevaluator.evaluation.tier3_report import render_agent_eval_html_report
from harbor.agents.installed.codex import Codex


ROOT = Path(__file__).resolve().parents[2]
VERIFIER_NO_NETWORK = 'services:\n  main:\n    network_mode: none\n'


def attach_loopback_verifier(task):
    """Apply the fixture owner's loopback-only setting after authored input validation."""
    with (task / 'tests/docker-compose.yaml').open('x', encoding='utf-8') as override:
        override.write(VERIFIER_NO_NETWORK)


def qualification_bundle(root, *, candidate=False):
    """Expand reviewed fixture submissions before native staging, never model data."""
    bundle = pilot.stage(ROOT, root / 'bundle' / pilot.NAME)
    if candidate:
        # Harbor 0.24 otherwise routes no-network through its egress namespace.
        # The candidate's bounded verifier-only compatibility rule admits this
        # literal offline override; the shared grader still requires only lo.
        for task in (bundle / 'evals/harbor').iterdir():
            if task.is_dir():
                (task / 'tests/docker-compose.yaml').write_text(VERIFIER_NO_NETWORK)
    source = ROOT / pilot.OVERLAY / 'support'
    solutions = {'pester-001': ('classic', 'standalone', 'data'),
                 'pester-002': ('classic', 'data'), 'pester-003': ('external', 'module'),
                 'pester-004': ('discovery', 'inline', 'compact')}
    fixtures = [(case, style, (source / f'qualification/{case}/{style}.Tests.ps1').read_bytes(), 'passed', None)
                for case, styles in solutions.items() for style in styles]
    fixtures += [(case, 'weak', (source / f'qualification/{case}/weak.Tests.ps1').read_bytes(), 'failed', None)
                 for case in solutions]
    good = (source / 'qualification/pester-001/classic.Tests.ps1').read_bytes()
    fixtures += [
        ('pester-001', 'unsupported', b"[System.IO.File]::ReadAllText('/tests/grader.py')", 'unsupported', None),
        ('pester-001', 'empty', b'# no tests\n', 'invalid', None),
        ('pester-001', 'skipped', b"Describe 'skip' { It 'skipped' -Skip { 1 | Should-Be 1 } }", 'invalid', None),
        ('pester-001', 'failure-text', b"Describe 'failed' { It 'payload' { throw 'PESTER_VERIFIER_ONLY_FORGED_FAILURE_PAYLOAD' } }", 'failed', None),
        ('pester-001', 'malformed', b'\xff', 'invalid', None),
        ('pester-001', 'timeout', b"Describe 'bounded' { It 'runs out of CPU' { foreach ($a in 1..100000) { foreach ($b in 1..100000) { $value=1 } } } }", 'timeout', None),
        ('pester-001', 'missing-runtime', good, 'infrastructure_error', 'missing'),
        ('pester-001', 'version-drift', good, 'infrastructure_error', 'version'),
        ('pester-003', 'wrong-scope', b"BeforeAll { Import-Module '/workspace/input/Probe.psm1' -Force }; Describe 'scope' { BeforeEach { Mock Test-ProbeConnection { $true } }; It 'checks status' { (Get-EndpointStatus -Target 'service.invalid').Healthy | Should-BeTrue } }", 'failed', None),
        ('pester-004', 'broken-discovery', (source / 'cases/pester-004/input/Existing.Tests.ps1').read_bytes(), 'invalid', None),
        ('pester-005', 'good', (source / 'qualification/pester-005/good.json').read_bytes(), 'passed', None),
        ('pester-005', 'wrong', (source / 'qualification/pester-005/wrong.json').read_bytes(), 'failed', None),
    ]
    entries = {entry['id']: entry for entry in pilot.dataset(ROOT)}
    native = bundle / 'evals/harbor'
    expanded, records = [], {}
    for case, style, candidate, expected, mode in fixtures:
        identity = case + '-' + style
        target = native / identity
        shutil.copytree(native / case, target)
        config = target / 'task.toml'
        config.write_text(config.read_text().replace('entry_id = ' + json.dumps(case),
                                                    'entry_id = ' + json.dumps(identity)))
        (target / 'tests/entry.json').write_text(json.dumps({'id': identity, 'grading_mode': 'custom_only'}, indent=2) + '\n')
        if mode:
            with (target / 'tests/Dockerfile').open('a') as dockerfile:
                if mode == 'missing':
                    dockerfile.write('RUN rm -- /opt/microsoft/powershell/7/pwsh\n')
                else:
                    change = ("from pathlib import Path; p=Path('/opt/pester/Modules/Pester/6.2.0/Pester.psd1'); "
                              "s=p.read_text(); assert \"'6.2.0'\" in s; "
                              "p.write_text(s.replace(\"'6.2.0'\",\"'6.1.0'\",1))")
                    dockerfile.write('RUN ' + json.dumps(['python3', '-c', change]) + '\n')
        expanded.append({**entries[case], 'id': identity})
        records[identity] = {'case': case, 'candidate': candidate, 'expected': expected,
                             'output': reports.read_json(source / 'cases' / case / 'profile.json').get('output', 'Subject.Tests.ps1')}
        if expected in ('passed', 'failed'):
            if case == 'pester-005':
                metrics = {'negative_control_correct': float(expected == 'passed')}
            else:
                metrics = {'pester_reference_pass': float(style not in ('failure-text', 'wrong-scope')),
                           'pester_mutation_detection': float(expected == 'passed'),
                           'pester_test_quality': float(expected == 'passed')}
            records[identity]['metrics'] = metrics
    for case in entries:
        shutil.rmtree(native / case)
    reports.write_json(bundle / 'evals/evals.json', {'skill_name': pilot.NAME, 'evals': expanded})
    (native / 'dataset.toml').write_text('[dataset]\nname = "nvidia/pester-qualification"\n\n' +
        ''.join('[[tasks]]\nname = ' + json.dumps('nvidia/' + entry['id']) + '\n\n' for entry in expanded))
    return bundle, records


def main(*, candidate=False, artifact=None):
    """Always retain cleanup status, including failed native controls."""
    artifact = Path(artifact) if artifact is not None else Path(os.environ['RUNNER_TEMP']) / 'pester-gate-artifacts'
    def resources():
        return {kind: set(subprocess.check_output(command, text=True, timeout=15).split()) for kind, command in (
            ('containers', ['docker', 'ps', '-aq']), ('networks', ['docker', 'network', 'ls', '-q']))}
    before = resources()
    import signal
    def interrupted(_signum, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    try:
        return _main(candidate=candidate, artifact=artifact)
    finally:
        after = resources()
        clean = before == after
        reports.write_json(artifact / 'cleanup.json', {'complete': clean})
        if not clean: raise RuntimeError('Native Pester cleanup incomplete')


def _main(*, candidate=False, artifact=None):
    subprocess.run(['docker', 'info'], check=True, stdout=subprocess.DEVNULL, timeout=15)
    compose = subprocess.check_output(['docker', 'compose', 'version', '--short'], text=True, timeout=15).strip()
    if compose != reports.POLICY['docker_compose']:
        raise RuntimeError('Qualification Compose version mismatch')
    if any(os.environ.get(key) for key in ('OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'NVIDIA_API_KEY')):
        raise RuntimeError('Qualification must not receive model credentials')
    artifact = Path(artifact) if artifact is not None else Path(os.environ['RUNNER_TEMP']) / 'pester-gate-artifacts'
    from importlib.metadata import version
    current = candidate == 'current'
    release = candidate == 'release'
    from evaluator_profiles import owning_candidate, runtime, candidate_versions
    if current or release:
        owner = owning_candidate()
        expected_runtime = owner['version'], owner['harbor']
        if release and owner['version'] != '1.0.1':
            raise RuntimeError('Release fixture requires the 1.0.1 benchmark candidate')
        runtime(candidate_versions(owner), owning=True)
    else:
        expected_runtime = ('0.7.2', '0.24.0') if candidate else ('0.3.0', '0.13.2')
    if (version('skillevaluator'), version('harbor')) != expected_runtime:
        raise RuntimeError('Qualification runtime mismatch')
    def resources(kind):
        command = ['docker', 'ps', '--all', '--quiet'] if kind == 'containers' else ['docker', 'network', 'ls', '--quiet']
        return set(subprocess.check_output(command, text=True, timeout=15).split())
    before = {kind: resources(kind) for kind in ('containers', 'networks')}
    with tempfile.TemporaryDirectory(prefix='pester-container-gate-', dir=os.environ.get('RUNNER_TEMP')) as temporary:
        root = Path(temporary)
        os.environ['SKILLEVALUATOR_OUTPUT_PROVENANCE_KEY_FILE'] = str(root / 'private/key')
        bundle, fixtures = qualification_bundle(root, candidate=candidate and not release)
        register = Codex(logs_dir=root / 'registration', skills_dir='/workspace/skills',
                         version=reports.POLICY['codex'] if release else '0.155.1')._build_register_skills_command()
        jobs = root / 'jobs'
        staged_evidence = []
        before_inputs = evidence.custom_source_manifest(ROOT, pilot.NAME)
        native_failed = False
        command_stages = []
        for present in (True, False):
            tasks = root / 'tasks' / str(present)
            staged_tasks = stage_native_harbor_tasks(bundle, tasks, with_skill=present, grading_mode='custom_only')
            if len(staged_tasks) != len(fixtures):
                raise RuntimeError('Native staging coverage mismatch')
            for task in staged_tasks:
                if release:
                    attach_loopback_verifier(task)
                if current and version('skillevaluator') == '0.9.0':
                    # Reuse #135's transport correction before any verifier image build.
                    from codex_pilot import bind_verifier_metadata
                    bind_verifier_metadata(task)
                fixture = fixtures[task.name]
                solution = task / 'solution'; solution.mkdir()
                (solution / 'candidate').write_bytes(fixture['candidate'])
                check = ('test -r "$HOME/.agents/skills/powershell-pester-6/SKILL.md"\n'
                         'cmp /workspace/skills/powershell-pester-6/SKILL.md "$HOME/.agents/skills/powershell-pester-6/SKILL.md"\n'
                         if present else 'test ! -e "$HOME/.agents/skills/powershell-pester-6"\n')
                (solution / 'solve.sh').write_text(
                    '#!/bin/sh\nset -eu\ntest "$(id -u)" = 1000\ntest "$HOME" = /home/agent\n'
                    'test ! -e /tests\ntest ! -e /opt/pester-runtime/Runner.ps1\n'
                    'test -z "$(find /workspace/skills -type d -name evals -print -quit)"\n' + register + '\n' + check +
                    f'cp /solution/candidate /workspace/output/{fixture["output"]}\n')
            captured = evidence.capture_custom_tasks(ROOT, pilot.NAME, staged_tasks,
                'with_skill' if present else 'without_skill', purpose='oracle_qualification')
            from harbor.models.task.task import Task
            if any(Task(task).checksum != row['task_checksum'] for task, row in zip(sorted(staged_tasks), captured)):
                raise RuntimeError('Native task checksum mismatch')
            staged_evidence.extend(captured)
            command = build_harbor_run_command(agent='oracle', env_mode='docker', dataset_path=tasks,
                job_name=f'{pilot.NAME}-codex-{"with" if present else "without"}', jobs_dir=jobs,
                n_attempts=1, n_concurrent=2, timeout_multiplier=1.0)
            # The native oracle supplies fixtures; no Codex/provider/judge runs.
            stage = {'arm': 'with_skill' if present else 'without_skill', 'stage': 'native_oracle', 'status': 'running'}
            command_stages.append(stage)
            stage_path = artifact.with_name(artifact.name + '-command-stages.json')
            reports.write_json(stage_path, command_stages)
            try:
                if current:
                    from qualify_evaluator_candidate import run_native
                    with (root / 'native-command.log').open('w') as log:
                        code = run_native(command, env={**os.environ, 'PYTHON_DOTENV_DISABLED': '1'}, log=log, timeout=2400)
                    text = (root / 'native-command.log').read_text(errors='replace')[-32768:]
                else:
                    result = subprocess.run(command, capture_output=True, text=True, timeout=1200,
                                            env={**os.environ, 'PYTHON_DOTENV_DISABLED': '1'})
                    code, text = result.returncode, (result.stdout + result.stderr)[-32768:]
                native_failed = bool(code)
                stage.update(status='failed' if native_failed else 'complete', returncode=code)
                if native_failed:
                    from skillevaluator.utils.redaction import redact_sensitive_text
                    diagnostic = redact_sensitive_text(text).replace(str(root), '<native>').replace(str(ROOT), '<checkout>')
                    artifact.with_name(artifact.name + '-command-diagnostics.txt').write_text(diagnostic)
            except subprocess.TimeoutExpired:
                native_failed = True
                stage.update(status='infrastructure_error', code='native_deadline')
            reports.write_json(stage_path, command_stages)
            if native_failed:
                break
        raw = root / 'raw'; run = raw / 'results' / pilot.NAME / 'qualification'
        collected = collect_harbor_results(pilot.NAME, ['codex'], run, jobs, expected_cases=len(fixtures),
            expected_case_ids=list(fixtures), expected_trials=len(fixtures),
            agent_models={'codex': {'model': 'credential-free-oracle', 'source': 'qualification'}})
        if evidence.custom_source_manifest(ROOT, pilot.NAME) != before_inputs:
            raise RuntimeError('Approved qualification inputs changed')
        if not native_failed and (not candidate or current):
            reports.write_json(raw / evidence.CUSTOM_CAPTURE, evidence.custom_capture(ROOT, pilot.NAME, bundle, staged_evidence,
                purpose='oracle_qualification', attempts=1, agent='oracle',
                execution_policy={'environment': 'docker', 'concurrency': 2, 'timeout_multiplier': 1.0, 'stop_on_pass': False}))
        # Directory convention only: actual trial metadata identifies oracle.
        reports.write_json(run / 'run_config.json', {'grading': {'mode': 'custom_only'}, 'judge': {'enabled': False},
            'qualification': {'producer': 'oracle', 'inference': False}})
        reports.write_json(run / 'result.json', {**collected, 'diagnostic_only': True, 'qualification': True,
            'skill_name': pilot.NAME, 'report_status': 'incomplete'})
        render_agent_eval_html_report(bundle, run, use_llm_judge=False)
        reports.benchmark_artifacts(ROOT, raw, pilot.NAME, artifact)
        if any(b'PESTER_VERIFIER_ONLY_' in p.read_bytes() for p in reports.regular_tree(artifact)):
            raise RuntimeError('Protected payload entered a diagnostic artifact')
        if native_failed:
            raise RuntimeError('Native oracle lifecycle failed; shared diagnostics retained')
        reports.write_json(artifact / 'qualification.json', {'runtime': dict(zip(('skillevaluator', 'harbor'), expected_runtime)),
            'diagnostic_only': True, 'inference': False, 'staged_tasks': staged_evidence,
            'harness_sha256': evidence.digest_bytes(Path(__file__).read_bytes()).removeprefix('sha256:')})
        source = ROOT / pilot.OVERLAY / 'support/cases'
        eligible = sum(f['expected'] in ('passed', 'failed') for f in fixtures.values())
        observed = []
        expected_tasks = {(row['arm'].replace('_', '-'), row['case_id']): row['task_checksum'] for row in staged_evidence}
        for arm in ('with-skill', 'without-skill'):
            rewards = list((run / 'codex' / arm / 'trials').glob('*/reward.json'))
            if len(rewards) != len(fixtures):
                raise RuntimeError('Qualification trial cardinality mismatch')
            seen = set()
            for path in rewards:
                reward = reports.read_json(path); identity = reward.get('entry_id')
                if identity not in fixtures or identity in seen:
                    raise RuntimeError('Qualification trial identity mismatch')
                seen.add(identity); fixture = fixtures[identity]
                trial = reports.read_json(path.with_name('result.json'))
                if (trial.get('task_name') != identity or trial.get('task_checksum') != expected_tasks[arm, identity]
                        or ('has_skill' in reward and reward['has_skill'] is not (arm == 'with-skill'))):
                    raise RuntimeError('Native identity or arm mismatch')
                outcome = reward.get('details', {}).get('outcome', {})
                observed.append(outcome.get('classification'))
                if outcome.get('classification') != fixture['expected']:
                    if release and outcome.get('code') in ('isolation_environment', 'isolation_network',
                            'isolation_seccomp', 'isolation_resources', 'isolation_mount',
                            'worker_permission', 'worker_coreclr', 'worker_memory', 'worker_dependency',
                            'worker_unclassified', 'incomplete', 'verifier'):
                        print(f'Pester verifier prerequisite: {outcome["code"]}', flush=True)
                    raise RuntimeError(f'Unexpected outcome ({identity}, {arm}, {outcome.get("classification")})')
                if fixture['expected'] not in ('passed', 'failed'):
                    if reward.get('evaluation_status') != 'failed' or reward.get('custom_metrics'):
                        raise RuntimeError('Unscoreable fixture acquired quality metrics')
                if fixture['expected'] in ('passed', 'failed'):
                    metrics = reward.get('custom_metrics', {})
                    if fixture['case'] != 'pester-005':
                        mutants = len(list((source / fixture['case'] / 'mutants').glob('*.ps1')))
                        if (outcome.get('pester_version') != '6.2.0' or outcome.get('powershell_version') != '7.6.9'
                                or outcome.get('reference_pass') != fixture['metrics']['pester_reference_pass']
                                or outcome.get('mutants_executed') != mutants
                                or outcome.get('mutants_detected') != int(fixture['expected'] == 'passed') * mutants):
                            raise RuntimeError('Mutation/runtime evidence mismatch')
                    if metrics != fixture['metrics']:
                        raise RuntimeError('Qualification metric mismatch')
                if fixture['case'] == 'pester-005' and any(k.startswith('pester_') for k in reward.get('custom_metrics', {})):
                    raise RuntimeError('Negative control acquired Pester quality metrics')
                print(json.dumps({'fixture': identity, 'arm': arm, 'outcome': outcome['classification'],
                                  'inference': False}), flush=True)
            summary = reports.read_json(run / 'codex' / arm / 'summary.json')
            if summary['scored_attempts'] != eligible or summary['execution_status'] != 'failed':
                raise RuntimeError('Applicability or incomplete qualification status was lost')
        if any(resources(kind) != before[kind] for kind in before):
            raise RuntimeError('Native Harbor resource cleanup incomplete')
        from collections import Counter
        if Counter(observed) != {'passed': 22, 'failed': 14, 'invalid': 8, 'timeout': 2,
                                 'unsupported': 2, 'infrastructure_error': 4}:
            raise RuntimeError('Qualification classification population mismatch')
        if not candidate or current:
            qualify_reporting(root, artifact, candidate=current)
        if any(b'PESTER_VERIFIER_ONLY_' in p.read_bytes() for p in reports.regular_tree(artifact)):
            raise RuntimeError('Protected payload entered a derived reporting artifact')
        print('Pester native qualification passed' + ('; candidate HTML diagnostics only' if candidate and not current else ' with shared reporting')
              + '; no model inference executed.', flush=True)


def qualify_reporting(root, native, *, candidate=False):
    """Keep native execution on its legacy runtime; hand reviews to their owner."""
    if candidate:
        _qualify_reporting(root, native, candidate=True)
        return
    python = Path(os.environ['SKILL_REVIEW_PYTHON'])
    if not python.is_absolute() or not python.is_file():
        raise RuntimeError('Current review interpreter unavailable')
    environment = {'PATH': os.defpath, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_NO_LAZY_FETCH': '1'}
    for name in ('TMPDIR', 'RUNNER_TEMP', 'SKILLEVALUATOR_OUTPUT_PROVENANCE_KEY_FILE'):
        if name in os.environ:
            environment[name] = os.environ[name]
    launcher = (
        "import sys; from pathlib import Path; sys.path.insert(0, sys.argv[1]); "
        "from pester_container_validation import _qualify_reporting; "
        "_qualify_reporting(Path(sys.argv[2]), Path(sys.argv[3]))"
    )
    subprocess.run([str(python), '-I', '-B', '-c', launcher, str(ROOT / '.github/scripts'),
                    str(root), str(native)], env=environment, check=True, timeout=120)


def _qualify_reporting(root, native, *, candidate=False, name=pilot.NAME):
    """Use the consolidated public-only consumers, then remove native originals."""
    import skill_analysis as analysis
    import skill_report as report
    import skill_review as review

    public = root / 'public'
    reports.public_benchmark(ROOT, native, name, 'confirmation', public)
    captured = analysis.capture_inputs([public])
    value = analysis.validate_analysis(None, captured)
    saved = root / 'analysis/analysis.json'
    reports.write_json(saved, value)
    rid = next(key for key, row in captured.records.items() if row['kind'] == 'behavioral')
    first = report.render_report(value, captured)
    context = None if candidate else review.prepare([public], saved, name, rid)
    if candidate:
        behavioral = [result for skill in value['skills'] if skill['skill'] == name for result in skill['behavioral_results']]
        if len(behavioral) != 1 or behavioral[0]['custom']['purpose'] != 'oracle_qualification':
            raise RuntimeError('Oracle reporting purpose lost')
    elif context.value['analysis']['behavioral_results'][0]['custom']['purpose'] != 'oracle_qualification':
        raise RuntimeError('Oracle reporting purpose lost')
    # Keep the already allowlisted native diagnostics in a separate retained
    # copy. These fresh consumers see public input only, with no native tree.
    hidden = root / 'retained-native'
    native.rename(hidden)
    try:
        again = analysis.capture_inputs([public])
        if evidence.encoded(analysis.validate_analysis(value, again)) != evidence.encoded(value):
            raise RuntimeError('Public-only analysis changed')
        if report.render_report(value, again) != first:
            raise RuntimeError('Public-only rendered report changed')
        if not candidate: review.prepare([public], saved, name, rid)
    finally:
        hidden.rename(native)
    output = report.generate([public], saved, root / 'consolidated')
    # Fixed new derived members only; no native staging or verifier inputs.
    reports.write_json(native / 'reporting/analysis.json', value)
    (native / 'reporting/consolidated.html').write_bytes((output / 'report.html').read_bytes())
    public_records = [(member['member'], evidence._CapturedRecord(again.records[member['record_id']], again.guards))
                      for manifest in again.manifests for member in manifest['members']]
    reports.stage_public(ROOT, public, native / 'reporting/public', public_records)


if __name__ == '__main__':
    main()
