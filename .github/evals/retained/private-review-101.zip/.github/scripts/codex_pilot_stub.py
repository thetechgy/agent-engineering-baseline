"""Loopback-only non-forwarding qualification endpoint for the real CLI; no credentials or forwarding."""
import base64
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
import sys
import time

# The trusted host supplies this only at credential-free probe startup. Image
# bytes contain no qualification answer and there is no fallback payload.
if len(sys.argv) not in (4, 5):
    raise SystemExit('Probe fixture must be supplied at runtime')
fixture = sys.argv[3]
if not 0 < len(base64.b64decode(fixture, validate=True)) <= 65536:
    raise ValueError('Invalid probe fixture size')
commands = json.loads(base64.b64decode(sys.argv[4], validate=True)) if len(sys.argv) == 5 else None
if commands is not None:
    if not isinstance(commands,list) or not 0 < len(commands) <= 16:
        raise ValueError('Invalid probe commands')
    for command in commands:
        valid = isinstance(command,str) and len(command) <= 131072
        if isinstance(command,dict):
            valid = (set(command) == {'tool','input','expect_failure'} and command['tool']=='apply_patch'
                     and isinstance(command['input'],str) and len(command['input']) <= 131072
                     and type(command['expect_failure']) is bool)
        if not valid: raise ValueError('Invalid probe operation')


def program(command):
    if isinstance(command,str):
        return 'text(await tools.exec_command(' + json.dumps({'cmd':command,'max_output_tokens':4096}) + '));'
    call = 'text(await tools.apply_patch(' + json.dumps(command['input']) + '));'
    return 'try {' + call + '} catch (error) { text(String(error)); }' if command['expect_failure'] else call

record = Path(sys.argv[1])
scenario = sys.argv[2]
benchmark = scenario in ('benchmark-priced', 'benchmark-interruption')
scored = scenario == 'scored-priced'
priced = scored or scenario in ('priced-success', 'case-observation-priced', 'benchmark-priced')
if scenario == 'benchmark-interruption':
    scenario = 'interruption'
compatibility = scenario == 'compatibility'
answer = 'Credential-free qualification complete.'
if scenario in ('case-observation', 'case-observation-priced'):
    answer = base64.b64decode(fixture, validate=True).decode()
    scenario = 'success'
if priced or compatibility:
    scenario = 'success'


def response_usage(request, *, deadline=False):
    if priced:
        # Distinct per-response counts check accumulation and cached reads.
        input_tokens, cached, writes, output = (100, 40, 20, 10) if request == 1 else (200, 60, 30, 20)
        return {'input_tokens': input_tokens, 'input_tokens_details': {'cached_tokens': cached, 'cache_write_tokens': writes},
                'output_tokens': output, 'total_tokens': input_tokens + output}
    return {'input_tokens': 7 if deadline else 0, 'output_tokens': 3 if deadline else 0,
            'total_tokens': 10 if deadline else 0}


def scored_exec_advertised(body):
    # The reviewed 0.171.0 release carries this model's declaration in a
    # developer-role input item instead of the request's top-level tools.
    return any(tool.get('name') == 'exec' and tool.get('type') == 'custom'
               and all(name in tool.get('description', '') for name in ('exec_command', 'apply_patch'))
               for item in body.get('input', []) if item.get('type') == 'additional_tools' and item.get('role') == 'developer'
               for namespace in item['tools'] if namespace.get('type') == 'namespace' and namespace.get('name') == 'functions'
               for tool in namespace['tools'])


class Refuse(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_POST(self):
        size = int(self.headers.get('Content-Length', '0'))
        if not 0 < size <= 4 * 1024 * 1024:
            self.send_error(413)
            return
        raw = self.rfile.read(size)
        body = json.loads(raw)
        # Save only nonsensitive frozen-request observations; discard auth headers.
        value = {'authorization_matches_sentinel': self.headers.get('Authorization') == 'Bearer pilot-not-a-credential',
                 'request_keys': sorted(body), 'tool_definitions': body.get('tools'), 'path': self.path, 'model': body.get('model'), 'reasoning': body.get('reasoning'),
                 'input_sha256': hashlib.sha256(json.dumps(body.get('input'), sort_keys=True).encode()).hexdigest(),
                 'input': body.get('input'), 'tools': [t.get('name', t.get('type')) for t in body.get('tools', [])],
                 'service_tier': body.get('service_tier'), 'stream': body.get('stream'),
                 'requests': (json.loads(record.read_text())['requests'] if record.exists() else 0) + 1}
        if scenario == 'native-deadline':
            value['simulated_response_usage'] = {'input_tokens': 7, 'output_tokens': 3, 'complete': False,
                'provenance': 'non-forwarding fixture response; not provider usage or complete CLI accounting'}
        if priced or compatibility:
            observed = {k: value[k] for k in ('path', 'model', 'reasoning', 'authorization_matches_sentinel',
                                             'request_keys', 'tools', 'service_tier')}
            if scored:
                observed['native_tool_route'] = 'functions.exec' if scored_exec_advertised(body) else None
            previous = json.loads(record.read_text())['request_observations'] if record.exists() else []
            value['request_observations'] = [*previous, observed]
        record.write_text(json.dumps(value, indent=2) + '\n')
        if scenario == 'provider-timeout':
            time.sleep(120)
            return
        if scenario in ('provider-refusal', 'malformed-response'):
            payload = (json.dumps({'error': {'message': 'Controlled refusal', 'type': 'invalid_request_error'}}).encode()
                       if scenario == 'provider-refusal' else b'event: response.completed\ndata: deliberately-malformed\n\n')
            self.send_response(403 if scenario == 'provider-refusal' else 200)
            self.send_header('Content-Type', 'application/json' if scenario == 'provider-refusal' else 'text/event-stream')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if scenario == 'native-empty' or scenario == 'native-deadline' and value['requests'] > 1:
            time.sleep(120)  # Non-forwarding fixture: expire the native agent deadline.
            return
        if value['requests'] == 1:
            command = {
                'success': f"python3 /opt/pilot/codex_pilot_probe.py && printf %s {fixture} | base64 -d > /workspace/output/Subject.Tests.ps1",
                'command-failure': "printf pilot-command-failure; exit 23",
                'interruption': "printf pilot-command-started; sleep 120",
            }.get(scenario, ':')
            issued = commands if commands is not None and scenario in ('success', 'native-deadline') else [command]
            names = {tool.get('name') for tool in body.get('tools', [])}
            calls = []
            if 'exec_command' in names or benchmark and not names:
                for index, operation in enumerate(issued):
                    call_id = 'pilot-tool-' + str(index)
                    if isinstance(operation, str):
                        calls.append({'type': 'function_call', 'call_id': call_id, 'name': 'exec_command',
                                      'arguments': json.dumps({'cmd': operation, 'max_output_tokens': 4096})})
                    else:
                        if names and 'apply_patch' not in names:
                            raise ValueError('Native patch tool was not advertised')
                        calls.append({'type': 'custom_tool_call', 'call_id': call_id, 'name': 'apply_patch',
                                      'input': operation['input']})
            else:
                programs = [program(operation) for operation in issued]
                if any(isinstance(operation, dict) for operation in issued):
                    programs = ['\n'.join(programs)]
                calls = [{'type': 'custom_tool_call', 'call_id': 'pilot-tool-' + str(i),
                          'name': 'exec', 'input': code} for i, code in enumerate(programs)]
            events = [
                {'type': 'response.created', 'response': {'id': 'pilot-fixture-1'}},
                *[{'type': 'response.output_item.done', 'item': call} for call in calls],
                {'type': 'response.completed', 'response': {'id': 'pilot-fixture-1',
                    'usage': response_usage(1, deadline=scenario == 'native-deadline')}},
            ]
            payload = ''.join('event: '+event['type']+'\ndata: '+json.dumps(event)+'\n\n' for event in events).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if scenario == 'command-failure':
            payload = json.dumps({'error': {'message': 'Credential-free deliberate failure', 'type': 'invalid_request_error', 'code': 'pilot_failure'}}).encode()
            self.send_response(400)
            self.send_header('Content-Type', 'application/json')
        else:
            events = [
                {'type': 'response.created', 'response': {'id': 'pilot-fixture-2'}},
                {'type': 'response.output_item.done', 'item': {'id': 'pilot-final', 'type': 'message', 'role': 'assistant',
                 'content': [{'type': 'output_text', 'text': answer}]}},
                {'type': 'response.completed', 'response': {'id': 'pilot-fixture-2',
                 'usage': response_usage(2)}},
            ]
            payload = ''.join('event: '+e['type']+'\ndata: '+json.dumps(e)+'\n\n' for e in events).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


with HTTPServer(('127.0.0.1', 8765), Refuse) as server:
    record.with_suffix('.ready').touch()
    server.serve_forever()
