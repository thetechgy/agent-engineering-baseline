#!/usr/bin/env python3
"""Private report attachments with authenticated original validator sources."""

from dataclasses import dataclass
from datetime import datetime
import importlib.metadata
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import skill_analysis as analysis
import skill_evidence as evidence

require = evidence.require
LIMIT = 1024 * 1024
REPLY_LIMIT = 16 * LIMIT
MAX_ASSESSMENTS = 8
PINS = {'openai': '2.54.0', 'pydantic': '2.14.3', 'skillevaluator': '0.3.0'}
PREVIOUS_PINS = {'openai': '2.54.0', 'pydantic': '2.14.2', 'skillevaluator': '0.3.0'}
LEGACY_PINS = {'openai': '2.44.0', 'pydantic': '2.13.4', 'skillevaluator': '0.3.0'}
MODULES = ('skill_review.py', 'skill_analysis.py', 'skill_evidence.py', 'skill_reports.py')
# Reviewed source bytes, not commands or report-supplied executable identities.
PROFILES = {
    'custom-metrics-v2': ('f879f698e4d8d3db30bf6507538f07f3d142722b', (
        'bb47d02509539a1049c96befb461bde044baa2da0b8b29d700461395f40cfc9d',
        'e4f166ce6a5776911c8c673591751f83b55b3a7b32157adec920532cb6a55e47',
        '8cba160927ecf52cd34e1afae2763fc5e6d89be07f11aa0df2512bc43ae2331a',
        'f197b6338972be5817a935f1f6c51554f03b054c56c3fb6fed5b178cbd168d50')),
    'current-v2': ('afdb659ee130171d263da6f13c9dec6de912d3a4', (
        '778f26c48da2eb7811a895a8c6b4cc6f3d304262abbfbd86ee5e7bfa97102680',
        'b120aa5ed4d0f1d8267295ab79d4bc5bc05f9dd4a68e39e26131a61401a4d73f',
        '0cb9a970e0325d4212b53dbf3cc7a81a8ad01635109eba7bab9d5ac8d3af73ca',
        '730e66118b5b047dac5b26035e283a6e1ed293e01c9cf9be08af287fa73f0f9b')),
    'baseline-a5392b0': ('a5392b0eda37485b131ffe416fcb9d6e5ee547d2', (
        '778f26c48da2eb7811a895a8c6b4cc6f3d304262abbfbd86ee5e7bfa97102680',
        'b120aa5ed4d0f1d8267295ab79d4bc5bc05f9dd4a68e39e26131a61401a4d73f',
        '0cb9a970e0325d4212b53dbf3cc7a81a8ad01635109eba7bab9d5ac8d3af73ca',
        '850e7a5d78cf979800b1ca9053c8f9cabb4face1a081c9265a13e9ddb444d316')),
    'baseline-3f47c9d': ('3f47c9de4df362ae9977748ad6353227f403a9b8', (
        '778f26c48da2eb7811a895a8c6b4cc6f3d304262abbfbd86ee5e7bfa97102680',
        'b120aa5ed4d0f1d8267295ab79d4bc5bc05f9dd4a68e39e26131a61401a4d73f',
        '0cb9a970e0325d4212b53dbf3cc7a81a8ad01635109eba7bab9d5ac8d3af73ca',
        '9067eb9126ec0423b8471b8a7f8a7a2b17ab758650cb6937352b5a1ea67dc61a')),
    'podman-1cffcf9': ('1cffcf9947c265f126a3ceee75e5e35249bfd722', (
        'd7bb2414c2c7cc364ea880cddf21a2dc3f739f2fcbcc3c8261bb2877329d534a',
        'b120aa5ed4d0f1d8267295ab79d4bc5bc05f9dd4a68e39e26131a61401a4d73f',
        '0f63d7671743807225c100b64c56221ec62b8437b4ef0ab364791ebc171afc63',
        '51d83cf47b7f64902d1f186364cfafd40933f81afb01c786aa9c3c8d448d9e97')),
    'gh-89f46f0': ('89f46f026cdaaf001487cbcc1425204db29e8952', (
        '778f26c48da2eb7811a895a8c6b4cc6f3d304262abbfbd86ee5e7bfa97102680',
        'b120aa5ed4d0f1d8267295ab79d4bc5bc05f9dd4a68e39e26131a61401a4d73f',
        '0f63d7671743807225c100b64c56221ec62b8437b4ef0ab364791ebc171afc63',
        '51d83cf47b7f64902d1f186364cfafd40933f81afb01c786aa9c3c8d448d9e97')),
}

# Same reviewed validator modules; the new data asset admits refreshed runtimes.
PROFILES['custom-metrics-v3'] = PROFILES['custom-metrics-v2']

# A reviewed data asset accompanies only profiles whose contract uses it.
REGISTRY_DIGESTS = {
    'custom-metrics-v2': '380b377022281b36be2f3833cf116fa44e712a529ce9e7f9ad2060915f095d41',
    'custom-metrics-v3': 'cf78bf851a8a1e0b123d08956e76db764d004a3f4c1d7557c6a53339beea31c2',
}

PROFILES['current-v3'] = ('1aa5b06a4d0d3c1c8b97f2e7b3398964c67d8166', (
    '453046546b07212ce35610194d3db2dc1e088ae8ce67441fbe8b0dc3b2b5e9ab',
    'aa9e5d0dcb49d098c8cee0eb6773f1b51f53c2f460ec7d4c124605440ca15782',
    '6495ed3d8b89d44be05170b595d22052da4af79ccf51ab004760d394fbcb2ce5',
    '911ee50046e00b0e6e863f8949d72029ae73ad256b4151cecc4e27b0cdaa966e',
))
REGISTRY_DIGESTS['current-v3'] = 'cf78bf851a8a1e0b123d08956e76db764d004a3f4c1d7557c6a53339beea31c2'

# Self-contained Pester packaging and its versioned diagnostic carrier.
PROFILES['current-v4'] = ('35c04044b7c53fccebb4eff61a42e9352450065d', (
    '453046546b07212ce35610194d3db2dc1e088ae8ce67441fbe8b0dc3b2b5e9ab',
    'aa9e5d0dcb49d098c8cee0eb6773f1b51f53c2f460ec7d4c124605440ca15782',
    '15aad470fe74eeb4722cdef3193e09e49e087f548ed4faa6b8cc430363945887',
    '7f79d9af94ec98c2310cf55fc380191b31c5db915ab1abf28dc927b64d4827ac',
))
REGISTRY_DIGESTS['current-v4'] = 'b046df671258f9579513efc33249f90ba4a3fef29acb316380db4d5d714b2f95'

# Pydantic 2.14.3; previous profiles and their environments remain frozen.
PROFILES['current-v5'] = ('488085d51ae1263c95c14d15dcbd58663d6d293d', (
    'b1b20e52192475bd758fd1d5dba1f95bf9911da9c963c13ccf650fe165e043e5',
    '11e3372992824dbeca35990b03ec2e0e683837141f4c15e9e522df0a4cd71a6f',
    '44f1275e0e0086be42bfbe221258e0170ff8fd2a63be567815c1d2695f9a16ee',
    '91361cde84bcfd74484e07535f1bb252880d4eb9ab412b6d6cd1fe94e8b08f16',
))
REGISTRY_DIGESTS['current-v5'] = '4fb8cd3f8455428b5eaeb92fb3b77873f917b6fc78f8d84ee45f473948f87871'

# Exact supporting code/data required by the newer validator modules.
SUPPORT_FILES = {'current-v5': {'.github/scripts/evaluator_profiles.py': '4343ef13d8ee21e6abda83942a3b1a0a5f25f5d35671f5932d5d34c22346b9d9', '.github/evals/evaluator-candidate.json': '9049293fbee7e2518a57a66ab3bfdb90d5412fd105d9115b6b6d5a951c0cd871'}}

# Profile selection never accepts executable identities from attachment data.
# Only setup/operator configuration supplies the two reviewed environments.
def validator_runtime(profile):
    require(profile in PROFILES, 'Unsupported validator profile')
    expected = historical_pins(profile)
    installed = {name: importlib.metadata.version(name) for name in PINS}
    if installed == expected:
        return sys.executable, expected
    variable = ('SKILL_REVIEW_PYTHON' if profile == 'current-v5' else
                'SKILL_PREVIOUS_REVIEW_PYTHON' if expected is PREVIOUS_PINS else 'SKILL_LEGACY_REVIEW_PYTHON')
    executable = Path(os.environ.get(variable, ''))
    require(executable.is_absolute() and executable.is_file(), 'Pinned validator runtime unavailable')
    return str(executable), expected


def historical_pins(profile):
    if profile == 'current-v5':
        return PINS
    if profile in ('current-v3', 'current-v4'):
        return PREVIOUS_PINS
    return LEGACY_PINS


# Fixed launcher. -I ignores caller PYTHONPATH, user site and working-directory imports.
# Audit hooks restrict audited Python operations; they are NOT an OS sandbox.
AUDIT_GUARD = r'''
import sys, json, importlib.metadata, importlib.util
from pathlib import Path

def restrict(event, args):
    if event.startswith('socket.') or event in (
        'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.spawn',
        'os.fork', 'os.forkpty', 'pty.spawn'):
        raise PermissionError('Offline validator operation rejected')
sys.addaudithook(restrict)
sys.dont_write_bytecode = True
'''

RUNNER = AUDIT_GUARD + r'''
try:
    scripts, pins, original = sys.argv[1:]
    sys.path.insert(0, scripts)
    expected = json.loads(pins)
    if sys.version_info[:2] != (3, 13) or {name: importlib.metadata.version(name) for name in expected} != expected:
        raise ValueError('Pinned validator environment required')
    if original:
        # Historical snapshots are already authenticated by the parent. Use
        # their context, report and rendering rules, with the saved producer
        # version checked separately below. Keep the original source on disk
        # for the snapshot's own implementation-digest calculation.
        path = Path(scripts) / 'skill_review.py'
        source = path.read_text()
        guard = '\n    versions()\n'
        recorded = '        "versions": versions(),\n'
        screen = '            for key, item in node.items():\n'
        if any(source.count(marker) != 1 for marker in (guard, recorded, screen)):
            raise ValueError('Unrecognized historical replay interface')
        replay = source.replace(guard, '\n', 1).replace(recorded, '', 1)
        # The release treats token-like names as sensitive. At this exact
        # schema location the original validator checks typed usage counters.
        # Screen their numeric values under neutral keys; keep all saved bytes.
        replay = replay.replace(
            screen,
            screen +
            '                if (location == ("provenance", "usage") and type(item) is int\n'
            '                        and key in ("preflight_input_tokens", "input_tokens", "output_tokens", "total_tokens")):\n'
            '                    result[key.removesuffix("_tokens") + "_count"] = item\n'
            '                    continue\n',
            1,
        )
        spec = importlib.util.spec_from_file_location('skill_review', path)
        review = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = review
        exec(compile(replay, str(path), 'exec'), review.__dict__)
    else:
        import skill_review as review
    request = json.loads(sys.stdin.buffer.read(1024 * 1024 + 1))
    capture = review.Capture()
    raw = capture.read(Path(request['review']), limit=review.REPORT_LIMIT)
    saved = review.evidence.parse_json(raw, limit=review.REPORT_LIMIT)
    if original:
        review.require(saved['provenance']['versions'] == json.loads(original), 'Original producer versions differ')
    markdown = capture.read(Path(request['review']).with_name('skill-review.md'), limit=review.REPORT_LIMIT)
    context = review.prepare([Path(p) for p in request['inputs']], Path(request['analysis']),
        request['skill'], request['record_id'],
        **{k: Path(request[k]) if request[k] is not None else None for k in ('source', 'support', 'selection')})
    validated = review.validate_review(saved, context)
    review.require(markdown == review.render_review(validated, context), 'Markdown mismatch')
    for guard in (*context.guards, capture.guard()):
        guard()
    response = review.evidence.encoded({
        'report': validated, 'records': context.value['records'],
        'review_digest': review.evidence.digest_bytes(raw),
        'markdown_digest': review.evidence.digest_bytes(markdown),
        'module_names': [Path(m.__file__).name for m in (review, review.analysis, review.evidence, review.evidence.reports)],
        'layout_valid': review.evidence.ROOT == Path(sys.argv[1]).parents[1] and all(
            Path(m.__file__).parent == Path(sys.argv[1])
            for m in (review, review.analysis, review.evidence, review.evidence.reports)),
    })
    review.require(len(response) <= 16 * 1024 * 1024, 'Validator response limit')
    sys.stdout.buffer.write(response)
except Exception:
    sys.exit(1)
'''


@dataclass(frozen=True)
class ValidatedReviews:
    """Transient validation witness. No persisted receipt is accepted as authority."""
    items: tuple
    roots: tuple
    guards: tuple
    seal: str

    def check(self, captured):
        require(evidence.identity(self.items) == self.seal, 'Attachment projection changed')
        analysis.check_capture(captured)
        seen = set()
        for item in self.items:
            rid = item['record_id']
            require(rid not in seen and rid in captured.records, 'Attachment record mismatch')
            seen.add(rid)
            require(captured.records[rid]['source']['skill_id'] == item['skill'], 'Attachment skill mismatch')
        for guard in self.guards:
            guard()


def locator(value, path):
    require(type(path) is list and len(path) <= 32, 'Invalid assessment locator')
    for key in path:
        require((type(value) is dict and type(key) is str and key in value) or
                (type(value) is list and type(key) is int and 0 <= key < len(value)), 'Missing assessment field')
        value = value[key]
    return value


def attachment_path(value, parent):
    require(type(value) is str and 0 < len(value) <= 4096, 'Invalid attachment path')
    path = Path(value)
    return path if path.is_absolute() else parent / path


def document(spec, parent, capture, *, structured=True):
    evidence.closed(spec, ('path', 'digest'))
    evidence.sha(spec['digest'])
    path = attachment_path(spec['path'], parent)
    raw = capture.read(path, limit=LIMIT)
    capture.roots.append(path.parent)
    require(evidence.digest_bytes(raw) == spec['digest'], 'Attachment document digest mismatch')
    return (evidence.parse_json(raw, limit=LIMIT) if structured else raw.decode('utf-8')), spec['digest']


def assessment(spec, parent, capture, report, review):
    evidence.closed(spec, ('author_kind', 'attribution', 'document', 'report_digest_locator',
                          'fields', 'narrative', 'rubric', 'rubric_locator', 'freeze'))
    require(spec['author_kind'] in ('independent_ai', 'human_supplied', 'unknown'), 'Invalid assessor category')
    require(type(spec['attribution']) is str and 0 < len(spec['attribution']) <= 200 and
            bool(spec['attribution'].strip()), 'Invalid assessor attribution')
    source, digest = document(spec['document'], parent, capture)
    require(locator(source, spec['report_digest_locator']) == report['review_digest'], 'Assessment report mismatch')
    fields = spec['fields']
    evidence.closed(fields, ('verdict', 'score', 'maximum', 'dimensions', 'limitations'))
    values = {k: None if v is None else locator(source, v) for k, v in fields.items()}
    require(type(values['verdict']) is str and 0 < len(values['verdict']) <= 8000 and
            bool(values['verdict'].strip()), 'Missing assessment verdict')
    score, maximum, dimensions = (values[k] for k in ('score', 'maximum', 'dimensions'))
    require((score is None) == (maximum is None), 'Incomplete assessment score')
    if score is not None:
        require(type(score) is int and type(maximum) is int and 0 <= score <= maximum <= 1000 and maximum > 0,
                'Invalid assessment score')
    if dimensions is not None:
        require(score is not None and type(dimensions) is dict and 0 < len(dimensions) <= 32, 'Invalid rubric dimensions')
        for name, row in dimensions.items():
            require(type(name) is str and 0 < len(name) <= 200, 'Invalid dimension name')
            evidence.closed(row, ('score', 'rationale'))
            require(type(row['score']) is int and 0 <= row['score'] <= maximum and
                    type(row['rationale']) is str and bool(row['rationale'].strip()), 'Invalid dimension result')
        require(sum(row['score'] for row in dimensions.values()) == score, 'Assessment arithmetic mismatch')
    narrative = None; narrative_digest = None
    if spec['narrative'] is not None:
        narrative, narrative_digest = document(spec['narrative'], parent, capture, structured=False)
    rubric = None; rubric_digest = None; rubric_semantic_digest = None
    if spec['rubric'] is not None:
        original_rubric, rubric_digest = document(spec['rubric'], parent, capture)
        rubric_semantic_digest = evidence.identity(original_rubric)
        rubric = locator(original_rubric, spec['rubric_locator'])
        require(type(rubric) is dict and type(rubric.get('dimensions')) is dict, 'Missing rubric dimensions')
        if dimensions is not None:
            require(set(dimensions) == set(rubric['dimensions']), 'Assessment rubric dimensions mismatch')
    else:
        require(spec['rubric_locator'] is None and dimensions is None, 'Assessment rubric missing')
    freeze = None; freeze_digest = None
    if spec['freeze'] is not None:
        original_freeze, freeze_digest = document(spec['freeze'], parent, capture)
        require(type(original_freeze) is dict, 'Invalid freeze record')
        require(rubric is not None and original_freeze.get('rubric_digest') == rubric_semantic_digest,
                'Frozen rubric digest mismatch')
        require(original_freeze.get('context_digest') == report['report']['provenance']['context_digest'],
                'Freeze context mismatch')
        # Only allowlisted presentation metadata, never the complete preservation file.
        freeze = {k: original_freeze[k] for k in ('rubric_digest', 'context_digest', 'original_freeze_utc')
                  if k in original_freeze}
        if 'original_freeze_utc' in freeze:
            stamp = datetime.fromisoformat(freeze['original_freeze_utc'])
            generated = datetime.fromisoformat(report['report']['provenance']['timestamp'])
            require(stamp.utcoffset() is not None and stamp <= generated, 'Inconsistent freeze time')
    value = {'author_kind': spec['author_kind'], 'attribution': spec['attribution'], **values,
             'narrative': narrative, 'rubric': rubric, 'freeze': freeze,
             'provenance': {'assessment_digest': digest, 'analyst_report_digest': report['review_digest'],
                            'narrative_digest': narrative_digest, 'rubric_digest': rubric_digest,
                            'rubric_semantic_digest': rubric_semantic_digest, 'freeze_digest': freeze_digest}}
    require(len(evidence.encoded(value)) <= LIMIT, 'Assessment presentation limit')
    # Screen only the explicit projection. Original preservation metadata may contain
    # private paths; it is authenticated but never included in HTML or diagnostics.
    review.screen_payload(value)
    value['id'] = evidence.identity(value)
    return value


def run_validator(request, modules, capture, roots, registry, profile, assets=None, *, offline_replay=False):
    original = ''
    if offline_replay:
        import private_review_runtime
        executable, expected = sys.executable, private_review_runtime.OVERLAY
        original = evidence.encoded({**historical_pins(profile), 'python': private_review_runtime.PYTHON}).decode()
    else:
        executable, expected = validator_runtime(profile)
    guards = (capture.guard(),)
    temporary = evidence.write_outputs({}, input_paths=roots, input_guards=guards)
    try:
        evidence.write_outputs({}, temporary / '.github', input_paths=roots, input_guards=guards)
        scripts = evidence.write_outputs({}, temporary / '.github' / 'scripts', input_paths=roots,
                                         input_guards=guards, rendered=modules)
        if registry is not None:
            evidence.write_outputs({}, temporary / '.github' / 'evals', input_paths=roots,
                                   input_guards=guards, rendered={'custom-metrics.json': registry, **(assets or {})})
        try:
            response = subprocess.run([executable, '-I', '-B', '-c', RUNNER, str(scripts),
                                       evidence.encoded(expected).decode(), original],
                input=evidence.encoded(request), stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                cwd=temporary, env={'PATH': os.defpath, 'PYTHONDONTWRITEBYTECODE': '1', 'GIT_NO_LAZY_FETCH': '1'},
                timeout=120, check=False)
        except subprocess.TimeoutExpired:
            raise ValueError('Original validator deadline exceeded; omit attachment for base report') from None
        require(response.returncode == 0, 'Original validator rejected attachment; omit attachment for base report')
        require(len(response.stdout) <= REPLY_LIMIT, 'Validator response limit')
        value = evidence.parse_json(response.stdout, limit=REPLY_LIMIT)
        evidence.closed(value, ('report', 'records', 'review_digest', 'markdown_digest', 'module_names', 'layout_valid'))
        require(value['module_names'] == list(MODULES) and value['layout_valid'] is True, 'Validator layout mismatch')
        return value
    finally:
        # The new caller-owned 0700 tree contains only our copied public code.
        # Same-UID and privileged interference are outside the existing writer boundary.
        shutil.rmtree(temporary)


def load(paths, captured):
    """Independently validate all supplied attachments or fail without report output."""
    require(0 < len(paths) <= analysis.MAX_REPORTS, 'Analyst attachment limit')
    try:
        versions = {k: importlib.metadata.version(k) for k in PINS}
    except importlib.metadata.PackageNotFoundError:
        raise ValueError('Pinned validator environment required') from None
    offline_replay = versions['skillevaluator'] == '1.0.1'
    if offline_replay:
        import private_review_runtime
        private_review_runtime.validate_install()
    else:
        require(sys.version_info[:2] == (3, 13) and versions in (PINS, PREVIOUS_PINS, LEGACY_PINS),
                'Pinned validator environment required')
    import skill_review as review  # Optional dependency, never needed by a base report.
    capture = review.Capture()
    items = []; roots = []; original_records = []; seen = set()
    for path in paths:
        path = evidence.safe_path(path, directory_identities=capture.directories)
        spec = capture.json(path, limit=LIMIT)
        parent = path.parent
        roots.append(parent)
        evidence.closed(spec, ('schema_version', 'profile', 'tooling', 'skill', 'record_id', 'review',
                              'review_digest', 'markdown_digest', 'inputs', 'analysis', 'source', 'support',
                              'selection', 'assessments'))
        require(type(spec['schema_version']) is int and spec['schema_version'] == 1, 'Attachment schema mismatch')
        require(type(spec['profile']) is str and spec['profile'] in PROFILES, 'Unsupported validator profile')
        evidence.skill_id(spec['skill']); evidence.sha(spec['record_id'])
        rid = spec['record_id']
        require(rid not in seen and rid in captured.records, 'Duplicate or missing attachment record')
        selected = captured.records[rid]
        require(selected['kind'] != 'inventory' and selected['source']['skill_id'] == spec['skill'], 'Attachment skill mismatch')
        seen.add(rid)
        require(type(spec['inputs']) is list and 0 < len(spec['inputs']) <= analysis.MAX_INPUTS, 'Original input limit')
        request = {k: spec[k] for k in ('skill', 'record_id')}
        request['inputs'] = [str(attachment_path(p, parent)) for p in spec['inputs']]
        for key in ('review', 'analysis', 'source', 'support', 'selection'):
            require(spec[key] is not None or key in ('source', 'support', 'selection'), 'Missing original input')
            request[key] = str(attachment_path(spec[key], parent)) if spec[key] is not None else None
        for key in ('inputs', 'source', 'support'):
            for raw in (request[key] if key == 'inputs' else [request[key]]):
                if raw is not None:
                    capture.tree(Path(raw)); roots.append(Path(raw))
        for key in ('analysis', 'selection'):
            if request[key] is not None:
                capture.read(Path(request[key]), limit=analysis.JSON_LIMIT)
                roots.append(Path(request[key]).parent)
        raw = capture.read(Path(request['review']), limit=LIMIT)
        markdown = capture.read(Path(request['review']).with_name('skill-review.md'), limit=LIMIT)
        roots.append(Path(request['review']).parent)
        for key, data in (('review_digest', raw), ('markdown_digest', markdown)):
            evidence.sha(spec[key])
            require(spec[key] == evidence.digest_bytes(data), 'Analyst report digest mismatch')
        require(spec['tooling'] is not None or spec['profile'] in ('current-v2', 'current-v3', 'current-v4'), 'Historical tooling snapshot required')
        tooling = attachment_path(spec['tooling'], parent) if spec['tooling'] is not None else evidence.ROOT
        modules = {}
        revision, hashes = PROFILES[spec['profile']]
        for name, digest in zip(MODULES, hashes):
            data = capture.read(tooling / '.github' / 'scripts' / name)
            require(evidence.digest_bytes(data) == 'sha256:' + digest, 'Unreviewed validator module')
            modules[name] = data
        assets = {}
        for member, digest in SUPPORT_FILES.get(spec['profile'], {}).items():
            data = capture.read(tooling / member, limit=LIMIT)
            require(evidence.digest_bytes(data) == 'sha256:' + digest, 'Unreviewed validator supporting file')
            if member.startswith('.github/scripts/'):
                modules[Path(member).name] = data
            else:
                assets[Path(member).name] = data
        registry = None
        if spec['profile'] in REGISTRY_DIGESTS:
            registry = capture.read(tooling / '.github/evals/custom-metrics.json', limit=LIMIT)
            require(evidence.digest_bytes(registry) == 'sha256:' + REGISTRY_DIGESTS[spec['profile']],
                    'Unreviewed metric registry')
        roots.append(tooling)
        require(type(spec['assessments']) is list and len(spec['assessments']) <= MAX_ASSESSMENTS, 'Assessment limit')
        # Capture assessment originals before any temporary output is allocated.
        # This provisional projection confers no authority: original validation
        # below must still reproduce the entire report exactly.
        provisional = {'review_digest': spec['review_digest'], 'report': evidence.parse_json(raw, limit=LIMIT)}
        assessments = [assessment(row, parent, capture, provisional, review) for row in spec['assessments']]
        require(len({row['provenance']['assessment_digest'] for row in assessments}) == len(assessments), 'Duplicate assessment document')
        require(len(capture.members) + len(capture.states) <= analysis.MAX_ENTRIES, 'Attachment entry limit')
        require(len(evidence.encoded(request)) <= LIMIT, 'Validator request limit')
        result = run_validator(request, modules, capture, tuple((*roots, *capture.roots)), registry, spec['profile'],
                               assets, offline_replay=offline_replay)
        require(result['review_digest'] == spec['review_digest'] and result['markdown_digest'] == spec['markdown_digest'],
                'Validated report capture mismatch')
        require(evidence.encoded(result['report']) == evidence.encoded(evidence.parse_json(raw, limit=LIMIT)), 'Validated report changed')
        require(result['records'].get(rid) == selected, 'Original and consolidated record mismatch')
        original_records.extend(result['records'].values())
        items.append({'record_id': rid, 'skill': spec['skill'], 'profile': spec['profile'], 'tooling_revision': revision,
                      **({'validator_execution': 'skillevaluator-1.0.1-private-review-offline-v1'} if offline_replay else {}),
                      'review_digest': spec['review_digest'], 'markdown_digest': spec['markdown_digest'],
                      'reference_deadlines': sorted({evidence.REVIEWED_REFERENCE_EXPIRY[(ref['artifact_id'], ref['artifact_digest'])]
                          for record in result['records'].values() for ref in record['references']
                          if (ref['artifact_id'], ref['artifact_digest']) in evidence.REVIEWED_REFERENCE_EXPIRY}),
                      'report': result['report'], 'assessments': sorted(assessments, key=lambda row: row['id'])})

    def current_references():
        for record in original_records:
            evidence.validate_evidence(record, public=True, _observed_at=evidence.utc_now())
    guards = (capture.guard(), current_references)
    values = tuple(sorted(items, key=lambda row: row['record_id']))
    result = ValidatedReviews(values, tuple(dict.fromkeys((*roots, *capture.roots))), guards, evidence.identity(values))
    result.check(captured)
    return result
