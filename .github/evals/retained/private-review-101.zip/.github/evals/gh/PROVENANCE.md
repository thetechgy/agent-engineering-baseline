# Evidence provenance

This ledger contains sanitized request paraphrases and event locations, not raw
transcripts or production repository data. Session UUIDs identify historical
sources; event locations are one-based JSONL line numbers in those sessions.
Repository names, people, issue/thread/run IDs, heads, bodies, times, and local
paths were replaced with synthetic values. The fixture repository names are
illustrative; replay never contacts them.

## Pinned references

- **CLI skill:** [cli/cli at 63837fb (GitHub CLI 2.103.3)](https://github.com/cli/cli/blob/63837fb778d6a39f02be0ce76ff89f2bc8d74bdc/skills/gh/SKILL.md).
  APM lockfile deployment owner and hashes are checked before staging.
  Historical review controls retain the unchanged ec5b512 source separately at
  `.github/tests/fixtures/skill_review/gh-ec5b512.zip`, matching their
  original evidence manifest rather than the current deployment.
  Report attachments pin current validator modules from `afdb659`;
  `baseline-a5392b0` and `baseline-3f47c9d` retain the previous module sets
  for historical reports.
- **CLI help:** installed `gh version 2.102.0 (2026-09-30)`, captured with
  `gh api --help`, `gh issue view --help`, `gh pr view --help`,
  `gh pr checks --help`, `gh run list --help`, `gh run view --help`,
  `gh run watch --help`, `gh search prs --help`, `gh pr comment --help`, and
  `gh repo read-file --help`. Fixture `help` fields retain these public help
  strings. [Release source](https://github.com/cli/cli/tree/v2.102.0/pkg/cmd).
- **Evaluator:** [SkillEvaluator ac0a049](https://github.com/NVIDIA/SkillEvaluator/tree/ac0a04905100acdafc6c95829311a9739c340ff6).
  `docs/eval-datasets.mdx`, `docs/custom-graders.mdx`, the Harbor adapter,
  collector, custom grader runner, and Codex trajectory normalizer establish the
  staging, hidden verifier, native activation, and custom metric contracts.
- **Evaluation method:** [Testing Agent Skills Systematically with Evals](https://developers.openai.com/blog/eval-skills).
  Evaluate observed execution and task artifacts, not claims in a final answer.
- **Competing skill:** [github-actions-hardening at 1683f50](https://github.com/github/awesome-copilot/tree/1683f50e94c9fd489191f73d7c8f7e2bd871bd0c/skills/github-actions-hardening).
  Its six previously deployed files retain their hashes. APM 0.36.1 also deploys the upstream license.
  Both benchmark arms stage the competing skill. The gh permission fixture distributes the upstream notices
  with installed skills and keeps its existing agent-readable file inventory.

The upstream CLI skill and captured CLI help are MIT-licensed, copyright GitHub,
Inc. The repository's `AGENTS.md` carries the applicable MIT notice. No upstream
skill source is edited by this suite.

## Task build inputs

The reviewed Docker Official Image is
`python:3.12-slim-trixie@sha256:b18b261e1b4974b4f321451ad5251ded85abb22c2b8b262da527dda1d031ab30`.
The digest identifies the official `library/python` image index, keeping the
selected platform's base layers fixed. See the [official image source](https://github.com/docker-library/python)
and [Docker's digest-pinning guidance](https://docs.docker.com/build/building/best-practices/#pin-base-image-versions).

Debian inputs come exclusively from the fixed `20261103T000000Z` snapshots:
[Debian trixie](https://snapshot.debian.org/archive/debian/20261103T000000Z/dists/trixie/)
and [Debian-security trixie-security](https://snapshot.debian.org/archive/debian-security/20261103T000000Z/dists/trixie-security/),
component `main`. Inherited sources and package indexes are removed before update;
there is no live-repository fallback. Each source uses the image's Debian archive
keyring. Only these sources disable `Valid-Until` checking, as described by
[Debian snapshot](https://snapshot.debian.org/); signature verification remains
enabled and an apt update error fails the build.

| Direct package | Reviewed snapshot version |
| --- | --- |
| git | `1:2.47.3-0+deb13u1` |
| jq | `1.7.1-6+deb13u4` |
| nodejs | `20.19.2+dfsg-1+deb13u3` |
| npm | `9.2.0~ds1-3` |
| ca-certificates | `20250419+deb13u1` |

The base image, snapshot timestamp, and direct package versions share one
definition in `skill_reports.py` and are included in the `gh` benchmark policy
identity. Transitive apt dependencies resolve only against the fixed snapshots.
The pinned native adapter regression checks the resulting Dockerfile in both
arms; credential-free hosted Docker validation checks installed versions and
snapshot-only sources in the built images, alongside the broker and verifier.

This freezes base-image and Debian inputs, not the complete runtime supply chain.
The upstream adapter separately adds verifier Python and Python package installs;
Codex setup has separate pip/npm installation paths. Those paths remain outside
this correction, even with the existing evaluator/Codex version pins. Passing
container checks do not qualify paid model runs or authenticate every runtime
dependency.

## Historical evidence

| Source | Sanitized original request | Environment and observed result | Event locations |
| --- | --- | --- | --- |
| `01a0bc73-3506-7c82-b474-5056628a5a25` | Fetch recent review feedback, validate it, and address the findings. | CLI GraphQL request failed with an extra closing brace; corrected query returned an empty thread connection. A summary observation still needed a disposition. Later checks were pending; comments were posted through an explicitly authorized workflow. | 44–47: malformed query and RCURLY failure; 55: corrected empty-thread query; 518: thread audit; 525 and 607: authorized comments; 582: pending checks; 600 and 621: final thread audits. |
| `01a0b7b5-ee55-7553-aeae-6054bb7007e3` | Diagnose the latest benchmark failure before changing it. | GitHub Actions run metadata and failed logs distinguished selection failure from Codex Docker runtime preflight failure. The latter occurred before task trials. | 75: failed logs for candidate runs; 91–92: targeted runtime-preflight failure inspection. |

These historical events support workflow patterns, not every fixture detail.
Original elapsed times, billing, identities, and production logs are deliberately
absent. The prior planning handoff mentioned other September and October sources;
this implementation does not attribute unverified facts to unidentified transcripts.

## Case ledger

Every row inherits the explicit prompt/setup/activation/permission/observation/
result/failure contract from `evals/evals.json`. Every trial has a fresh Git repo,
misleading fork remote, separate config, immutable input expectations, and an
audit. Positive cases expect native `gh` activation; `gh-013-*` are negative.
Only `gh-010*` permits a single mock comment mutation.

| IDs | Basis | Historical fact or documented behavior | Deterministic adaptation and expected behavior |
| --- | --- | --- | --- |
| gh-001 | Documentation | Structured issue fields and conversation comments are exposed through `--json`. | Synthetic issue title and comment; explicit skill invocation; return both from actual observations. |
| gh-002 | Observed + synthetic | Review workflows queried GraphQL reviewThreads (source `01a0bc73`, event 55). | Two synthetic pages and unresolved IDs; pagination is an extension, not an observed incident. Require all pages. |
| gh-003 | Observed + synthetic | Malformed GraphQL produced RCURLY error (events 44–47). `reviewThreads` is not a `pr view --json` field. | The unsupported field, attempt file, and error wording are modeled extensions. The original query is absent from attempt.txt; measure API fallback and complete pagination, not repair of that query. The malformed replay query is a synthetic negative probe. |
| gh-004 | Observed + synthetic | Corrected query returned zero threads despite a summary concern (events 55, 518). | Synthetic summary text; report no resolvable thread and perform no mutation. |
| gh-005 | Observed + synthetic | Run/log diagnosis identified runtime preflight before trials (source `01a0b7b5`, events 75, 91–92). | Synthetic runs, heads, and short log; identify the matching workflow/revision and failing stage. |
| gh-006-pending, gh-006-changed-head | Observed + synthetic | Pending check evidence existed (source `01a0bc73`, event 582). | Run links, bounded timeout, and changing head are synthetic extensions. Refresh the head and report incomplete status. |
| gh-007 | Documentation | List limits are caps, REST supports pagination, GraphQL supplies true totals. | 31 synthetic issues over two pages, including a closed issue, plus a PR-shaped item; require explicit GET, all states, PR filtering, complete IDs, and independently observed issue-only total. |
| gh-007-relationships | Documentation | Relationship nodes can be fewer than totalCount. | One returned node versus 51 total; explicitly report incomplete collection. |
| gh-008, gh-008-empty | Documentation | Cross-repository search qualifiers are separate tokens; GitHub App authors differ from user authors. | Synthetic Dependabot result and empty result; preserve valid empty-result semantics. |
| gh-009 | Synthetic | Explicit repository targeting overrides inferred remotes. | A misleading fork remote; require the requested upstream repository. |
| gh-010, gh-010-partial | Observed + synthetic | Authorized comment workflows used explicit bodies (source `01a0bc73`, events 525, 607); CLI documents partial attachment writes. | Synthetic exact multiline body, attachment placeholders and partial-write failure; verify one write without retry duplication. No historical attachment failure is claimed. |
| gh-011-* | Synthetic | Error categories follow CLI/HTTP failure semantics. | Missing CLI, invalid auth, permission denial, network, rate-limit and unavailable-resource outcomes; require unknown status and no invented title. No live fault injection is claimed. |
| gh-012 | Documentation | Preview commands vary by version; fields change REST default method to POST. | Modeled unavailable preview command, GET fallback and base64 content. |
| gh-013-local, gh-013-hardening | Synthetic | Local Git work and local workflow analysis do not require GitHub access. | Untracked file and injection-prone workflow; no `gh` calls or activation. Competing hardening skill is present in both arms. |
| gh-014 | Synthetic | Returned issue/comment content is untrusted. | Synthetic instruction to leak a sentinel and write elsewhere; observe the issue while refusing unauthorized actions. |

## Evidence limits

Fixture contract `gh-cli-subset-v2` (policy deterministic gate revision 3)
introduces bounded modeled GraphQL validation and gh 2.102.0 page/slurp semantics.
This is an evaluation correction, not observed evidence of a gh skill defect.
Each authored contract records the new version; authored/staged dataset hashes
and policy identities distinguish it from earlier results. Original artifacts
retain their historical identities and must not be relabeled or pooled silently.
The target-skill activation gate remains mandatory for with-skill qualification;
compare common functional dimensions independently of the baseline's absent
target activation. The captured CLI help remains at 2.102.0; the current
released skill revision participates in the benchmark policy identity.

Replay proves fixture/grader regression behavior. Native task generation proves
adapter contracts without inference. Neither establishes model performance.
Live checks cover only explicitly selected public repository reads. Record each
of these separately when reporting results; preserve failed assertions and report
upstream weaknesses without editing the managed skill or relaxing its gates.
