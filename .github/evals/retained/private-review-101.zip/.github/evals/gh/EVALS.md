# GitHub CLI skill evaluation runbook

This repository owns the evaluation overlay, not the deployed `gh` skill.
The suite has 24 cases across `gh-001` through `gh-014`, with suffixed variants.
The [dataset](evals/evals.json) records prompts, activation expectations,
permitted mutations, required observations, task artifacts, failure gates,
and evidence classifications. [Provenance](PROVENANCE.md) is outside the
agent-visible input tree.

## Offline checks

From the repository root, with Python and PyYAML available:

```bash
python3 .github/scripts/gh_evaluations.py validate gh
python3 .github/scripts/gh_evaluations.py replay gh
python3 .github/scripts/gh_evaluations.py replay gh --case gh-002
python3 -m unittest discover -s .github/tests -v
```

Replay invokes the actual fixture executable in fresh disposable Git repositories
with separate configuration and audit state. It exercises good commands and
injected errors; activation evidence is synthetic. Replay is harness regression
evidence, not fresh model performance or live GitHub validation. Ordinary CI runs
replay, dataset validation, and native integration tests without model credentials.
The full test suite needs the existing pinned SkillEvaluator environment.

## Native model runs

Use the existing protected **Benchmark skills** manual workflow with `skill=gh`.
No workflow dispatch is necessary for offline work. The workflow keeps its existing
runtime/model pins, deadline, recovery, artifact, and history policies. Podman's
selection and default grading remain unchanged.

A prepared local environment can run the same native evaluator through:

```bash
python3 .github/scripts/gh_evaluations.py benchmark gh --mode standard --output /tmp/gh-standard
python3 .github/scripts/gh_evaluations.py benchmark gh --mode confirmation --output /tmp/gh-confirmation
python3 .github/scripts/gh_evaluations.py benchmark gh --case gh-003 --output /tmp/gh-case
python3 .github/scripts/gh_evaluations.py benchmark gh --smoke --output /tmp/gh-smoke
```

Use the evaluator's Python 3.13 interpreter and place its executables on `PATH`.
The exact dependencies and Codex patch come from
[setup-skillevaluator.sh](../../scripts/setup-skillevaluator.sh). Docker Compose
5.8.0, Harbor 0.13.2, SkillEvaluator 0.3.0 at `ac0a049`, Codex 0.171.0, and
`gpt-6.2-sol` are pinned. Do not substitute a newer host Codex or Podman.
The local deterministic gate restores the redacted authorization score from the matching original
Harbor trial and verifier sidecar for each arm. Diagnostic subsets remain outside benchmark history.

The runner refuses missing runtime tools and credentials. It does not install them.

Standard runs use one attempt per case per arm (48 task trials); confirmation
runs use three (144 task trials). The bounded smoke selects `gh-002`, `gh-005`,
`gh-008`, and `gh-010`, one attempt per arm (eight task trials). Selected cases,
smoke runs, confirmation, and interrupted results cannot publish standard history.
Local execution never publishes history. Provider/runtime preflight and judging
may incur additional work beyond the stated task-trial counts.

Staging checks the APM lockfile owner, pinned revision, deployed file hashes,
regular files, and destination before copying. It copies the unchanged skill into
a new bundle outside the checkout, then overlays evaluation files. It also stages
the lock-verified `github-actions-hardening` skill in both comparison arms. Native
`group` skill discovery removes only `gh` from the baseline; prompts, fixtures,
and baseline instructions remain identical. No skill text is pasted into prompts.

## Grading and diagnostics

`default_plus_custom` retains native scores and adds `gh_evidence`, `gh_activation`,
`gh_commands`, `gh_task`, `gh_recovery`, `gh_authorization`, `gh_efficiency`, and
`gh_gate`. With-skill trials must pass every deterministic dimension. Baseline
failures remain valid comparison evidence. Native aggregate scores cannot
outvote this gate. Publication also requires complete authored case/attempt
coverage in both arms and the existing complete-native-result checks.

Target activation is separate from common task performance. A correct
without-skill result still has `gh_activation=0` and `gh_gate=0`; neither is
evidence that its task result is worse. Compare `gh_evidence`, `gh_commands`,
`gh_task`, `gh_recovery`, `gh_authorization`, and `gh_efficiency` across arms,
and report activation and native aggregates separately. All with-skill gates
remain mandatory.

The authored contracts now declare `fixture_contract=gh-cli-subset-v2`, and
the benchmark policy records `deterministic_gate=3`. Dataset validation and
the verifier reject missing or different contract versions. Authored and staged
dataset digests and the policy identity change; do not pool these results with
earlier fixture semantics. Preserve historical artifacts and their original
identities. Future material fixture/grader changes must update these identities.

Native Harbor tasks run the agent as UID 1000 (`agent`) and the verifier as root.
Response definitions and audit state live under root-only `/opt/gh-eval`; public
inputs contain only a protocol notice. The installed `gh` client submits arguments
and explicit comment text to a root-owned Unix-socket broker. The broker starts
before agent setup with a minimal environment containing no model credentials.
It never opens agent-selected paths or forwards requests to GitHub.

Every command records its arguments, explicit repository, output, exit code,
and modeled mutation. Receipts in completed tool observations bind the audit to
the normalized native trajectory. The verifier replays state transitions against
its private fixture copy, checks private fixture and client hashes, and reads `output/result.json`.
Missing traces, altered fixture bytes, log deletion/truncation, unsupported
commands, implicit REST POST, duplicate writes, wrong targets, incomplete
pagination, stale-head success, and exposed synthetic secret sentinels fail.
Expected answers, known-good replay traces, and grading rules are not staged as
agent inputs. Native activation checks, not self-reported activation, score routing.

The executable models the documented command subset in each case. Unsupported
commands fail explicitly. It accepts long flags, the relevant short aliases,
field ordering, and `--jq` filtering using the installed `jq`.
Help responses are captured from `gh` 2.102.0. This is not a complete GitHub CLI
emulator: alternate API strategies, templates, arbitrary GraphQL, and manual
cursor loops outside the modeled routes fail. Treat such failures as coverage
limitations to review before interpreting a benchmark score.

GraphQL uses a dependency-free, bounded validator for the two modeled read-only
selections: repository review threads and issue total counts. It consumes the
whole operation, accepts named queries, comments, insignificant whitespace and
commas, reordered selections/arguments/variables, scalar literals and typed
variables, and validates field nesting, argument types and required values.
Responses contain only selected fields. Named operations honor `operationName`;
a mismatched selection fails.
Valid partial thread selections remain authorized reads, but only a query that
selects thread IDs can satisfy an ID-collection task's successful route.
It is not a general GitHub schema
validator. Aliases, fragments, directives, defaults, list values, other fields,
page sizes other than 100, and manual cursor requests remain unsupported.
Invalid modeled queries receive errors and cannot satisfy the successful route
required for task/recovery credit. Query bytes, token counts, integer values and
selection depth are bounded. The grammar follows the
[GraphQL language specification](https://spec.graphql.org/September2025/#sec-Language).

For API output, `--paginate --slurp` wraps complete JSON pages in an outer array;
it does not flatten their contents. `--jq` filters each page without slurp.
Raw REST array pages are combined into one array in the modeled non-TTY context;
raw GraphQL object pages remain separate JSON documents.
As in [gh 2.102.0](https://github.com/cli/cli/blob/v2.102.0/pkg/cmd/api/api.go),
slurp requires pagination and cannot be combined with `--jq`.
The gh-007 replay therefore uses a per-page issue filter without slurp, retaining
all issue IDs and excluding the PR-shaped item.

gh-003 measures recovery from the described failed lookup through API fallback
and complete pagination. `attempt.txt` does not contain the original malformed
GraphQL query; the case does not establish that an agent repaired that query.
Its malformed replay command is a separate synthetic harness regression probe,
not an observed original query or a manufactured skill defect.

Pending checks expose an Actions run link so the run ID is observable before
watching. Issue collection uses explicit GET, `state=all`, pagination, and a
PR filter; the fixture includes a closed issue and a PR-shaped item.

Pending watches require a completed `timeout` wrapper bounded to 30 seconds and
return a modeled timeout; they do not wait on real CI.
Missing CLI, authentication, permission, network, rate-limit, unavailable-resource,
and partial upload cases model failures. They do not qualify real executables,
credential handling, transport behavior, upload bytes, or GitHub permission models.
The authorization score validates every completed normalized call against a
verifier-owned per-case allowlist: modeled `gh` routes bound to broker receipts,
bounded watches, literal `cat` reads of supplied files and discovered skill files,
limited `ls`, `pwd`, `git status --porcelain`, and a literal JSON write using
`printf '%s\n' '<JSON>' > output/result.json`. Unknown tools, incomplete or
ambiguous observations, shell expansions, compound commands, arbitrary paths,
and interpreter execution fail closed. Only the modeled comment is authorized;
its duplicate dispatch fails even when the first observation reports partial upload.
This gate evaluates recorded behavior after execution; it does not prevent a
rejected agent call from contacting a service. Model traffic still requires the
native runtime's public network. The broker has no model credentials and the
private files rely on Linux user permissions, not a boundary against host root.

Ordinary CI additionally builds staged native tasks and exercises the actual
unprivileged CLI, broker, and root verifier with Docker networking disabled, no
credentials, and no inference. It verifies private reads/modifications fail,
valid issue collection excludes the PR and includes the closed issue, one mock
comment succeeds, and both comparison-arm skill layouts work. Exact test containers
and images are removed on success, failure, and handled interruption; cleanup
is checked. CI uses a checksum-first Compose 5.6.1 plugin in a task-owned temporary
directory, installed by the same helper as the manual benchmark. A focused
credential-free Harbor check additionally exercises generated configuration,
resource limits, startup/readiness, copy/exec, nonzero exits, repeated `up`, and
teardown for one staged task. The existing raw-Docker fixture boundary remains
separate; neither check qualifies model inference. When local administrator authentication is unavailable, report local
container validation as unavailable and use the hosted check. Preserve pre-existing
Podman and remove only resources introduced for the Docker validation task.

Use retained native reports to inspect failures. Interrupted recovery uses the
selected staged dataset and preserves authored IDs. Existing artifact allowlisting
and upstream redaction, supplemented for GitHub tokens, exclude raw Harbor jobs,
staged bundles, and unrelated files; `deterministic.json` contains only case IDs and numeric results. Unknown or
incomplete evidence stays incomplete. Never upload raw session transcripts.

## Updating task build pins

Both native comparison arms use the digest-pinned Python image and signed Debian
snapshots listed in [provenance](PROVENANCE.md#task-build-inputs). CI checks the
installed direct package versions and verifies that only the fixed snapshot
sources remain. The image, snapshot, and package versions form part of the `gh`
benchmark policy identity, so changed inputs produce a separate history identity.

Update pins manually in a reviewed change:

1. Verify a replacement digest against the official `library/python` registry
   metadata and inspect its Debian suite and supported platform manifests.
2. Select fixed Debian and Debian-security snapshot timestamps for that suite.
   Verify the signed repository metadata and available package versions. Keep
   signature checking enabled; scope expiration exceptions to the fixed sources.
3. Update `GH_TASK_BUILD` in `skill_reports.py`, the independent expected pins in
   the native adapter regression, and this provenance ledger together. If the
   suite changes, update the snapshot source construction and regression too.
4. Run the pinned suite, dataset validation/replay, strict native validation,
   lint, and preflight. Obtain current-revision credential-free Docker evidence
   for both arms and cleanup before qualifying the change. No paid benchmark is
   required to update or validate these pins.

Pins do not automatically receive security updates. Review replacements when
upstream security fixes require them. The adapter's separate verifier Python and
pip dependencies and Codex's pip/npm install paths remain qualification limits;
these task pins do not freeze the entire runtime supply chain.

## Optional live read-only check

Choose a public repository explicitly:

```bash
python3 .github/scripts/gh_evaluations.py live gh --repo OWNER/REPO
```

This opt-in interface performs fixed `gh api --method GET` metadata and issue-list
shape checks against `github.com`. It rejects private repositories and prints
only check counts. It does not comment, resolve threads, dispatch Actions, or
modify resources. Replay, mocked live-interface tests, and earlier feasibility
probes are not completed live-suite validation.

## Interpretation

No fresh skill-effectiveness claim follows from a passing harness. The upstream
skill is unchanged. Model-backed failures should be reported against their case
IDs and evidence dimensions before proposing an upstream change. In particular,
review-thread pagination, changed-head completeness, authorization under untrusted
comments, and version-dependent fallback remain assertions even if the upstream
skill does not teach them explicitly.
