# Skill review

Model-generated judgment requiring human review. Structural validity and citation
integrity do not establish semantic truth. Not quality-qualified; automated publication ineligible.

## Assessment

**Disposition:** no&#95;change

**Tested benefit:** Not measured; configuration is not observed benefit.

**Tested harm:** Unknown without recorded outcomes.

**Interpretation:** Retain the upstream skill; inspect evidence gaps.

**Uncertainty:** Expected cases do not establish completed trials or successful execution.

### Evidence sufficiency

**Source identity:** sha256:b5771a55b3b0f5ebb56f24dedfd29391e9cc7747a8b7fbb6f72432e515597bf5

**Source coverage:** complete

**Source integrity:** verified

**Behavioral support:** unavailable

**Behavioral scope:** No measured trials supplied.

**Provenance and availability:** Verified retained member; excerpts retain their original locator. Public availability remains independent.

**Limitations:** Synthetic fixture; no real-world effectiveness or causal conclusion.

**Conclusion:** investigation&#95;only

**Rationale:** Investigate applicability and command trace before any skill changes.

**Citations**

- sha256:96ed3db66ae2d51e67e2f258ed478caace0ce3e60f67171bfb58c6ec78fbe114: public&#95;record; &#91;&#x27;metrics&#x27;&#93;; available; positive.

## Native suggestions

No native suggestions supplied.

## Recommendations

No actions recommended.

## Unverified external assertions

None supplied.

## Host provenance

**Analysis digest:** sha256:1d9360062f49e0257e6b849aedd0382a80578d88731a16dd3de41e0d79136ed4

**Automated publication eligible:** False

**Configuration:** {   &quot;deadline&#95;seconds&quot;: 180,   &quot;input&#95;limit&quot;: 64000,   &quot;model&quot;: &quot;gpt-6.2-sol&quot;,   &quot;output&#95;limit&quot;: 12000 }

**Context digest:** sha256:6251080758fc40d5ecbc68781ea572f15e8e60a8b25ae7f82a6dba9280701561

**Endpoint:** https://api.openai.com/v1

**Implementation digest:** sha256:522b6655292c8dd5179efb92a9fbb084c267ec6aa442ba96934d5e63a3338847

**Input provenance digest:** sha256:b57e9c58dfe7fb78257cf35cc9e97f273600983dd8f2f111c21085e3850f2f97

**Method:** grounded-skill-review/2

**Prompt digest:** sha256:acf66608aea3b55771f6d88f7f1c457aa9b9a4b4caca9f189e0b7bf0907284a5

**Public availability:** {}

**Quality qualification:** not&#95;quality&#95;qualified

**Schema digest:** sha256:b899319f1897e4c472b967666c455515ba92c37d380d9f46847b68e0ea204f07

**Sdk retries:** 0

**Selected record id:** sha256:96ed3db66ae2d51e67e2f258ed478caace0ce3e60f67171bfb58c6ec78fbe114

**Source authentication:** {   &quot;coverage&quot;: &quot;complete&quot;,   &quot;missing&#95;members&quot;: &#91;&#93;,   &quot;verified&#95;members&quot;: &#91;     &quot;SKILL.md&quot;   &#93; }

**Source content digest:** sha256:6517f333dcea06832103c2b96a9ad9a1f40d3b081ac99053477e4477e02a24b8

**Source coverage:** complete

**Source identity:** sha256:b5771a55b3b0f5ebb56f24dedfd29391e9cc7747a8b7fbb6f72432e515597bf5

**Source members:** &#91;   {     &quot;complete&quot;: true,     &quot;end&#95;line&quot;: 216,     &quot;excerpt&#95;digest&quot;: &quot;sha256:d0cd6017dc3de91ae0f8b658bea78fd692fb27d252c966852eee5055f8d936c7&quot;,     &quot;id&quot;: &quot;sha256:77a3ac9f7059ca0944b954c1dbe6a8551c99c7a40bc1b39c2066594518ece3c7&quot;,     &quot;member&quot;: &quot;SKILL.md&quot;,     &quot;original&#95;digest&quot;: &quot;sha256:8be0aef75646008f64f89c59813ea301e7758aeb180ddb72f93dbf89ebab4f22&quot;,     &quot;start&#95;line&quot;: 1,     &quot;technical&#95;spans&quot;: &#91;&#93;,     &quot;total&#95;lines&quot;: 216,     &quot;transformation&quot;: &quot;utf8-splitlines-join-lf&quot;   } &#93;

**Source omitted members:** &#91;&#93;

**Source owner:** upstream

**Source path:** skills/gh

**Source repository:** cli/cli

**Source revision:** ec5b512045db67e5a2a4ff4a1b02660b2fb24390

**Store:** False

**Support ids:** &#91;&#93;

**Support provenance:** &#91;&#93;

**Timestamp:** 2026-11-23T12:00:00+00:00

**Tool policy:** none

**Truncation:** disabled

**Usage:** {   &quot;input&#95;tokens&quot;: 1000,   &quot;output&#95;tokens&quot;: 500,   &quot;preflight&#95;input&#95;tokens&quot;: 1000,   &quot;total&#95;tokens&quot;: 1500 }

**Validation status:** structure&#95;and&#95;citations&#95;validated&#95;human&#95;review&#95;required

**Versions:** {   &quot;openai&quot;: &quot;2.54.0&quot;,   &quot;pydantic&quot;: &quot;2.14.2&quot;,   &quot;python&quot;: &quot;3.13.18&quot;,   &quot;skillevaluator&quot;: &quot;0.3.0&quot; }
