# Skill review

Model-generated judgment requiring human review. Structural validity and citation
integrity do not establish semantic truth. Not quality-qualified; automated publication ineligible.

## Assessment

**Disposition:** investigate

**Tested benefit:** Not measured; configuration is not observed benefit.

**Tested harm:** Unknown without recorded outcomes.

**Interpretation:** Retain the upstream skill; inspect evidence gaps.

**Uncertainty:** Expected cases do not establish completed trials or successful execution.

### Evidence sufficiency

**Source identity:** sha256:b5771a55b3b0f5ebb56f24dedfd29391e9cc7747a8b7fbb6f72432e515597bf5

**Source coverage:** complete

**Source integrity:** verified

**Behavioral support:** unavailable

**Behavioral scope:** No measured trials supplied.

**Provenance and availability:** Verified retained member; excerpts retain their original locator. Public availability remains independent.

**Limitations:** Synthetic fixture; no real-world effectiveness or causal conclusion.

**Conclusion:** investigation&#95;only

**Rationale:** Investigate applicability and command trace before any skill changes.

**Citations**

- sha256:96ed3db66ae2d51e67e2f258ed478caace0ce3e60f67171bfb58c6ec78fbe114: public&#95;record; &#91;&#x27;metrics&#x27;&#93;; available; positive.

## Native suggestions

No native suggestions supplied.

## Recommendations

### 1. investigate (low)

**Scope:** Request exact retained results from the overlay owner.

**Source paths:** &#91;&#93;

**Justification:** Supported only within the cited scope.

**Expected benefit:** Establish what evidence is available before proposing changes.

**Alternatives:** &#91;&#x27;Retain current guidance and repair the evaluation.&#x27;&#93;

**Risks:** &#91;&#x27;Overfitting one synthetic trial.&#x27;&#93;

### Evidence sufficiency

**Source identity:** sha256:b5771a55b3b0f5ebb56f24dedfd29391e9cc7747a8b7fbb6f72432e515597bf5

**Source coverage:** complete

**Source integrity:** verified

**Behavioral support:** unavailable

**Behavioral scope:** No measured trials supplied.

**Provenance and availability:** Verified retained member; excerpts retain their original locator. Public availability remains independent.

**Limitations:** Synthetic fixture; no real-world effectiveness or causal conclusion.

**Conclusion:** investigation&#95;only

**Rationale:** Investigate applicability and command trace before any skill changes.

**Citations**

- sha256:96ed3db66ae2d51e67e2f258ed478caace0ce3e60f67171bfb58c6ec78fbe114: public&#95;record; &#91;&#x27;metrics&#x27;&#93;; available; positive.

**Measurable validation**

- Zero unconfirmed destructive operations; retain all previous passes.

**Comparisons:** &#91;&#93;

**Previously passing cases:** False

**Mandatory safety gates:** False

**Negative controls:** False

**Fresh realistic cases:** False

## Unverified external assertions

None supplied.

## Host provenance

**Analysis digest:** sha256:1d9360062f49e0257e6b849aedd0382a80578d88731a16dd3de41e0d79136ed4

**Automated publication eligible:** False

**Configuration:** {   &quot;deadline&#95;seconds&quot;: 180,   &quot;input&#95;limit&quot;: 64000,   &quot;model&quot;: &quot;gpt-6.2-sol&quot;,   &quot;output&#95;limit&quot;: 12000 }

**Context digest:** sha256:6ba1f8c8542a8b5afec87d89268a4df00ef12578a51c7736750f2a47dbff96b8

**Endpoint:** https://api.openai.com/v1

**Implementation digest:** sha256:c8c2c17db91d31b9cc1f1b381cc209740932cd8c569600b0282fc5e1942e714b

**Input provenance digest:** sha256:b57e9c58dfe7fb78257cf35cc9e97f273600983dd8f2f111c21085e3850f2f97

**Method:** grounded-skill-review/2

**Prompt digest:** sha256:fb36dc5ae8f3aa78218fdded686e3f8db079373b3d795fd0bd8a5a966e3a554b

**Public availability:** {}

**Quality qualification:** not&#95;quality&#95;qualified

**Schema digest:** sha256:b899319f1897e4c472b967666c455515ba92c37d380d9f46847b68e0ea204f07

**Sdk retries:** 0

**Selected record id:** sha256:96ed3db66ae2d51e67e2f258ed478caace0ce3e60f67171bfb58c6ec78fbe114

**Source authentication:** {   &quot;coverage&quot;: &quot;complete&quot;,   &quot;missing&#95;members&quot;: &#91;&#93;,   &quot;verified&#95;members&quot;: &#91;     &quot;SKILL.md&quot;   &#93; }

**Source content digest:** sha256:6517f333dcea06832103c2b96a9ad9a1f40d3b081ac99053477e4477e02a24b8

**Source coverage:** complete

**Source identity:** sha256:b5771a55b3b0f5ebb56f24dedfd29391e9cc7747a8b7fbb6f72432e515597bf5

**Source members:** &#91;   {     &quot;complete&quot;: true,     &quot;end&#95;line&quot;: 216,     &quot;excerpt&#95;digest&quot;: &quot;sha256:d0cd6017dc3de91ae0f8b658bea78fd692fb27d252c966852eee5055f8d936c7&quot;,     &quot;id&quot;: &quot;sha256:77a3ac9f7059ca0944b954c1dbe6a8551c99c7a40bc1b39c2066594518ece3c7&quot;,     &quot;member&quot;: &quot;SKILL.md&quot;,     &quot;original&#95;digest&quot;: &quot;sha256:8be0aef75646008f64f89c59813ea301e7758aeb180ddb72f93dbf89ebab4f22&quot;,     &quot;start&#95;line&quot;: 1,     &quot;technical&#95;spans&quot;: &#91;&#93;,     &quot;total&#95;lines&quot;: 216,     &quot;transformation&quot;: &quot;utf8-splitlines-join-lf&quot;   } &#93;

**Source omitted members:** &#91;&#93;

**Source owner:** upstream

**Source path:** skills/gh

**Source repository:** cli/cli

**Source revision:** ec5b512045db67e5a2a4ff4a1b02660b2fb24390

**Store:** False

**Support ids:** &#91;&#93;

**Support provenance:** &#91;&#93;

**Timestamp:** 2026-11-23T12:00:00+00:00

**Tool policy:** none

**Truncation:** disabled

**Usage:** {   &quot;input&#95;tokens&quot;: 1000,   &quot;output&#95;tokens&quot;: 500,   &quot;preflight&#95;input&#95;tokens&quot;: 1000,   &quot;total&#95;tokens&quot;: 1500 }

**Validation status:** structure&#95;and&#95;citations&#95;validated&#95;human&#95;review&#95;required

**Versions:** {   &quot;openai&quot;: &quot;2.44.0&quot;,   &quot;pydantic&quot;: &quot;2.13.4&quot;,   &quot;python&quot;: &quot;3.13.18&quot;,   &quot;skillevaluator&quot;: &quot;0.3.0&quot; }
