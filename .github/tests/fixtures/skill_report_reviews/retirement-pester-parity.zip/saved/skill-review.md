# Skill review

Model-generated judgment requiring human review. Structural validity and citation
integrity do not establish semantic truth. Not quality-qualified; automated publication ineligible.

## Assessment

**Disposition:** no&#95;change

**Tested benefit:** Native metrics are descriptive only.

**Tested harm:** No causal harm established.

**Interpretation:** Guidance already exists; inspect execution before attributing a defect.

**Uncertainty:** The test is synthetic and support is scoped.

### Evidence sufficiency

**Source identity:** sha256:4a987ead430a606395e1cc32ef69d68585d78d5f248835c5d54a56f81c97fdf9

**Source coverage:** unavailable

**Source integrity:** unavailable

**Behavioral support:** unavailable

**Behavioral scope:** Only supplied trial 1 in the synthetic control.

**Provenance and availability:** Verified retained member; excerpts retain their original locator. Public availability remains independent.

**Limitations:** Synthetic fixture; no real-world effectiveness or causal conclusion.

**Conclusion:** investigation&#95;only

**Rationale:** Investigate applicability and command trace before any skill changes.

**Citations**

- sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c: public&#95;record; &#91;&#x27;metrics&#x27;&#93;; available; positive.

## Native suggestions

No native suggestions supplied.

## Recommendations

No actions recommended.

## Unverified external assertions

None supplied.

## Host provenance

**Analysis digest:** sha256:3d80920e91b394ffe5c5ffabab77680c6a78174a515914a2aa7606661df29dd7

**Automated publication eligible:** False

**Configuration:** {   &quot;deadline&#95;seconds&quot;: 180,   &quot;input&#95;limit&quot;: 64000,   &quot;model&quot;: &quot;gpt-6.2-sol&quot;,   &quot;output&#95;limit&quot;: 12000 }

**Context digest:** sha256:28933e4121240456248e06e262c5910bf0710c50496e93f5d4bb3625a70e596e

**Endpoint:** https://api.openai.com/v1

**Implementation digest:** sha256:522b6655292c8dd5179efb92a9fbb084c267ec6aa442ba96934d5e63a3338847

**Input provenance digest:** sha256:e679e1f0dee9486358fac937f1c1a1b966fe6a165bc1412677dd0e01aefba9ae

**Method:** grounded-skill-review/2

**Prompt digest:** sha256:acf66608aea3b55771f6d88f7f1c457aa9b9a4b4caca9f189e0b7bf0907284a5

**Public availability:** {   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:0b43e93722257f474c88081c2a4eab35393de43f06ec642c34441878fb40e6e4&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:0c4cbbbee0a2e0cdd5fde5bdd5cd65d62c927fc6c9ae21367354be8178f6f674&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:0d4e58e9a724f6c16053da716f3f995ed63034b56ca2aa9b89492d2a92e9568a&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:0d516ccdfa1f97d0e5c9a7c96f4b29cd0e954db386b6e330e35ae6f3ebb99ebb&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:179775cc384d687fd855654ddfb92e6e1bc1ae2be2d446c97d8074f8b96759cc&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:17bbf9d2c7b207247cf6b3d7d49e3e1e1b57f9441307afddb99f7f6a665254d7&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:1c46806b6615c5115d473167fcb162e29aebe0c4ecb2810be2c7c2b4d537350d&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:1cfca49499c67fafb207a3dd883ba8d8a9edb2f00a11ef463812ba6e82a3ceb9&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:2347e0d1af0a743952e2dc5f1f2c6cff2ac763e76c93f4ed814914e85787d8e9&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:24609bb12c454563805d1ca14a74475012dcdc32b3c142c9aca9aecf61c0f786&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:26396e12ba8c369d0e35e4d37966d7dc6a88d4e9b78d5a3645349c73b7f7b978&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:2694b6e54acfcd0906af557d43492b01f5a768be433f5066652a59d6b469c84e&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:2b8cb748d865dabcb5a1e4b3ab1e942a9d60709850c1a562d4318bcb436e901c&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:2baee85da6d7811b5622baaf78459502688ec651b5137360d43597050c73ce6f&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:2d74a0ee011bad542872f3b0ea6f069d0283b44ee68d927e96817b40c37837e0&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:382b73b89b287bd6b49b056050d2492574e2653ab911ec05bd1c35dce7f6d406&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:3b4256af340d14bac6d0fb0d9cb9d801616039388b9a9660d2d875954986ac8c&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:3bc0dbe9cad49c653b9d76861d63fac9c8ca04bfb55b4f9a28d8ab3f647a55eb&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:4673b6ef8d660a82fa16165f17c7eb81c1b8d892d0d32521fcc05a4c12d986b6&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:55af2f0aa4cd950f1d65051ffae505cf2f986c193a321cc3dae77e6e37820904&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:6aaedaa5db91fb250ceadbdd7dec5703d26ec8f2f3eb7deff6db4a42f07eaefa&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:6ffddafb5bc02f1dd196b4b4983802b989f6cd2f75b09ae888a6c8c527550a32&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:768f03f27030ab68f72dc1025896acefea8f0f229588a982a7d0612b40237019&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:776adff1d15e825053dc54a7b7cc53d7d3da7dfa307b95700f8663ff132bcfd0&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:78253c2e16bc702fb1c076933aaa9665bd07ac8bcd48700c2083e9c57152a203&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:7ad8c8dcd64afde6d858e10224710e85aa078d03ed36f38c2b6318eb522b63ca&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:7fc9f0040355a72a3dee886f4a575909078f77679cd680a9c129cd733c5233bc&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:86637e1e5117c246fb4c94c03571d5ed94d13d6e4d449b0efa4fc13ad6631a52&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:867af5ae8a9b0d822a1d58187d4f337f38fe98491139ee651c22253c1a94c9e3&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:86a62d7d8a589f629272dfe2abffd8c9aa59a4244e3e46cda484280245551da9&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:8da094e393c4c0a40a488cf1499e6f60d648ecf227cc84a5fb8af99de4306434&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:92b11afa701d947d3aa1d934002ad8ca36fb31f48de7ce912762c5b4243152ea&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:92ecde503c205e954b0289ab2a98c13e9158daa299e36d8345b319e74dc3b0c3&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:935fe2ae60e48890dae6617220134cc5f6bfb74342050b16651e1eb06f393733&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:93b0d489ad5f2a016512fb0349088144abaa5f1e820a976d200385c386ce1bf0&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:989cea72f5d229800103db1c903692e3eefc271f47769f453c266faaaf72d879&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:9933d53a6bd961b94f325df66d643640598e3774ed767b9b925af86baf45aed7&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:9e7c832b5eee79be4e0df8c28b26b58283b4a494f481a238b0a6520b58d9ef79&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:a526970d4d147db9b3d3525aab3577740fac4939bdb2a3e43c249739b6163194&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:a73e9eb686e0baf83dcc88372e4329869c664cf517cd07ef284db74fb8f584fd&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:ac4ca7f6c9a923294db74fce4d978df46586c4ecace694ac7d5644482599d506&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:accffb26eb66d9fcbd243f5b9f73eed5a79ea84db76c887768fbce6724158cbd&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:badd3e302d619aa4062dc196b0edb74858877d9b3f1b12a20f17255622f92167&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:be46554eceb682610b6b546b9132e5aac43087ad1c27eb19b9660a8d9f2cb4a1&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:bff76cf6fa9ca1adec32d1869a4e390e9dd2a2c81f92d6e480e76a2fad1c4282&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:c0ad238a07c540ad6be4d5a3bc288e0f3e745a5740bec2cfd791b322067ed9e6&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:c0e70f23771e6da69bc62961445c06a0b04bf0d56b77bd2f9e91e9e46d3a2abc&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:c29277da6b1472e9aaf40624618542b4cc14f2c5537a8f4af38e6483d2d236df&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:c352923231944ed9cce0d4b728be84cf296706037733557e8ab2149dc1a4edde&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:cb44ae562806220b0616357b4fddd11fc9d1b85df4ba1952c01b114993e1410f&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:cc3f1770440936a3326ed5c6eb53560759a5fe8caa81f024eebd79122cdee5d8&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:cf458f9acd23fe08894a64854b8424e2f54030919d00d2a985d464389dee2ee4&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:cfc301d4d81c0095524442a69df43181b374f42f444543e631ff82d30728b07e&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:d9fab7c0ed0c69b3828a3fa50685fcb057cf625b9b3e1ecc5443459577cbb6d9&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:de29aea86fcb7c39894a7464c26315bece8f17b12c2ee13d5852e046f0ef25ed&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:ded7a935eafe19a5748a17b80ea26cb0cd725cf9d3bea60c377f2266c393c826&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:e5f19d069bf2c8779f48ea388993eea2d5e6cb2a4c45fbd7f5a5aeeb986970d6&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:ec65251c6adb603fd09be42f12e3275ce4b0212bf9e5342a0998ddd9db7c809c&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:ecc64683f746f99347b0821e130841fe581904c6f95497865700580a1ecf0a99&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:ef3deac4c8b6920594e914128e71b6c0ab3d37b066917441d225ec48a9440522&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:f0fd77ca0c6f2168bfc3630fd58d3401373d5d3b61f83d09e9271e05bdb1beab&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:f1af89643af28a701e68765411d16f6af00d66c8e9ae901ad27135bf6b81dc16&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:fa27f515a7f0e8b4664daa8fdfe57f5313b51486ae93d2112bc59f81df75bb5b&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:facbab21c9a0b3bef8b7a74e726c5624636e2d6aec6298a6a2c35953c115e1e0&quot;: &quot;available&quot;,   &quot;sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c/sha256:fb8f671b6775244ad6c28bc853b35033739d7a1f700ad59069926af1b3c7bf8a&quot;: &quot;available&quot; }

**Quality qualification:** not&#95;quality&#95;qualified

**Schema digest:** sha256:5d97f9281cc9f1b3eab0ce379f43d10c2bdd9685581c4df349ffb2f982c92580

**Sdk retries:** 0

**Selected record id:** sha256:8e0e2579e853ca82f0ae2d67e0695dd6c6480888553caacbed7994d83040030c

**Source authentication:** {   &quot;coverage&quot;: &quot;unavailable&quot;,   &quot;missing&#95;members&quot;: &#91;     &quot;SKILL.md&quot;,     &quot;references/compatibility-and-migration.md&quot;,     &quot;references/execution.md&quot;   &#93;,   &quot;verified&#95;members&quot;: &#91;&#93; }

**Source content digest:** sha256:d3641c5190c1b86d8e853adc8f3c68fe6376b5fdaf5c1d90c610a745102ff03e

**Source coverage:** unavailable

**Source identity:** sha256:4a987ead430a606395e1cc32ef69d68585d78d5f248835c5d54a56f81c97fdf9

**Source members:** &#91;&#93;

**Source omitted members:** &#91;   &quot;SKILL.md&quot;,   &quot;references/compatibility-and-migration.md&quot;,   &quot;references/execution.md&quot; &#93;

**Source owner:** local

**Source path:** .apm/skills/powershell-pester-6

**Source repository:** thetechgy/agent-engineering-baseline

**Source revision:** 58cb9698543c546173501887254dc7989d2db396

**Store:** False

**Support ids:** &#91;&#93;

**Support provenance:** &#91;&#93;

**Timestamp:** 2026-11-23T12:00:00+00:00

**Tool policy:** none

**Truncation:** disabled

**Usage:** {   &quot;input&#95;tokens&quot;: 1000,   &quot;output&#95;tokens&quot;: 500,   &quot;preflight&#95;input&#95;tokens&quot;: 1000,   &quot;total&#95;tokens&quot;: 1500 }

**Validation status:** structure&#95;and&#95;citations&#95;validated&#95;human&#95;review&#95;required

**Versions:** {   &quot;openai&quot;: &quot;2.54.0&quot;,   &quot;pydantic&quot;: &quot;2.14.2&quot;,   &quot;python&quot;: &quot;3.13.18&quot;,   &quot;skillevaluator&quot;: &quot;0.3.0&quot; }
